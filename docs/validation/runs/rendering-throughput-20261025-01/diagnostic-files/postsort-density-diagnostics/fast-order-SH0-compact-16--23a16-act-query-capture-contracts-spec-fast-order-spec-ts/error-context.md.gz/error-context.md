# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fast-order.spec.ts >> SH0 compact 16-bit order keeps IDs and exact query/capture contracts
- Location: e2e\fast-order.spec.ts:4:83

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Copy range (offset: 0, size: 128) does not fit in [Buffer \"Fast depth indirect\"] size (20).
+  - While validating source [Buffer \"Fast depth indirect\"] copy size.
+  - While encoding [CommandEncoder (unlabeled)].CopyBufferToBuffer([Buffer \"Fast depth indirect\"], 0, [Buffer (unlabeled)], 0, 128).
+  - While finishing [CommandEncoder (unlabeled)].
+ ",
+   "[Invalid CommandBuffer] is invalid due to a previous error.
+  - While calling [Queue].Submit([[Invalid CommandBuffer]])
+ ",
+ ]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import type {} from './fast-order-harness';
  3  | 
  4  | for (const degree of [0, 1, 2, 3]) for (const precision of [16, 24, 32] as const) test(`SH${degree} compact ${precision}-bit order keeps IDs and exact query/capture contracts`, async ({ page }, info) => {
  5  |   await page.goto('/e2e/fast-order-harness.html'); await page.waitForFunction(() => !!window.fastOrder);
  6  |   const value = await page.evaluate(({ degree, precision }) => window.fastOrder.measure(degree, precision), { degree, precision });
  7  |   await info.attach('fast-order.json', { body: JSON.stringify(value), contentType: 'application/json' });
> 8  |   expect(value.fast).toBe(true); expect(value.errors).toEqual([]); expect(value.memory.bytes).toBe(0);
     |                                                       ^ Error: expect(received).toEqual(expected) // deep equality
  9  |   expect(value.actualOrder).toEqual(value.expectedOrder); expect(value.indirectCount).toBe(value.projectedVisible);
  10 |   if (precision === 32) expect(value.quality.maxRgb).toBe(0);
  11 |   expect(value.pickA.index).toBe(value.pickB.index); expect(value.pickA.depth).toBe(value.pickB.depth);
  12 |   expect(value.captureEqual).toBe(true); expect(value.mapEqual).toBe(true); expect(value.visibleEqual).toBe(true); expect(value.colorSorts).toBe(0);
  13 |   expect(value.interleaved).toBe(true);
  14 | });
  15 | for (const visibility of [0, 1]) test(`compact order handles visible fraction ${visibility}`, async ({ page }) => {
  16 |   await page.goto('/e2e/fast-order-harness.html'); await page.waitForFunction(() => !!window.fastOrder);
  17 |   const value = await page.evaluate(visibility => window.fastOrder.measure(0, 32, visibility), visibility);
  18 |   expect(value.fast).toBe(true); expect(value.actualOrder).toEqual(value.expectedOrder); expect(value.quality.maxRgb).toBe(0);
  19 |   expect(value.indirectCount).toBe(value.projectedVisible); expect(value.errors).toEqual([]); expect(value.memory.bytes).toBe(0);
  20 | });
  21 | test('refused optional order resources retain exact baseline rendering', async ({ page }) => {
  22 |   await page.goto('/e2e/fast-order-harness.html'); await page.waitForFunction(() => !!window.fastOrder);
  23 |   const value = await page.evaluate(() => window.fastOrder.measure(0, 32, .25, true));
  24 |   expect(value.fast).toBe(false); expect(value.actualOrder).toEqual(value.expectedOrder); expect(value.quality.maxRgb).toBe(0);
  25 |   expect(value.captureEqual).toBe(true); expect(value.mapEqual).toBe(true); expect(value.errors).toEqual([]); expect(value.memory.bytes).toBe(0);
  26 | });
  27 | for(const precision of [16,24] as const) test(`GL ${precision}-bit display restores exact clean output and retains reusable worker arrays`,async({page})=>{
  28 |   await page.goto('/e2e/fast-order-harness.html');await page.waitForFunction(()=>!!window.fastOrder);
  29 |   const value=await page.evaluate(precision=>window.fastOrder.workerQuality(precision),precision);
  30 |   expect(value.before).toBe(precision);expect(value.after).toBe(32);expect(value.captureEqual).toBe(true);expect(value.mapEqual).toBe(true);
  31 |   expect(value.picks[0].index).toBe(value.picks[1].index);expect(value.picks[0].depth).toBe(value.picks[1].depth);
  32 |   expect(value.scratch.bytes).toBeGreaterThan(0);expect(value.memory.bytes).toBe(0);
  33 | });
  34 | for(const precision of [24,32] as const) test(`compact ${precision}-bit order follows atomically replaced canonical and divergent preview masks`,async({page})=>{
  35 |   await page.goto('/e2e/fast-order-harness.html');await page.waitForFunction(()=>!!window.fastOrder);
  36 |   const value=await page.evaluate(precision=>window.fastOrder.measure(3,precision,.25,false,true),precision);
  37 |   expect(value.fast).toBe(true);expect(value.actualOrder).toEqual(value.expectedOrder);expect(value.errors).toEqual([]);
  38 |   if(precision===32)expect(value.quality.maxRgb).toBe(0);
  39 |   expect(value.captureEqual).toBe(true);expect(value.mapEqual).toBe(true);expect(value.memory.bytes).toBe(0);
  40 | });
  41 | 
```