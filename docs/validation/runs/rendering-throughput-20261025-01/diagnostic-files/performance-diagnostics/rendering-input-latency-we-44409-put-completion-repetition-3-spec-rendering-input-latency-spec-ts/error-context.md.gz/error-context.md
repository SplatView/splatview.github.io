# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rendering-input-latency.spec.ts >> webgl2 App wheel input completion repetition 3
- Location: e2e\rendering-input-latency.spec.ts:7:3

# Error details

```
Error: page.evaluate: Error: Camera owner/revision changed before queue completion.
    at BenchmarkObservation.settleFrame (http://127.0.0.1:5173/src/app/benchmarkObservation.ts:252:23)
    at http://127.0.0.1:5173/src/app/controller.ts:818:18
    at http://127.0.0.1:5173/src/app/controller.ts:2012:56
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic "SplatView scene" [ref=e4]
  - paragraph [ref=e5]: Tab moves between the scene and controls. Scene shortcuts work while the scene has focus. Open Tutorial for navigation and selection controls. The canvas is visual; scene status reports the current file, tool and selection counts.
  - status "Scene status" [ref=e6]: Ready. Bench example.sog. 0 selected of 262556 visible. Basic mode. Orbit navigation.
  - toolbar "Scene controls" [ref=e7]:
    - group "Scene files" [ref=e8]:
      - button "Open scene" [ref=e9] [cursor=pointer]
      - button "Save scene" [ref=e13] [cursor=pointer]
      - button "Capture image" [ref=e19] [cursor=pointer]
      - button "Copy image" [ref=e24] [cursor=pointer]
    - group "View navigation" [ref=e31]:
      - button "Reset camera" [ref=e32] [cursor=pointer]
      - button "Orbit / Look" [pressed] [ref=e37] [cursor=pointer]
      - button "Auto orbit" [ref=e45] [cursor=pointer]
      - button "Flip up" [ref=e50] [cursor=pointer]
      - group "Guides and background" [ref=e55]:
        - button "Viewport guides" [ref=e56] [cursor=pointer]
        - button "Background" [ref=e63] [cursor=pointer]
    - group "Lens and display" [ref=e66]:
      - button "Narrower lens" [ref=e67] [cursor=pointer]
      - button "Wider lens" [ref=e72] [cursor=pointer]
      - button "Fullscreen" [ref=e77] [cursor=pointer]
    - group "Viewer panel" [ref=e81]:
      - button "Tools" [ref=e82] [cursor=pointer]
  - link "OpsiClear website" [ref=e85] [cursor=pointer]:
    - /url: https://opsiclear.com
  - status "Copy image" [ref=e86]
```