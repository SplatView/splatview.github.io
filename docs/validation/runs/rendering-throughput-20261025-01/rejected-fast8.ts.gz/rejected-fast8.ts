import frameSource from './frame.wgsl?raw';
import sortSource from './sort.wgsl?raw';
import scanSource from './scan.wgsl?raw';
import visibleSource from './visibleOrder.wgsl?raw';
import { planFastOrder } from './fastOrderLayout';
import type { SortPrecision } from '../sortPrecision';
import type { GaussianRenderer, GpuScene } from './renderer';

const sortEntries = ['rank', 'scatter'] as const, scanEntries = ['local', 'blocks', 'bins'] as const;
const visibleEntries = ['countVisible', 'visibleOffsets', 'scatterVisible'] as const;
type Pipelines = Record<typeof sortEntries[number] | typeof scanEntries[number] | typeof visibleEntries[number] | 'generateVisible', GPUComputePipeline>;
type Stage = { pipeline: GPUComputePipeline; group: GPUBindGroup; x: number; y?: number; indirectOffset?: number };
const preparations = new WeakMap<GaussianRenderer, Promise<Pipelines>>();

async function prepare(renderer: GaussianRenderer): Promise<Pipelines> {
  let pending = preparations.get(renderer);
  if (!pending) {
    pending = renderer.checkedAllocation(() => {
      const device = renderer.device;
      const sort = device.createShaderModule({ label: 'Stable 8-bit depth radix', code: frameSource + sortSource });
      const scan = device.createShaderModule({ label: '256-bin depth prefix', code: scanSource });
      const visible = device.createShaderModule({ label: 'Stable visible source IDs', code: frameSource + visibleSource });
      const entries: [keyof Pipelines, GPUShaderModule, Record<string, number> | undefined][] = [
        ...sortEntries.map(name => [name, sort, { RADIX_BITS: 8, RADIX_BINS: 256, RADIX_MASK_WORDS: 2048 }] as [typeof name, GPUShaderModule, Record<string, number>]),
        ...scanEntries.map(name => [name, scan, { RADIX_BINS: 256 }] as [typeof name, GPUShaderModule, Record<string, number>]),
        ...visibleEntries.map(name => [name, visible, undefined] as [typeof name, GPUShaderModule, undefined]),
        ['generateVisible', sort, undefined],
      ];
      const task = Promise.all(entries.map(async ([entryPoint, module, constants]) => [entryPoint,
        await device.createComputePipelineAsync({ label: `Fast order ${entryPoint}`, layout: 'auto', compute: { module, entryPoint, constants } })] as const));
      void task.catch(() => undefined); return { task };
    }, async value => { await value.task.catch(() => undefined); }).then(async value => Object.fromEntries(await value.task) as Pipelines);
    preparations.set(renderer, pending);
  }
  try { const pipelines = await pending; renderer.requireScene(); return pipelines; }
  catch (error) { if (preparations.get(renderer) === pending) preparations.delete(renderer); throw error; }
}

/** Adds commands only. The renderer submits; the scene owns its credit and
 * retires these buffers after genuine query/display/capture completion. */
export class FastOrder {
  private disposed = false;
  private readonly full: Stage[][] = [];
  private readonly compact: Stage[][] = [];
  private readonly visibility: Stage[];
  private readonly generateFull: Stage;
  private readonly generateCompact: Stage;
  private readonly generateFullOdd: Stage;
  private readonly generateCompactOdd: Stage;
  readonly indirect: GPUBuffer;
  readonly drawGroup: GPUBindGroup;
  constructor(renderer: GaussianRenderer, readonly allocationBytes: number,
    private readonly buffers: GPUBuffer[], private readonly release: () => void,
    scene: GpuScene, pipelines: Pipelines, layout: ReturnType<typeof planFastOrder>) {
    const device = renderer.device;
    const create = (label: string, size: number, usage = GPUBufferUsage.STORAGE) => {
      const buffer = device.createBuffer({ label, size, usage: usage | GPUBufferUsage.COPY_SRC }); buffers.push(buffer); return buffer;
    };
    const extra = Object.fromEntries(Object.entries(layout.sizes).map(([name, size]) => [name,
      create(`Fast depth ${name}`, size, name === 'indirect' ? GPUBufferUsage.STORAGE | GPUBufferUsage.INDIRECT : GPUBufferUsage.STORAGE)])) as Record<keyof typeof layout.sizes, GPUBuffer>;
    this.indirect = extra.indirect;
    const fullParams: GPUBuffer[] = [], compactParams: GPUBuffer[] = [];
    for (let i = 0; i < 4; i++) {
      const full = create(`Full depth pass ${i}`, 16, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
      device.queue.writeBuffer(full, 0, new Uint32Array([scene.count, layout.groups, layout.blocks, i * 8])); fullParams.push(full);
      compactParams.push(create(`Visible depth pass ${i}`, 16, GPUBufferUsage.UNIFORM | GPUBufferUsage.STORAGE));
    }
    const bind = (pipeline: GPUComputePipeline, entries: [number, GPUBuffer][]) => renderer.bind(pipeline, entries);
    const b = scene.buffers;
    this.visibility = visibleEntries.map((name): Stage => {
      const entries: Record<typeof name, [number, GPUBuffer][]> = {
        countVisible: [[0, renderer.frame], [1, b.projected], [2, b.ranks], [3, extra.visibleCounts]],
        visibleOffsets: [[0, renderer.frame], [3, extra.visibleCounts], [5, extra.indirect], ...compactParams.map((buffer, i) => [6 + i, buffer] as [number, GPUBuffer])],
        scatterVisible: [[0, renderer.frame], [2, b.ranks], [3, extra.visibleCounts], [4, extra.visible]],
      };
      return { pipeline: pipelines[name], group: bind(pipelines[name], entries[name]), x: name === 'visibleOffsets' ? 1 : layout.groups };
    });
    const generation: [number, GPUBuffer][] = [[8, b.splats], [9, b.states], [10, renderer.frame], [11, b.states]];
    this.generateFull = { pipeline: renderer.pipelines.generate, group: bind(renderer.pipelines.generate, [[0, fullParams[0]], [3, b.pairsA], ...generation]), x: layout.groups };
    this.generateCompact = { pipeline: pipelines.generateVisible, group: bind(pipelines.generateVisible, [[0, compactParams[0]], [3, extra.compactA], ...generation, [12, extra.visible]]), x: 0, indirectOffset: 32 };
    this.generateFullOdd = { pipeline: renderer.pipelines.generate, group: bind(renderer.pipelines.generate, [[0, fullParams[0]], [3, b.pairsB], ...generation]), x: layout.groups };
    this.generateCompactOdd = { pipeline: pipelines.generateVisible, group: bind(pipelines.generateVisible, [[0, compactParams[0]], [3, extra.compactB], ...generation, [12, extra.visible]]), x: 0, indirectOffset: 32 };
    this.drawGroup = renderer.bind(renderer.raster, [[0, renderer.frame], [4, extra.compactA], [7, b.projected]]);
    for (const [params, output, indirect] of [[fullParams, this.full, false], [compactParams, this.compact, true]] as const) {
      let input = indirect ? extra.compactA : b.pairsA, destination = indirect ? extra.compactB : b.pairsB;
      for (const parameter of params) {
        output.push([
          { pipeline: pipelines.rank, group: bind(pipelines.rank, [[0, parameter], [1, input], [2, b.ranks], [4, extra.counts]]), x: layout.groups, ...(indirect ? { indirectOffset: 32 } : {}) },
          { pipeline: pipelines.local, group: bind(pipelines.local, [[0, parameter], [1, extra.counts], [2, extra.groupOffsets], [3, extra.groupSums]]), x: layout.blocks, y: 256, ...(indirect ? { indirectOffset: 48 } : {}) },
          { pipeline: pipelines.blocks, group: bind(pipelines.blocks, [[0, parameter], [1, extra.groupSums], [2, extra.blockOffsets], [3, extra.binTotals]]), x: 256, ...(indirect ? { indirectOffset: 64 } : {}) },
          { pipeline: pipelines.bins, group: bind(pipelines.bins, [[1, extra.binTotals], [2, extra.binOffsets]]), x: 1 },
          { pipeline: pipelines.scatter, group: bind(pipelines.scatter, [[0, parameter], [1, input], [2, b.ranks], [3, destination], [5, extra.groupOffsets], [6, extra.blockOffsets], [7, extra.binOffsets]]), x: layout.groups, ...(indirect ? { indirectOffset: 32 } : {}) },
        ]);
        [input, destination] = [destination, input];
      }
    }
  }
  encode(encoder: GPUCommandEncoder, precision: SortPrecision, compact: boolean) {
    if (this.disposed) throw new Error('The fast depth order was retired.');
    const pass = encoder.beginComputePass({ label: compact ? 'Compact stable depth sort' : 'Fast stable depth sort' });
    const dispatch = (stage: Stage) => {
      pass.setPipeline(stage.pipeline); pass.setBindGroup(0, stage.group);
      if (stage.indirectOffset !== undefined) pass.dispatchWorkgroupsIndirect(this.indirect, stage.indirectOffset);
      else pass.dispatchWorkgroups(stage.x, stage.y ?? 1);
    };
    if (compact) for (const stage of this.visibility) dispatch(stage);
    dispatch(compact ? precision === 24 ? this.generateCompactOdd : this.generateCompact : precision === 24 ? this.generateFullOdd : this.generateFull);
    const stages = compact ? this.compact : this.full;
    for (let i = (32-precision)/8; i < 4; i++) for (const stage of stages[i]) dispatch(stage);
    pass.end();
  }
  dispose() {
    if (this.disposed) return; this.disposed = true;
    for (const buffer of this.buffers) buffer.destroy(); this.release();
  }
}

export async function allocateFastOrder(renderer: GaussianRenderer, scene: GpuScene): Promise<FastOrder | undefined> {
  const limits = renderer.device.limits;
  if (scene.count < 2048 || !renderer.admitSortScratch || !(limits.maxComputeWorkgroupStorageSize >= 8192)) return;
  const layout = planFastOrder(scene.count);
  if (Object.values(layout.sizes).some(size => size > limits.maxBufferSize || size > limits.maxStorageBufferBindingSize)) return;
  let release: (() => void) | undefined; const buffers: GPUBuffer[] = [];
  let released = false;
  const releaseCredit = () => { if (!released) { released = true; release?.(); } };
  try {
    release = renderer.admitSortScratch(layout.bytes);
    const pipelines = await prepare(renderer); renderer.requireScene(scene);
    const result = await renderer.checkedAllocation(() => new FastOrder(renderer, layout.bufferBytes, buffers, releaseCredit, scene, pipelines, layout), value => value.dispose());
    renderer.requireScene(scene); return result;
  } catch {
    // Uniform initialization borrows the buffers until its genuine queue fence.
    if (buffers.length) await renderer.device.queue.onSubmittedWorkDone().catch(() => undefined);
    for (const buffer of buffers) buffer.destroy(); releaseCredit(); return;
  }
}
