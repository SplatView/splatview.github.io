import datetime
import gzip
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path.cwd()
PHASE = ROOT / '.build/rendering-throughput-20261025-01'
OUT = ROOT / 'docs/validation/runs/rendering-throughput-20261025-01'
OUT.mkdir(parents=True, exist_ok=True)


def record(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
    return record(path)


def copy(source, name=None):
    source = ROOT / source
    target = OUT / (name or source.name)
    shutil.copyfile(source, target)
    return record(target)


def archive(source, name=None):
    target = OUT / ((name or source.name)+'.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    target.write_bytes(gzip.compress(data, compresslevel=9, mtime=0))
    return {'archive': record(target), 'uncompressedBytes': len(data), 'uncompressedSha256': hashlib.sha256(data).hexdigest()}


def report(name):
    value = json.loads((PHASE/name).read_text(encoding='utf-8-sig'))
    stats = value['stats']
    assert stats['unexpected'] == stats['skipped'] == stats['flaky'] == 0, (name,stats)
    return {'name': name, 'stats': stats, 'report': archive(PHASE/name)}


frozen = json.loads((PHASE/'final-source.json').read_text())['files']
assert all(record(ROOT/f['path']) == f for f in frozen), 'Frozen runtime/fixture source changed during qualification.'
old = json.loads((ROOT/'docs/validation/runs/standalone-renderer-20261025-01/source-files.json').read_text())
paths = {f['path'] for f in old['files']}
for directory in ['src','e2e','tests','examples']:
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/directory).rglob('*') if p.is_file())
paths.add('design/feature-reviews/rendering-throughput-2026-10-25.md')
source = save('source-files.json', {'gitBase': old['gitBase'], 'includesRetainedUncommittedWork': True,
    'files': [record(ROOT/p) for p in sorted(paths)]})
prior = []
expected = {
    'standalone-renderer-20261025-01': '5574c1e48169040a7c950309cf90aae7f0f454982c621067d640ff7ba211b77c',
    'rendering-optimization-20261025-01': '0326dec1df30b79cef47866d93a5ca364c339bff230e741c918f368890925475',
    'webgl2-implementation-20261025-02': 'a8db5009a5ae728be08c31a47bea265d982cae90166de718c63bbd75a08c998c',
}
for folder, digest in expected.items():
    item=record(ROOT/f'docs/validation/runs/{folder}/validation.json')
    assert item['sha256']==digest;prior.append(item)
for name,digest in {
    'standalone-renderer-2026-10-25.md':'062ef0a22ba3de1f5730acd392ca7eb5b45eb62f0a41faa0557b6bfbccfda0ed',
    'rendering-optimization-plan-2026-10-25.md':'07f9ba42254ea4f23e983fc0b2eddcd3f369cece6ebea181be16b57b74114f14',
    'webgl2-implementation-2026-10-25.md':'a83979669bf8652cafcc9e7fc5a93f1984872048ae495d5b1c53055a7266b843',
    'steady-splats-2026-10-25.md':'eb57319abd4c47cab768d346182dea6138f93d33a030a78ee3f0e016237046aa',
}.items():
    item=record(ROOT/f'design/feature-reviews/{name}');assert item['sha256']==digest;prior.append(item)
unit=json.loads((PHASE/'unit-final.json').read_text(encoding='utf-8-sig'))
assert unit['success'] and unit['numFailedTests']==0
browser_names=['performance-render-only.json','input-fences-qualified.json','postsort-qualified.json','final-fast-order.json','renderer-regression.json','selection-browser.json',
    'outputs-webgl2.json','outputs-webgpu.json','sdk-browser.json','production-webgl2.json','production-webgpu.json']
browsers=[report(name) for name in browser_names]
diagnostics=[]
for name, reason in {
    'fast-order-initial.json':'Rejected compact/full query order aliasing. Fixed by separate compact draw pairs; final regression interleaves display during an exact map.',
    'fast-order-separated.json':'Intermediate successful query separation candidate, before final algorithm.',
    'precision-smoke.json':'16-bit candidate rejected as application default by the representative image-quality budget.',
    'precision24-smoke.json':'Intermediate accepted 24-bit representative image result; final repeated evidence supersedes it.',
    'gpu-pass-timing.json':'Invalid zero GPU timing probe: resolve destination alignment was wrong. Excluded from performance conclusions.',
    'gpu-pass-timing-corrected.json':'Valid intermediate eight-bit/serial-prefix prototype; slower than portable baseline and rejected.',
    'parallel-prefix.json':'Rejected WGSL reserved identifier; optional path fell back. Excluded from fast-path timing conclusions.',
    'parallel-prefix-qualified.json':'Intermediate four-bit indirect-sort prototype; later rejected after dense-scene measurements.',
    'density-and-mask.json':'Dense/small indirect-sort regression; two fixture query-snapshot failures after capture used different opacity. Replaced algorithm and preserved scoped capture inputs.',
    'postsort-density.json':'Post-sort candidate: timing cases passed, but sixteen fixture cases copied 128 bytes from the new 20-byte argument buffer. Harness fixed before final qualification.',
    'final-performance.json':'59 passed and three WebGL input-observer cases failed on expected camera advance during outstanding frames. All six input cases replaced by the actual post-input display-fence sampler; production staleness checks unchanged. Retained 56 non-input passing cases in an explicitly derived report.',
    'fast24-regression.json':'Intermediate precision/order/query regression cohort.',
}.items():
    diagnostics.append({'reason':reason,'stats':json.loads((PHASE/name).read_text(encoding='utf-8-sig'))['stats'],'report':archive(PHASE/name)})
diagnostic_artifacts=[]
for folder in ['postsort-density-diagnostics','performance-diagnostics']:
    for p in (PHASE/folder).rglob('*'):
        if p.is_file(): diagnostic_artifacts.append(archive(p, 'diagnostic-files/'+folder+'/'+p.relative_to(PHASE/folder).as_posix()))
benchmark_inputs=[archive(PHASE/name) for name in ['baseline.json','baseline-source.json','pipelined-stage.json','performance-source.json','pre-budget-source.json','final-source.json','post-performance-delta.json']]
intermediate_build_checks=[{'name':name,'stats':json.loads((PHASE/name).read_text(encoding='utf-8-sig'))['stats'],'report':archive(PHASE/name)} for name in ['sdk-browser-before-budget.json','production-webgl2-before-budget.json','production-webgpu-before-budget.json']]
logs=[archive(p) for p in PHASE.glob('*.log')]
processors=[archive(PHASE/name) for name in ['summarize.py','collect-receipt.py','write-report.py','verify-artifacts.mjs','run-browser-checks.mjs','run-final-build-checks.mjs','production.config.ts']]
for p in PHASE.glob('rejected-*'):
    diagnostic_artifacts.append(archive(p))
manifest=json.loads((ROOT/'dist/build-manifest.json').read_text())
engine=json.loads((ROOT/'dist-engine/engine-manifest.json').read_text())
checks=json.loads((PHASE/'checks.json').read_text())
value={'schemaVersion':1,'kind':'rendering-throughput-delivery','status':'implemented-and-locally-qualified',
    'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'featureId':'view.render',
    'review':record(ROOT/'design/feature-reviews/rendering-throughput-2026-10-25.md'),
    'sourceInventory':source,'priorEvidenceUnchanged':prior,
    'appArtifacts':copy('.build/rendering-throughput-20261025-01/artifacts.json','app-artifacts.json'),
    'standaloneArtifacts':copy('dist-engine/engine-manifest.json'),
    'performance':copy('.build/rendering-throughput-20261025-01/performance-summary.json'),
    'controlledSeries':copy('.build/rendering-throughput-20261025-01/controlled-series.json'),
    'environment':copy('.build/rendering-throughput-20261025-01/environment.json'),
    'browserCohorts':browsers,'intermediateBuildChecks':intermediate_build_checks,'diagnostics':diagnostics,'diagnosticArtifacts':diagnostic_artifacts,'benchmarkInputs':benchmark_inputs,
    'portableTests':{'passed':unit['numPassedTests'],'failed':unit['numFailedTests'],'files':len(unit['testResults']),'report':archive(PHASE/'unit-final.json')},
    'checks':checks,'logs':logs,'evidenceProcessors':processors,
    'build':{'deploymentId':manifest['deploymentId'],'appInputId':manifest['build']['appInputId'],'engineSourceId':engine['sourceId']},
    'qualificationLimits':['Windows Chromium/NVIDIA secure localhost only; no cross-origin isolation required.',
        'Browser cohorts overlap and are not summed as unique coverage.',
        'Historical before/after queue/fence and trusted-input clocks are not physical presentation FPS.',
        'GPU timestamp comparisons use interleaved measured-source variants and synthetic scenes, not historical GPU timestamps or an external-engine benchmark. Shipping differs only in close/allocation joining, base-mirror budget bookkeeping, test-only input/all-visible fixtures and generated build identity; the GPU/GL frame, sorting/compaction and shader algorithms are unchanged.',
        'Historical and corrected input latency samplers have different inclusion rules; no matched input latency improvement is claimed.',
        'Quality is a measured representative-view result, not a universal artifact bound; explicit 16-bit display has greater overlap error.',
        'Dense moving exact views can pay a small optional compaction cost; small scenes avoid compaction.',
        'Logical reservations are not measured physical driver memory.',
        'No new native/installed preview/thumbnail, macOS/Ubuntu/other browser/GPU/hosting qualification.',
        'No external deployment/publication or native/profile migration.'],
    'remainingFollowUps':['Matched immutable PlayCanvas/COLMAPView head-to-head workloads.',
        'Adaptive render resolution/overdraw for large dense views, with its own image/query contract review.',
        'Existing dense GL map fragment cancellation, optional scratch eviction and bounded initial program preparation.',
        'Independent other-browser/OS/GPU/hosting qualification.']}
print(json.dumps(save('validation.json',value),indent=2))
