import frameSource from './frame.wgsl?raw';
import sortSource from './sort.wgsl?raw';
import visibleSource from './visibleOrder.wgsl?raw';
import { planFastOrder } from './fastOrderLayout';
import type { SortPrecision } from '../sortPrecision';
import type { GaussianRenderer, GpuScene } from './renderer';

const entries=['countVisible','publishVisible','scatterVisible','generateVisible'] as const;
type Pipelines=Record<typeof entries[number],GPUComputePipeline>;
type Stage={pipeline:GPUComputePipeline;group:GPUBindGroup;x:number;y?:number;indirectOffset?:number};
const preparations=new WeakMap<GaussianRenderer,Promise<Pipelines>>();
async function prepare(renderer:GaussianRenderer):Promise<Pipelines> {
  let pending=preparations.get(renderer);
  if(!pending) {
    pending=renderer.checkedAllocation(()=>{
      const visible=renderer.device.createShaderModule({label:'Stable visible source IDs',code:frameSource+visibleSource});
      const sort=renderer.device.createShaderModule({label:'Visible source depth keys',code:frameSource+sortSource});
      const task=Promise.all(entries.map(async entryPoint=>[entryPoint,await renderer.device.createComputePipelineAsync({
        label:`Visible order ${entryPoint}`,layout:'auto',compute:{module:entryPoint==='generateVisible'?sort:visible,entryPoint},
      })] as const));
      void task.catch(()=>undefined);return{task};
    },async value=>{await value.task.catch(()=>undefined);}).then(async value=>Object.fromEntries(await value.task) as Pipelines);
    preparations.set(renderer,pending);
  }
  try {const result=await pending;renderer.requireScene();return result;}
  catch(error){if(preparations.get(renderer)===pending)preparations.delete(renderer);throw error;}
}

/** Encodes only. The renderer submits; the scene joins retirement and owns credit.
 * Separate compact pairs keep exact multi-stage queries stable between displays. */
export class FastOrder {
  private disposed=false;
  private readonly visibility:Stage[];
  private readonly generate:Stage;
  private readonly passes:Stage[][]=[];
  private readonly parameters:GPUBuffer;
  private readonly compactPairs:GPUBuffer;
  private readonly visibleSources:GPUBuffer;
  private readonly sourceSplats:GPUBuffer;
  readonly indirect:GPUBuffer;
  readonly drawGroup:GPUBindGroup;
  constructor(renderer:GaussianRenderer,readonly allocationBytes:number,private readonly buffers:GPUBuffer[],
    private readonly release:()=>void,scene:GpuScene,pipelines:Pipelines,layout:ReturnType<typeof planFastOrder>) {
    const device=renderer.device;
    const extra=Object.fromEntries(Object.entries(layout.sizes).map(([name,size])=>{
      let usage=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC;
      if(name==='indirect')usage|=GPUBufferUsage.INDIRECT;
      if(name==='parameters')usage|=GPUBufferUsage.UNIFORM;
      if(name==='visibilityParameters')usage=GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST;
      const buffer=device.createBuffer({label:`Fast depth ${name}`,size,usage});buffers.push(buffer);return[name,buffer];
    })) as Record<keyof typeof layout.sizes,GPUBuffer>;
    device.queue.writeBuffer(extra.visibilityParameters,0,new Uint32Array([scene.count,layout.groups,layout.blocks,0]));
    this.indirect=extra.indirect;
    this.parameters=extra.parameters;this.compactPairs=extra.compactA;this.visibleSources=extra.visible;this.sourceSplats=scene.buffers.splats;
    const bind=(pipeline:GPUComputePipeline,bindings:[number,GPUBuffer|GPUBufferBinding][])=>device.createBindGroup({
      layout:pipeline.getBindGroupLayout(0),entries:bindings.map(([binding,resource])=>({binding,resource:'buffer' in resource?resource:{buffer:resource}})),
    });
    const stage=(pipeline:GPUComputePipeline,bindings:[number,GPUBuffer|GPUBufferBinding][],x:number,y=1,indirectOffset?:number):Stage=>
      ({pipeline,group:bind(pipeline,bindings),x,y,indirectOffset});
    const b=scene.buffers,p=renderer.pipelines;
    this.visibility=[
      stage(pipelines.countVisible,[[0,renderer.frame],[1,b.projected],[2,b.ranks],[3,extra.visibleCounts]],layout.groups),
      stage(p.local,[[0,extra.visibilityParameters],[1,extra.visibleCounts],[2,extra.visibleOffsets],[3,extra.visibleSums]],layout.blocks),
      stage(p.blocks,[[0,extra.visibilityParameters],[1,extra.visibleSums],[2,extra.visibleBlocks],[3,extra.visibleTotal]],1),
      stage(pipelines.publishVisible,[[5,extra.indirect],[6,extra.parameters],[9,extra.visibleTotal]],1),
      stage(pipelines.scatterVisible,[[0,renderer.frame],[2,b.ranks],[4,extra.visible],[7,extra.visibleOffsets],[8,extra.visibleBlocks]],layout.groups),
    ];
    this.generate=stage(pipelines.generateVisible,[[0,{buffer:extra.parameters,offset:0,size:16}],[3,extra.compactA],
      [8,b.splats],[9,b.states],[10,renderer.frame],[11,scene.previewMask('transformBase')],[12,extra.visible]],0,1,32);
    this.drawGroup=renderer.bind(renderer.raster,[[0,renderer.frame],[4,extra.compactA],[7,b.projected]]);
    let input=extra.compactA,output=extra.compactB;
    for(let i=0;i<8;i++) {
      const parameter:GPUBufferBinding={buffer:extra.parameters,offset:i*256,size:16};
      this.passes.push([
        stage(p.rank,[[0,parameter],[1,input],[2,b.ranks],[4,b.counts]],0,1,32),
        stage(p.local,[[0,parameter],[1,b.counts],[2,b.groupOffsets],[3,b.groupSums]],0,1,48),
        stage(p.blocks,[[0,parameter],[1,b.groupSums],[2,b.blockOffsets],[3,b.binTotals]],0,1,64),
        stage(p.bins,[[1,b.binTotals],[2,b.binOffsets]],1),
        stage(p.scatter,[[0,parameter],[1,input],[2,b.ranks],[3,output],[5,b.groupOffsets],[6,b.blockOffsets],[7,b.binOffsets]],0,1,32),
      ]);
      [input,output]=[output,input];
    }
  }
  stageSources(renderer:GaussianRenderer,states:GPUBuffer,transformTargets:GPUBuffer) {
    return renderer.bind(this.generate.pipeline,[[0,this.parameters],[3,this.compactPairs],[8,this.sourceSplats],
      [9,states],[10,renderer.frame],[11,transformTargets],[12,this.visibleSources]]);
  }
  publishSources(group:GPUBindGroup) {this.generate.group=group;}
  encode(encoder:GPUCommandEncoder,precision:SortPrecision) {
    if(this.disposed)throw new Error('The compact depth order was retired.');
    const pass=encoder.beginComputePass({label:'Compact stable depth sort'});
    const dispatch=(stage:Stage)=>{
      pass.setPipeline(stage.pipeline);pass.setBindGroup(0,stage.group);
      if(stage.indirectOffset!==undefined)pass.dispatchWorkgroupsIndirect(this.indirect,stage.indirectOffset);
      else pass.dispatchWorkgroups(stage.x,stage.y??1);
    };
    for(const stage of this.visibility)dispatch(stage);
    dispatch(this.generate);
    for(let i=(32-precision)/4;i<8;i++)for(const stage of this.passes[i])dispatch(stage);
    pass.end();
  }
  dispose(){if(this.disposed)return;this.disposed=true;for(const buffer of this.buffers)buffer.destroy();this.release();}
}
export async function allocateFastOrder(renderer:GaussianRenderer,scene:GpuScene):Promise<FastOrder|undefined> {
  const limits=renderer.device.limits;
  if(scene.count<2048||!renderer.admitSortScratch||!(limits.maxComputeWorkgroupStorageSize>=1024))return;
  const layout=planFastOrder(scene.count);
  if(Object.values(layout.sizes).some(size=>size>limits.maxBufferSize||size>limits.maxStorageBufferBindingSize))return;
  let credit:(()=>void)|undefined,released=false;const buffers:GPUBuffer[]=[];
  const release=()=>{if(!released){released=true;credit?.();}};
  try {
    credit=renderer.admitSortScratch(layout.bytes);const pipelines=await prepare(renderer);renderer.requireScene(scene);
    const result=await renderer.checkedAllocation(()=>new FastOrder(renderer,layout.bufferBytes,buffers,release,scene,pipelines,layout),value=>value.dispose());
    renderer.requireScene(scene);return result;
  }catch{
    if(buffers.length)await renderer.device.queue.onSubmittedWorkDone().catch(()=>undefined);
    for(const buffer of buffers)buffer.destroy();release();return;
  }
}
