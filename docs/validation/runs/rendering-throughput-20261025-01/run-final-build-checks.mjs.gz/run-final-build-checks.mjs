import {readFileSync,writeFileSync,openSync,closeSync} from 'node:fs';
import {resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
const phase=resolve('.build/rendering-throughput-20261025-01'),statuses=[];
for(const [name,backend,command] of [
  ['sdk-browser',null,['test','--config','playwright.engine.config.ts','--reporter=json']],
  ['final-fast-order',null,['test','--project','spec:fast-order.spec.ts','--project','spec:display-policy.spec.ts','--reporter=json']],
  ['production-webgl2','webgl2',['test','--config','.build/rendering-throughput-20261025-01/production.config.ts']],
  ['production-webgpu','webgpu',['test','--config','.build/rendering-throughput-20261025-01/production.config.ts']],
]) {
  const env={...process.env,PLAYWRIGHT_JSON_OUTPUT_FILE:resolve(phase,name+'.json')};
  if(backend)env.SPLATVIEW_TEST_BACKEND=backend;else delete env.SPLATVIEW_TEST_BACKEND;
  const log=openSync(resolve(phase,name+'.log'),'w');console.log('Starting',name);
  const result=spawnSync(process.execPath,[resolve('node_modules/@playwright/test/cli.js'),...command],{env,stdio:['ignore',log,log]});closeSync(log);
  statuses.push({name,command:['node','node_modules/@playwright/test/cli.js',...command],backend,exitCode:result.status,error:result.error?.message});
  writeFileSync(resolve(phase,'final-browser-run-status.json'),JSON.stringify(statuses,null,2)+'\n');
  console.log('Finished',name,result.status);if(result.status!==0)process.exit(result.status??1);
}
