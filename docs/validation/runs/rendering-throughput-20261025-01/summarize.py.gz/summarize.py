import base64
import json
from pathlib import Path
from statistics import median

PHASE = Path(__file__).resolve().parent


def read(name):
    return json.loads((PHASE / name).read_text(encoding='utf-8-sig'))


def attachments(value, name):
    if isinstance(value, dict):
        for a in value.get('attachments', []):
            if a['name'] == name:
                yield json.loads(base64.b64decode(a['body'])) if 'body' in a else json.loads(Path(a['path']).read_text())
        for v in value.values():
            yield from attachments(v, name)
    elif isinstance(value, list):
        for v in value:
            yield from attachments(v, name)


def summary(values):
    values = sorted(values)
    return {'samples': len(values), 'medianMs': median(values), 'p95Ms': values[min(len(values)-1, int(len(values)*.95))]}


def throughput(report):
    result = {}
    for mode in ['sorted', 'steady']:
        for backend in ['webgpu', 'webgl2']:
            values = [v for v in attachments(report, f'display-throughput-{mode}.json') if v['backend'] == backend]
            intervals = [b['submittedMs']-a['submittedMs'] for v in values for a, b in zip(v['rows'], v['rows'][1:])]
            result[f'{backend}/{mode}'] = {'repetitions': len(values), 'rows': [len(v['rows']) for v in values],
                'submissionInterval': summary(intervals), 'maximumPending': max(row['pending'] for v in values for row in v['rows'])}
    return result


before, after = read('baseline.json'), read('performance-render-only.json')
assert all(r['stats']['unexpected'] == r['stats']['flaky'] == r['stats']['skipped'] == 0 for r in [before, after])
precision = list(attachments(after, 'precision-profile.json'))
quality = {}
for backend in ['webgpu', 'webgl2']:
    values = [v for v in precision if v['backend'] == backend]
    pixels = [q for v in values for q in v['displayQuality']]
    quality[backend] = {'views': len(pixels), 'minimumPsnrDb': min(v['psnr'] for v in pixels),
        'maximumMeanAbsoluteRgb': max(v['meanAbsoluteRgb'] for v in pixels), 'maximumAbsoluteRgb': max(v['maxRgb'] for v in pixels)}

gpu = []
for v in attachments(after, 'gpu-depth-pass-timestamps.json'):
    gpu.append({'count': v['count'], 'visibility': v['visibility'], 'compactionAvailable': v['fastAvailable'],
        'gpuPassMediansMs': {mode: {stage: median(samples) for stage, samples in stages.items()} for mode, stages in v['samples'].items()},
        'summedPassMedianMs': {mode: sum(median(samples) for samples in stages.values()) for mode, stages in v['samples'].items()},
        'scope': v['scope']})

input_times = {}
for label, report in [('historicalSubmitObservedSampler', before), ('shippingPostInputDrawSampler', read('input-fences-qualified.json'))]:
    values = list(attachments(report, 'app-input-completion.json'))
    input_times[label] = {backend: summary([s['inputToCompletionMs'] for v in values if v['backend'] == backend for s in v['samples']]) for backend in ['webgpu', 'webgl2']}

result = {'scope': 'Historical before/after queue/fence wall clocks; measured-source interleaved GPU implementation variants. Physical presentation FPS unavailable.',
    'inputComparisonLimit': 'The shipping sampler requires CPU draw start after input and accepts actual captured display fences during camera advance. Historical sampler used submit-observed time and rejected camera-stale observation. These latency summaries are not a matched improvement claim.',
    'throughput': {'baseline': throughput(before), 'final': throughput(after)}, 'appInputCompletion': input_times,
    'quality24': quality, 'gpuImplementationVariants': gpu}
(PHASE / 'performance-summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2))
