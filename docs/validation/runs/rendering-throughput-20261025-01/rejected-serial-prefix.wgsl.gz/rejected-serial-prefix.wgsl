// Stable source-ID compaction. Accept exactly the existing projector's flag.
@group(0) @binding(0) var<uniform> frame:Frame;
@group(0) @binding(1) var<storage,read> projected:array<Projected>;
@group(0) @binding(2) var<storage,read_write> ranks:array<u32>;
@group(0) @binding(3) var<storage,read_write> counts:array<u32>;
@group(0) @binding(4) var<storage,read_write> visible:array<u32>;
@group(0) @binding(5) var<storage,read_write> indirect:array<u32>;
struct Dispatch {count:u32,groups:u32,blocks:u32,digit:u32}
@group(0) @binding(6) var<storage,read_write> pass0:Dispatch;
@group(0) @binding(7) var<storage,read_write> pass1:Dispatch;
@group(0) @binding(8) var<storage,read_write> pass2:Dispatch;
@group(0) @binding(9) var<storage,read_write> pass3:Dispatch;
var<workgroup> prefix:array<u32,256>;
@compute @workgroup_size(256)
fn countVisible(@builtin(global_invocation_id) thread:vec3<u32>,@builtin(local_invocation_index) lane:u32,@builtin(workgroup_id) group:vec3<u32>) {
  let i=thread.x; var accepted=false;
  if(i<frame.flags.x) { accepted=projected[i].center.w!=0.0; }
  prefix[lane]=select(0u,1u,accepted); workgroupBarrier();
  for(var step=1u;step<256u;step*=2u) {
    let value=prefix[lane]; var previous=0u;
    if(lane>=step) { previous=prefix[lane-step]; }
    workgroupBarrier(); prefix[lane]=value+previous; workgroupBarrier();
  }
  if(i<frame.flags.x) { ranks[i]=select(0xffffffffu,prefix[lane]-1u,accepted); }
  if(lane==255u) { counts[group.x+1u]=prefix[255]; }
}
@compute @workgroup_size(1)
fn visibleOffsets() {
  var total=0u;
  for(var group=1u;group<=(frame.flags.x+255u)/256u;group++) {
    let count=counts[group]; counts[group]=total; total+=count;
  }
  counts[0]=total;
  let groups=(total+255u)/256u; let blocks=(groups+255u)/256u;
  pass0=Dispatch(total,groups,blocks,0u); pass1=Dispatch(total,groups,blocks,8u);
  pass2=Dispatch(total,groups,blocks,16u); pass3=Dispatch(total,groups,blocks,24u);
  // Indexed draw at byte 0. Dispatch records at bytes 32, 48 and 64.
  indirect[0]=6u; indirect[1]=total; indirect[2]=0u; indirect[3]=0u; indirect[4]=0u;
  indirect[8]=groups; indirect[9]=1u; indirect[10]=1u;
  indirect[12]=blocks; indirect[13]=256u; indirect[14]=1u;
  indirect[16]=256u; indirect[17]=1u; indirect[18]=1u;
}
@compute @workgroup_size(256)
fn scatterVisible(@builtin(global_invocation_id) thread:vec3<u32>) {
  let i=thread.x; if(i<frame.flags.x && ranks[i]!=0xffffffffu) { visible[counts[i/256u+1u]+ranks[i]]=i; }
}
