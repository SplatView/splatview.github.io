# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fill.spec.ts >> Fill App workflows >> view, tool, history and explicit Fill option changes expire completed tolerance ownership
- Location: e2e\fill.spec.ts:128:3

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Open scene', exact: true })
Expected: enabled
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByRole('button', { name: 'Open scene', exact: true }) with timeout 15000ms
  - waiting for getByRole('button', { name: 'Open scene', exact: true })

```

```yaml
- alert:
  - heading "SplatView needs a reload" [level=1]
  - paragraph: Failed to fetch
  - button "Reload"
```

# Test source

```ts
  1   | import { expect, test, type Page } from './backend-test';
  2   | import { fixtureCenters } from './sceneCoordinates';
  3   | import { fillPly, fillPositions } from './fill-fixture';
  4   | import type {} from './fill-harness';
  5   | import { chooseSelectionTool } from './selectTool';
  6   | import { appIdle } from './app-idle';
  7   | 
  8   | const bytes = fillPly();
  9   | const panel = (page: Page) => page.getByRole('complementary', { name: 'Tools', exact: true });
  10  | const slider = (page: Page) => page.getByRole('slider', { name: 'Selection tolerance', exact: true });
  11  | const option = (page: Page, name: string) => panel(page).getByRole('group', { name: 'Options', exact: true }).getByRole('button', { name, exact: true });
  12  | async function setOption(page: Page, name: string, pressed: boolean) {
  13  |   const button = option(page, name);
  14  |   if (await button.getAttribute('aria-pressed') !== String(pressed)) await button.click();
  15  |   await expect(button).toHaveAttribute('aria-pressed', String(pressed));
  16  | }
  17  | async function ready(page: Page) { await expect(page.locator('.status.panel')).toHaveCount(0); }
  18  | async function selected(page: Page, count: number) {
  19  |   await expect(panel(page).locator('.model-stats')).toHaveText(new RegExp(`^${count.toLocaleString('en-US')}/[\\d,]+ splats \\| SH[0-3]$`)); await ready(page);
  20  | }
  21  | async function tolerance(page: Page, percent: number) {
  22  |   await slider(page).click({ button: 'right' });
  23  |   const exact = page.getByRole('spinbutton', { name: 'Tolerance percent', exact: true });
  24  |   await exact.fill(String(percent)); await exact.press('Enter'); await ready(page);
  25  | }
  26  | async function open(page: Page) {
> 27  |   await page.goto('/'); await expect(page.getByRole('button', { name: 'Open scene', exact: true })).toBeEnabled();
      |                                                                                                     ^ Error: expect(locator).toBeEnabled() failed
  28  |   await page.getByLabel('Open scene files').setInputFiles({ name: 'fill-opacity.ply', mimeType: 'application/octet-stream', buffer: Buffer.from(bytes) });
  29  |   await expect(page).toHaveTitle('fill-opacity.ply — SplatView');
  30  |   await page.mouse.move(640, 400); await expect(page.locator('main')).not.toHaveClass(/chrome-hidden/);
  31  |   await page.getByRole('button', { name: 'Tools', exact: true }).click();
  32  |   await chooseSelectionTool(page, 'Fill');
  33  |   await setOption(page, 'Visible only', false); await setOption(page, 'Include splat edges', false);
  34  | }
  35  | async function exportSelection(page: Page) {
  36  |   await page.getByRole('button', { name: 'Save scene', exact: true }).click();
  37  |   await page.getByLabel('Export format', { exact: true }).selectOption('5');
  38  |   await page.getByLabel('Export scope', { exact: true }).selectOption('1');
  39  |   const downloading = page.waitForEvent('download'); await page.getByRole('button', { name: 'Download', exact: true }).click();
  40  |   const stream = await (await downloading).createReadStream(), chunks: Buffer[] = [];
  41  |   for await (const chunk of stream!) chunks.push(Buffer.from(chunk));
  42  |   const rows = Buffer.concat(chunks).toString('utf8').trim().split(/\r?\n/).slice(1).map(row => row.split(',').slice(0, 3).map(Number));
  43  |   const ids = rows.map(row => fillPositions.findIndex(point => point.every((value, i) => Math.abs(value - row[i]) < 1e-5))).sort((a, b) => a - b);
  44  |   expect(ids).not.toContain(-1); await page.getByRole('button', { name: 'I have kept the file', exact: true }).click(); return ids;
  45  | }
  46  | 
  47  | test.describe('Fill App workflows', () => {
  48  |   test.beforeEach(async ({ page }) => { await open(page); });
  49  |   for (const operation of ['Replace', 'Add', 'Subtract', 'Intersect'] as const)
  50  |     test(`${operation} Fill grows and shrinks the connected opacity island in one Undo`, async ({ page }) => {
  51  |       const [center] = await fixtureCenters(page, bytes, fillPositions);
  52  |       if (operation !== 'Add') { await page.getByRole('button', { name: 'Select all', exact: true }).click(); await selected(page, 4); }
  53  |       await page.getByRole('button', { name: operation, exact: true }).click();
  54  |       // Ten displayed percent (.01 opacity difference) tolerates viewport/map
  55  |       // quantization while remaining below every other source-center gap.
  56  |       await tolerance(page, 10);
  57  |       await page.mouse.move(...center as [number, number]); await page.mouse.down(); await selected(page, operation === 'Add' ? 0 : 4);
  58  |       await page.mouse.up(); await selected(page, operation === 'Subtract' ? 3 : 1);
  59  |       await tolerance(page, 60); await selected(page, 2);
  60  |       await tolerance(page, 100); await selected(page, operation === 'Subtract' ? 1 : 3);
  61  |       expect(await exportSelection(page)).toEqual(operation === 'Subtract' ? [3] : [0, 1, 2]);
  62  |       await tolerance(page, 10); await selected(page, operation === 'Subtract' ? 3 : 1);
  63  |       expect(await exportSelection(page)).toEqual(operation === 'Subtract' ? [1, 2, 3] : [0]);
  64  |       await page.getByRole('button', { name: 'Undo', exact: true }).click(); await selected(page, operation === 'Add' ? 0 : 4);
  65  |       if (operation !== 'Add') { await page.getByRole('button', { name: 'Undo', exact: true }).click(); await selected(page, 0); }
  66  |       await expect(page.getByRole('button', { name: 'Undo', exact: true })).toBeDisabled(); await expect(page.getByRole('alert')).toHaveCount(0);
  67  |     });
  68  | 
  69  |   test('empty clicks preserve every Combine mask and the preceding completed Fill checkpoint', async ({ page }) => {
  70  |     await tolerance(page, 10);
  71  |     const [center] = await fixtureCenters(page, bytes, fillPositions); await page.mouse.click(...center as [number, number]); await selected(page, 1);
  72  |     for (const operation of ['Replace', 'Add', 'Subtract', 'Intersect']) {
  73  |       await page.getByRole('button', { name: operation, exact: true }).click(); await page.mouse.click(1100, 100); await selected(page, 1);
  74  |     }
  75  |     await tolerance(page, 100); await selected(page, 3); expect(await exportSelection(page)).toEqual([0, 1, 2]);
  76  |     await page.getByRole('button', { name: 'Undo', exact: true }).click(); await selected(page, 0);
  77  |     await expect(page.getByRole('button', { name: 'Undo', exact: true })).toBeDisabled(); await expect(page.getByRole('alert')).toHaveCount(0);
  78  |   });
  79  | 
  80  |   test('Fill rejects drags and cancelled presses while preserving the last adjustable click', async ({ page }) => {
  81  |     await tolerance(page, 10);
  82  |     const centers = await fixtureCenters(page, bytes, fillPositions); await page.mouse.click(...centers[0] as [number, number]); await selected(page, 1);
  83  |     for (const cancel of ['drag', 'blur', 'capture', 'escape'] as const) {
  84  |       await page.mouse.move(...centers[3] as [number, number]); await page.mouse.down(); await selected(page, 1);
  85  |       if (cancel === 'drag') await page.mouse.move(centers[3][0] + 6, centers[3][1]);
  86  |       else if (cancel === 'blur') await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  87  |       else if (cancel === 'capture') await page.getByLabel('SplatView scene').dispatchEvent('lostpointercapture');
  88  |       else await page.keyboard.press('Escape');
  89  |       await page.mouse.up(); await selected(page, 1);
  90  |       if (cancel !== 'escape') { await tolerance(page, 100); await selected(page, 3); await tolerance(page, 10); await selected(page, 1); }
  91  |       else { await chooseSelectionTool(page, 'Fill'); await tolerance(page, 100); await selected(page, 1); }
  92  |     }
  93  |     await page.getByRole('button', { name: 'Undo', exact: true }).click(); await selected(page, 0); await expect(page.getByRole('alert')).toHaveCount(0);
  94  |   });
  95  | 
  96  |   test('blur cancels a released pending Fill without expiring the preceding completed click', async ({ page }) => {
  97  |     await tolerance(page, 10);
  98  |     const centers = await fixtureCenters(page, bytes, fillPositions); await page.mouse.click(...centers[0] as [number, number]); await selected(page, 1);
  99  |     await page.evaluate(async () => {
  100 |       const url = performance.getEntriesByType('resource').find(entry => new URL(entry.name).pathname === '/src/app/selectionMaps.ts')?.name;
  101 |       if (!url) throw new Error('The actual document map owner module was not loaded.');
  102 |       const { DocumentSelectionMaps } = await import(/* @vite-ignore */ url);
  103 |       const original = DocumentSelectionMaps.prototype.request;
  104 |       let release!: () => void;
  105 |       const gate = new Promise<void>(resolve => { release = resolve; });
  106 |       const control = { entered: false, returned: false, release };
  107 |       (window as unknown as { fillReadback: typeof control }).fillReadback = control;
  108 |       DocumentSelectionMaps.prototype.request = async function(...args: unknown[]) {
  109 |         const map = await original.apply(this, args); DocumentSelectionMaps.prototype.request = original;
  110 |         control.entered = true; await gate; control.returned = true; return map;
  111 |       };
  112 |     });
  113 |     await page.mouse.click(...centers[3] as [number, number]);
  114 |     await page.waitForFunction(() => (window as unknown as { fillReadback: { entered: boolean } }).fillReadback.entered);
  115 |     await selected(page, 1); await expect(slider(page)).toBeEnabled();
  116 |     await tolerance(page, 100); await selected(page, 1);
  117 |     await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  118 |     await page.evaluate(() => (window as unknown as { fillReadback: { release(): void } }).fillReadback.release());
  119 |     await page.waitForFunction(() => (window as unknown as { fillReadback: { returned: boolean } }).fillReadback.returned);
  120 |     // Enter a different value: replacing an input's existing "100" with "100"
  121 |     // emits no DOM change and therefore would not request an amendment.
  122 |     await tolerance(page, 99); await selected(page, 3); expect(await exportSelection(page)).toEqual([0, 1, 2]);
  123 |     await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  124 |     await tolerance(page, 10); await selected(page, 1);
  125 |     await page.getByRole('button', { name: 'Undo', exact: true }).click(); await selected(page, 0); await expect(page.getByRole('alert')).toHaveCount(0);
  126 |   });
  127 | 
```