import type { ComputeStage } from './computeProtocol';
import { validateSortPrecision, type SortPrecision } from '../sortPrecision';

/** Deterministic worker sort. Selection/deletion flags never enter the key. */
export type ComputeCheckpoint = () => Promise<void>;
export type RadixScratch={keys:Uint32Array<ArrayBuffer>;input:Uint32Array<ArrayBuffer>;output:Uint32Array<ArrayBuffer>;histogram:Uint32Array<ArrayBuffer>};
export const createRadixScratch=(count:number):RadixScratch=>({keys:new Uint32Array(count),input:new Uint32Array(count),output:new Uint32Array(count),histogram:new Uint32Array(256)});
const f = Math.fround;
export function transformPoint(m: Float32Array, offset: number, x: number, y: number, z: number): [number,number,number,number] {
  const row = (r:number) => f(f(f(f(m[offset+r]*x)+f(m[offset+r+4]*y))+f(m[offset+r+8]*z))+m[offset+r+12]);
  return [row(0),row(1),row(2),row(3)];
}
export function floatDepthKey(depth: number) {
  const value=new Float32Array(1); value[0]=depth;
  const bits=new Uint32Array(value.buffer)[0];
  return (bits ^ ((bits & 0x80000000) ? 0xffffffff:0x80000000)) >>> 0;
}
export async function stableDepthOrder(packed: Float32Array, count: number, strideWords: number,
  frame: Float32Array, transformTargets: Uint8Array, checkpoint: ComputeCheckpoint, scratch?:RadixScratch, candidates?:Uint32Array,stage?:ComputeStage,precision:SortPrecision=32): Promise<Uint32Array<ArrayBuffer>> {
  validateSortPrecision(precision);
  count=candidates?.length??count;
  if(scratch && scratch.keys.length<count) throw new RangeError('Insufficient radix scratch.');
  const owned=scratch??createRadixScratch(count),flags=new Uint32Array(frame.buffer,frame.byteOffset,frame.length), keys=owned.keys;
  let input=owned.input.subarray(0,count), output=owned.output.subarray(0,count);
  const scalar=new Float32Array(1), bits=new Uint32Array(scalar.buffer), histogram=owned.histogram;
  for(let i=0;i<count;i++) {
    const id=candidates?candidates[i]:i,at=id*strideWords; let x=packed[at],y=packed[at+1],z=packed[at+2],w=1;
    if(flags[76] && (!flags[77] || (transformTargets[id]&1))) [x,y,z,w]=transformPoint(frame,60,x,y,z);
    scalar[0]=f(f(f(f(frame[2]*x)+f(frame[6]*y))+f(frame[10]*z))+f(frame[14]*w));
    keys[i]=(bits[0]^((bits[0]&0x80000000)?0xffffffff:0x80000000))>>>0; input[i]=i;
    if((i&8191)===8191) await checkpoint();
  }
  stage?.('depth-key-generation');
  for(let shift=32-precision;shift<32;shift+=8) {
    histogram.fill(0);
    for(let i=0;i<count;i++) { histogram[(keys[input[i]]>>>shift)&255]++; if((i&65535)===65535) await checkpoint(); }
    let sum=0; for(let i=0;i<256;i++) { const n=histogram[i]; histogram[i]=sum; sum+=n; }
    for(let i=0;i<count;i++) { const id=input[i]; output[histogram[(keys[id]>>>shift)&255]++]=id; if((i&65535)===65535) await checkpoint(); }
    [input,output]=[output,input]; await checkpoint(); stage?.(`radix-pass-${shift}`);
  }
  if(candidates) for(let i=0;i<count;i++) input[i]=candidates[input[i]];
  return input;
}
