//#region src/renderer/backend.ts
function e(e) {
	if (e !== "auto" && e !== "webgpu" && e !== "webgl2") throw RangeError("Invalid graphics backend.");
	return e;
}
var t = 0;
function n() {
	return ++t;
}
var r = /* @__PURE__ */ new WeakMap();
function i(e, t) {
	r.set(e, t);
}
function a(e) {
	return r.get(e);
}
//#endregion
//#region src/renderer/orderKey.ts
var o = [
	2,
	6,
	10,
	14
];
function s(e, t, n, r) {
	if (!e || e.sourceRevision !== n) return !1;
	for (let n = 0; n < 4; n++) if (e.bits[n] !== t[o[n]]) return !1;
	if (e.bits[4] !== t[76]) return !1;
	if (!t[76]) return !0;
	if (e.bits[5] !== t[77]) return !1;
	for (let n = 0; n < 16; n++) if (e.bits[6 + n] !== t[60 + n]) return !1;
	return !t[77] || e.transformTargets === r;
}
function c(e, t, n) {
	let r = /* @__PURE__ */ new Uint32Array(22);
	for (let t = 0; t < 4; t++) r[t] = e[o[t]];
	return r[4] = e[76], e[76] && (r[5] = e[77], r.set(e.subarray(60, 76), 6)), {
		sourceRevision: t,
		bits: r,
		transformTargets: e[76] && e[77] ? n : void 0
	};
}
//#endregion
//#region src/renderer/compactOrderKey.ts
var l = [
	...Array.from({ length: 32 }, (e, t) => t),
	36,
	37,
	59,
	...Array.from({ length: 18 }, (e, t) => 60 + t),
	79
];
function u(e, t, n) {
	return {
		revision: t,
		precision: n,
		bits: Uint32Array.from(l, (t) => e[t])
	};
}
function d(e, t, n, r) {
	return !!e && e.revision === n && e.precision >= r && l.every((n, r) => t[n] === e.bits[r]);
}
//#endregion
//#region src/renderer/sortPrecision.ts
function f(e) {
	if (e !== 16 && e !== 24 && e !== 32) throw RangeError("Sort precision must be 16, 24 or 32 bits.");
	return e;
}
//#endregion
//#region src/renderer/webgpu/frame.wgsl?raw
var p = "struct Frame {\n  view: mat4x4<f32>, projection: mat4x4<f32>, eyeDegree: vec4<f32>, viewport: vec4<f32>,\n  flags: vec4<u32>, gradeA: vec4<f32>, gradeB: vec4<f32>, gradeC: vec4<f32>, gradeD: vec4<f32>,\n  geometry: mat4x4<f32>, geometryFlags: vec4<u32>,\n}\nstruct Projected { center: vec4<f32>, axes: vec4<f32>, color: vec4<f32> }\n\n// Desktop processing.cpp opacity operation. Apply before alpha culling and\n// footprint support so boost can revive transparent records without re-sorting.\nfn previewOpacity(alpha: f32, state: u32, scale: f32, flags: u32) -> f32 {\n  if((flags&1u)==0u || ((flags&2u)!=0u && (state&1u)==0u)) { return alpha; }\n  if(scale<=1.0) { return clamp(alpha*scale,0.0,1.0); }\n  return clamp(alpha+(1.0-alpha)*(scale-1.0)/2.0,0.0,1.0);\n}\n", m = "// Stable sorted-pair compaction. Accept exactly the existing projector's flag.\n@group(0) @binding(0) var<uniform> frame:Frame;\n@group(0) @binding(1) var<storage,read> projected:array<Projected>;\n@group(0) @binding(2) var<storage,read_write> ranks:array<u32>;\n@group(0) @binding(3) var<storage,read_write> counts:array<u32>;\n@group(0) @binding(4) var<storage,read_write> visible:array<vec2<u32>>;\n@group(0) @binding(5) var<storage,read_write> indirect:array<u32>;\n@group(0) @binding(7) var<storage,read> offsets:array<u32>;\n@group(0) @binding(8) var<storage,read> blockOffsets:array<u32>;\n@group(0) @binding(9) var<storage,read> totalCount:array<u32>;\n@group(0) @binding(10) var<storage,read> ordered:array<vec2<u32>>;\nvar<workgroup> prefix:array<u32,256>;\n@compute @workgroup_size(256)\nfn countVisible(@builtin(global_invocation_id) thread:vec3<u32>,@builtin(local_invocation_index) lane:u32,@builtin(workgroup_id) group:vec3<u32>) {\n  let i=thread.x; var accepted=false;\n  if(i<frame.flags.x) { accepted=projected[ordered[i].y&0xffffffu].center.w!=0.0; }\n  prefix[lane]=select(0u,1u,accepted); workgroupBarrier();\n  for(var step=1u;step<256u;step*=2u) {\n    let value=prefix[lane]; var previous=0u;\n    if(lane>=step) { previous=prefix[lane-step]; }\n    workgroupBarrier(); prefix[lane]=value+previous; workgroupBarrier();\n  }\n  if(i<frame.flags.x) { ranks[i]=select(0xffffffffu,prefix[lane]-1u,accepted); }\n  if(lane==255u) { counts[group.x]=prefix[255]; }\n}\n@compute @workgroup_size(1)\nfn publishVisible() {\n  let total=totalCount[0];\n  indirect[0]=6u;indirect[1]=total;indirect[2]=0u;indirect[3]=0u;indirect[4]=0u;\n}\n@compute @workgroup_size(256)\nfn scatterVisible(@builtin(global_invocation_id) thread:vec3<u32>) {\n  let i=thread.x;\n  if(i<frame.flags.x && ranks[i]!=0xffffffffu) { visible[offsets[i/256u]+blockOffsets[i/65536u]+ranks[i]]=ordered[i]; }\n}\n", h = 1048576, g = class extends Error {}, _ = /* @__PURE__ */ new WeakMap(), v = /* @__PURE__ */ new WeakMap();
function y(e, t) {
	if (!Number.isSafeInteger(e) || !Number.isSafeInteger(t) || e < 0 || t < 0 || !Number.isSafeInteger(e * t)) throw new g("The requested allocation is too large.");
	return e * t;
}
function b(e) {
	if (!Number.isInteger(e) || e < 0 || e > 3) throw new g("Unsupported SH degree.");
	return 40 + 4 * Math.ceil(3 * (e + 1) ** 2 / 2);
}
function x(e, t) {
	return y(e, 144 + b(t) + 16 + 4 + 48 + 6) + y(Math.ceil(e / 256), 128) + 4 * h;
}
var S = class {
	limit;
	entries = /* @__PURE__ */ new Map();
	used = 0;
	peak = 0;
	identities = /* @__PURE__ */ new WeakMap();
	constructor(e) {
		if (this.limit = e, !Number.isSafeInteger(e) || e < 0) throw new g("Invalid memory budget.");
	}
	get usage() {
		return {
			bytes: this.used,
			peakBytes: this.peak,
			allocations: this.entries.size
		};
	}
	get categorySnapshot() {
		let e = {
			source: {
				bytes: 0,
				allocations: 0
			},
			decoded: {
				bytes: 0,
				allocations: 0
			},
			work: {
				bytes: 0,
				allocations: 0
			},
			history: {
				bytes: 0,
				allocations: 0
			},
			render: {
				bytes: 0,
				allocations: 0
			},
			image: {
				bytes: 0,
				allocations: 0
			},
			recovery: {
				bytes: 0,
				allocations: 0
			}
		};
		for (let t of this.entries.values()) e[t.category].bytes += t.bytes, e[t.category].allocations++;
		for (let t of Object.values(e)) Object.freeze(t);
		return Object.freeze(e);
	}
	get overageBytes() {
		return Math.max(0, this.used - this.limit);
	}
	owns(e, t) {
		let n = this.identities.get(e), r = n === void 0 ? void 0 : this.entries.get(n);
		return r !== void 0 && (t === void 0 || r.category === t);
	}
	reserve(e, t) {
		if (y(t, 1), t > this.limit - this.used) throw new g("This operation exceeds the available scene budget. Close a scene or load fewer splats.");
		let n = Symbol(e), r = {
			category: e,
			bytes: t
		};
		this.entries.set(n, r);
		let i = {
			live: !0,
			get bytes() {
				return r.bytes;
			}
		}, a = Object.freeze({});
		v.set(a, i), this.used += t, this.peak = Math.max(this.peak, this.used);
		let o = (() => {
			let e = this.entries.get(n);
			e && (this.used -= e.bytes, this.entries.delete(n), i.live = !1);
		});
		return this.identities.set(o, n), _.set(o, a), Object.defineProperty(o, "bytes", { get: () => this.entries.get(n)?.bytes ?? 0 }), o.resize = (e) => this.rebalance([{
			lease: o,
			bytes: e
		}]), o;
	}
	stage(e) {
		let t = /* @__PURE__ */ new Set(), n = e.map(({ lease: e, bytes: n }) => {
			y(n, 1);
			let r = this.identities.get(e), i = r && this.entries.get(r);
			if (!r || !i || t.has(r)) throw new g("Invalid memory reservation.");
			return t.add(r), {
				entry: i,
				bytes: n
			};
		}), r = this.used;
		for (let { entry: e } of n) r -= e.bytes;
		for (let { bytes: e } of n) r += e, y(r, 1);
		return {
			staged: n,
			next: r
		};
	}
	commit({ staged: e, next: t }) {
		for (let { entry: t, bytes: n } of e) t.bytes = n;
		this.used = t, this.peak = Math.max(this.peak, this.used);
	}
	rebalance(e) {
		let t = this.stage(e);
		if (t.next > this.limit && t.staged.some(({ entry: e, bytes: t }) => t > e.bytes)) throw new g("This operation exceeds the available scene budget.");
		this.commit(t);
	}
	retainObservedNativeHeap(e, t, n = []) {
		let r = this.stage([{
			lease: e,
			bytes: t
		}, ...n]);
		if (r.staged[0].entry.category !== "source" || t < r.staged[0].entry.bytes || r.staged.slice(1).some(({ entry: e, bytes: t }) => t > e.bytes)) throw new g("Invalid retained native heap reconciliation.");
		this.commit(r);
	}
	transferRetainedNativeCoverage(e, t, n) {
		let r = this.stage([{
			lease: e,
			bytes: t
		}, ...n]);
		if (r.staged[0].entry.category !== "source" || r.next > this.used) throw new g("A native coverage transfer cannot increase admitted memory.");
		this.commit(r);
	}
};
//#endregion
//#region src/renderer/webgpu/fastOrderLayout.ts
function C(e) {
	if (!Number.isSafeInteger(e) || e < 1 || e > 3e6) throw RangeError("Invalid fast-order count.");
	let t = Math.ceil(e / 256), n = Math.ceil(t / 256), r = {
		visibleCounts: y(t, 4),
		indirect: 20,
		compactA: y(e, 8),
		visibleOffsets: y(t, 4),
		visibleSums: y(n, 4),
		visibleBlocks: y(n, 4),
		visibleTotal: 4
	}, i = Object.values(r).reduce((e, t) => e + t, 0);
	return {
		groups: t,
		blocks: n,
		sizes: r,
		bufferBytes: i,
		bytes: y(i + 16384, 1)
	};
}
//#endregion
//#region src/renderer/webgpu/fastOrder.ts
var w = [
	"countVisible",
	"publishVisible",
	"scatterVisible"
], T = /* @__PURE__ */ new WeakMap();
async function E(e) {
	let t = T.get(e);
	t || (t = e.checkedAllocation(() => {
		let t = e.device.createShaderModule({
			label: "Stable visible draw order",
			code: p + m
		}), n = Promise.all(w.map(async (n) => [n, await e.device.createComputePipelineAsync({
			label: `Visible order ${n}`,
			layout: "auto",
			compute: {
				module: t,
				entryPoint: n
			}
		})]));
		return n.catch(() => void 0), { task: n };
	}, async (e) => {
		await e.task.catch(() => void 0);
	}).then(async (e) => Object.fromEntries(await e.task)), T.set(e, t));
	try {
		let n = await t;
		return e.requireScene(), n;
	} catch (n) {
		throw T.get(e) === t && T.delete(e), n;
	}
}
var D = class {
	allocationBytes;
	buffers;
	release;
	disposed = !1;
	stages;
	indirect;
	drawGroup;
	constructor(e, t, n, r, i, a, o) {
		this.allocationBytes = t, this.buffers = n, this.release = r;
		let s = e.device, c = Object.fromEntries(Object.entries(o.sizes).map(([e, t]) => {
			let r = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | (e === "indirect" ? GPUBufferUsage.INDIRECT : 0), i = s.createBuffer({
				label: `Fast depth ${e}`,
				size: t,
				usage: r
			});
			return n.push(i), [e, i];
		}));
		this.indirect = c.indirect;
		let l = (t, n, r) => ({
			pipeline: t,
			group: e.bind(t, n),
			x: r
		}), u = i.buffers, d = e.pipelines;
		this.stages = [
			l(a.countVisible, [
				[0, e.frame],
				[1, u.projected],
				[2, u.ranks],
				[3, c.visibleCounts],
				[10, i.ordered]
			], o.groups),
			l(d.local, [
				[0, i.params[0]],
				[1, c.visibleCounts],
				[2, c.visibleOffsets],
				[3, c.visibleSums]
			], o.blocks),
			l(d.blocks, [
				[0, i.params[0]],
				[1, c.visibleSums],
				[2, c.visibleBlocks],
				[3, c.visibleTotal]
			], 1),
			l(a.publishVisible, [[5, c.indirect], [9, c.visibleTotal]], 1),
			l(a.scatterVisible, [
				[0, e.frame],
				[2, u.ranks],
				[4, c.compactA],
				[7, c.visibleOffsets],
				[8, c.visibleBlocks],
				[10, i.ordered]
			], o.groups)
		], this.drawGroup = e.bind(e.raster, [
			[0, e.frame],
			[4, c.compactA],
			[7, u.projected]
		]);
	}
	encode(e) {
		if (this.disposed) throw Error("The compact draw order was retired.");
		let t = e.beginComputePass({ label: "Compact visible draw order" });
		for (let e of this.stages) t.setPipeline(e.pipeline), t.setBindGroup(0, e.group), t.dispatchWorkgroups(e.x);
		t.end();
	}
	dispose() {
		if (!this.disposed) {
			this.disposed = !0;
			for (let e of this.buffers) e.destroy();
			this.release();
		}
	}
};
async function O(e, t) {
	let n = e.device.limits;
	if (t.count < 262144 || !e.admitSortScratch || !(n.maxComputeWorkgroupStorageSize >= 1024)) return;
	let r = C(t.count);
	if (Object.values(r.sizes).some((e) => e > n.maxBufferSize || e > n.maxStorageBufferBindingSize)) return;
	let i, a = !1, o = [], s, c = () => {
		a || (a = !0, i?.());
	};
	try {
		i = e.admitSortScratch(r.bytes);
		let n = await E(e);
		e.requireScene(t);
		let a = await e.checkedAllocation(() => s = new D(e, r.bufferBytes, o, c, t, n, r), (e) => e.dispose());
		return e.requireScene(t), a;
	} catch {
		if (s) s.dispose();
		else for (let e of o) e.destroy();
		c();
		return;
	}
}
//#endregion
//#region src/renderer/webgpu/splats.wgsl?raw
var k = "@group(0) @binding(0) var<uniform> frame: Frame;\n@group(0) @binding(1) var<storage, read> splats: array<u32>;\n@group(0) @binding(2) var<storage, read> states: array<u32>;\n@group(0) @binding(3) var<storage, read_write> projectedOut: array<Projected>;\n@group(0) @binding(4) var<storage, read> order: array<vec2<u32>>;\n@group(0) @binding(5) var<uniform> query: vec4<f32>;\n@group(0) @binding(6) var<storage, read_write> queryOutput: array<u32>;\n@group(0) @binding(7) var<storage, read> projected: array<Projected>;\n// Session eligibility is independent of canonical selection/highlight states.\n// Channels without a retained selected-edit owner alias canonical states.\n@group(0) @binding(8) var<storage, read> colorTargets: array<u32>;\n@group(0) @binding(9) var<storage, read> transformTargets: array<u32>;\n@group(0) @binding(10) var<storage, read> opacityTargets: array<u32>;\n\nfn coefficient(address: u32, i: u32) -> f32 {\n  let values = unpack2x16float(splats[address + 10u + i / 2u]);\n  return values[i % 2u];\n}\nfn coefficients(address: u32, i: u32) -> vec3<f32> {\n  return vec3(coefficient(address,3u*i),coefficient(address,3u*i+1u),coefficient(address,3u*i+2u));\n}\n// Frozen desktop support bounds, with its interpolation margin. The final\n// alpha cutoff still decides whether a sample contributes.\nfn opacitySupport(opacity: f32) -> f32 {\n  if(opacity>=.2141082512) { return 9.0; }\n  if(opacity>=.0289764008) {\n    if(opacity>=.0787660238) { return select(7.0,8.0,opacity>=.1298632188); }\n    return select(5.0,6.0,opacity>=.0477740084);\n  }\n  if(opacity>=.0106598221) { return select(3.0,4.0,opacity>=.0175750755); }\n  return select(1.0,2.0,opacity>=.0064655090);\n}\nfn luma(v: vec3<f32>) -> f32 { return dot(v,vec3(.299,.587,.114)); }\nfn rotateColor(value: vec3<f32>) -> vec3<f32> {\n  var v = vec3(luma(value))+(value-vec3(luma(value)))*frame.gradeA.w;\n  if(frame.gradeD.z==0.0) { return v; }\n  let cs=cos(radians(frame.gradeD.z)); let sn=sin(radians(frame.gradeD.z));\n  return vec3(\n    dot(vec3(.299+.701*cs+.168*sn,.587-.587*cs+.330*sn,.114-.114*cs-.497*sn),v),\n    dot(vec3(.299-.299*cs-.328*sn,.587+.413*cs+.035*sn,.114-.114*cs+.292*sn),v),\n    dot(vec3(.299-.300*cs+1.250*sn,.587-.588*cs-1.050*sn,.114+.886*cs-.203*sn),v));\n}\nfn halfColor(v: vec3<f32>) -> vec3<f32> {\n  let clamped=clamp(v,vec3(-65504.0),vec3(65504.0));\n  return vec3(unpack2x16float(pack2x16float(clamped.xy)),unpack2x16float(pack2x16float(vec2(clamped.z,0.0))).x);\n}\nfn gammaChannel(value: f32, radius: f32) -> vec2<f32> {\n  let low=max(0.0,value-radius); let high=max(0.0,value+radius);\n  if(high<=0.0) { return vec2(value,1.0); }\n  if(high-low>high*.001) {\n    let lowPower=pow(low,frame.gradeA.z); let highPower=pow(high,frame.gradeA.z);\n    let gain=(highPower-lowPower)/(high-low); return vec2(lowPower+(value-low)*gain,gain);\n  }\n  let after=pow(value,frame.gradeA.z); return vec2(after,frame.gradeA.z*after/value);\n}\nfn color(address: u32, position: vec3<f32>, state: u32) -> vec3<f32> {\n  let direction=position-frame.eyeDegree.xyz;\n  let d=direction/max(length(direction),1e-20);\n  let x=d.x; let y=d.y; let z=d.z; let xx=x*x; let yy=y*y; let zz=z*z;\n  var b: array<f32,16>;\n  b[0]=0.2820947918;\n  b[1]=-0.4886025119*y; b[2]=0.4886025119*z; b[3]=-0.4886025119*x;\n  b[4]=1.0925484306*x*y; b[5]=-1.0925484306*y*z;\n  b[6]=0.3153915653*(2.0*zz-xx-yy); b[7]=-1.0925484306*x*z; b[8]=0.5462742153*(xx-yy);\n  b[9]=-0.5900435899*y*(3.0*xx-yy); b[10]=2.8906114426*x*y*z;\n  b[11]=-0.4570457995*y*(4.0*zz-xx-yy); b[12]=0.3731763326*z*(2.0*zz-3.0*xx-3.0*yy);\n  b[13]=-0.4570457995*x*(4.0*zz-xx-yy); b[14]=1.4453057213*z*(xx-yy); b[15]=-0.5900435899*x*(xx-3.0*yy);\n  let bands=u32(frame.eyeDegree.w)+1u; let count=bands*bands;\n  var result=vec3(.5);\n  if(frame.flags.z==0u || (frame.flags.w!=0u && (state&1u)==0u)) {\n    for(var j=0u;j<count;j++) { result+=b[j]*coefficients(address,j); }\n    return max(result,vec3(0.0));\n  }\n  let temperature=vec3(1.0+.3*frame.gradeB.y,1.0,1.0-.3*frame.gradeB.y);\n  var dc=coefficients(address,0u)*temperature+vec3(.05,-.1,.05)*frame.gradeB.z;\n  dc=(dc*frame.gradeA.x+vec3((frame.gradeA.x-1.0)*.5/b[0]))*frame.gradeA.y;\n  var gain=vec3(1.0);\n  if(frame.gradeA.z!=1.0) {\n    var energy=vec3(0.0);\n    for(var j=1u;j<count;j++) {\n      let v=(coefficients(address,j)*temperature*frame.gradeA.x)*frame.gradeA.y; energy+=v*v;\n    }\n    let radius=sqrt(energy*(f32(count-1u)*.07957747154594767));\n    let before=dc*b[0]+vec3(.5);\n    let red=gammaChannel(before.x,radius.x); let green=gammaChannel(before.y,radius.y); let blue=gammaChannel(before.z,radius.z);\n    gain=vec3(red.y,green.y,blue.y); dc=(vec3(red.x,green.x,blue.x)-vec3(.5))/b[0];\n  }\n  dc=rotateColor(dc);\n  var rgb=dc*b[0]+vec3(.5);\n  if(frame.gradeB.x!=1.0) {\n    let sat=max(rgb.x,max(rgb.y,rgb.z))-min(rgb.x,min(rgb.y,rgb.z));\n    rgb=clamp(vec3(luma(rgb))+(rgb-vec3(luma(rgb)))*(1.0+(1.0-sat)*(frame.gradeB.x-1.0)),vec3(0.0),vec3(1.0));\n    dc=(rgb-vec3(.5))/b[0];\n  }\n  let shadow=1.0-smoothstep(0.0,.5,luma(rgb)); let highlight=smoothstep(.5,1.0,luma(rgb));\n  dc*=1.0+frame.gradeB.w*shadow+frame.gradeC.x*highlight;\n  dc+=vec3(frame.gradeC.y*(1.0-frame.gradeC.y)/b[0]);\n  let phase=vec3(0.0,2.094395102393195,4.18879020478639);\n  dc+=.5*cos(vec3(radians(frame.gradeC.z))-phase)*frame.gradeC.w*shadow/b[0];\n  dc+=.5*cos(vec3(radians(frame.gradeD.x))-phase)*frame.gradeD.y*highlight/b[0];\n  result+=b[0]*halfColor(dc);\n  for(var k=1u;k<count;k++) {\n    let v=((coefficients(address,k)*temperature*frame.gradeA.x)*frame.gradeA.y)*gain;\n    result+=b[k]*halfColor(rotateColor(v));\n  }\n  return max(result,vec3(0.0));\n}\n@compute @workgroup_size(256)\nfn project(@builtin(global_invocation_id) thread: vec3<u32>) {\n  let i=thread.x; if(i>=frame.flags.x) { return; }\n  let state=states[i]; let address=i*frame.flags.y;\n  projectedOut[i]=Projected(vec4(0.0),vec4(0.0),vec4(0.0));\n  if((state&2u)!=0u) { return; }\n  var position=vec4(bitcast<f32>(splats[address]),bitcast<f32>(splats[address+1u]),bitcast<f32>(splats[address+2u]),1.0);\n  let opacity=previewOpacity(bitcast<f32>(splats[address+3u]),opacityTargets[i],frame.gradeD.w,frame.geometryFlags.w);\n  let transforming=frame.geometryFlags.x!=0u && (frame.geometryFlags.y==0u || (transformTargets[i]&1u)!=0u);\n  if(transforming) { position=frame.geometry*position; }\n  let p=frame.view*position;\n  if(p.z>=-.001 || opacity<.0039) { return; }\n  let c0=vec4(bitcast<f32>(splats[address+4u]),bitcast<f32>(splats[address+5u]),bitcast<f32>(splats[address+6u]),bitcast<f32>(splats[address+7u]));\n  let c1=vec2(bitcast<f32>(splats[address+8u]),bitcast<f32>(splats[address+9u]));\n  var covariance=mat3x3(vec3(c0.x,c0.y,c0.z),vec3(c0.y,c0.w,c1.x),vec3(c0.z,c1.x,c1.y));\n  if(transforming) {\n    let a=mat3x3(frame.geometry[0].xyz,frame.geometry[1].xyz,frame.geometry[2].xyz);\n    covariance=a*covariance*transpose(a);\n  }\n  let depth=-p.z;\n  let right=vec3(frame.view[0].x,frame.view[1].x,frame.view[2].x);\n  let up=vec3(frame.view[0].y,frame.view[1].y,frame.view[2].y);\n  let forward=vec3(frame.view[0].z,frame.view[1].z,frame.view[2].z);\n  let jx=frame.viewport.z/depth*(right+p.x/depth*forward);\n  let jy=frame.viewport.w/depth*(up+p.y/depth*forward);\n  let a=dot(jx,covariance*jx)+.3; let b=dot(jx,covariance*jy); let c=dot(jy,covariance*jy)+.3;\n  let middle=(a+c)*.5; let delta=sqrt(max(0.0,(a-c)*(a-c)*.25+b*b));\n  let l1=max(.01,middle+delta); let l2=max(.01,middle-delta);\n  var axis=select(vec2(0.0,1.0),vec2(1.0,0.0),a>=c);\n  if(abs(b)>.00001) { axis=normalize(vec2(b,l1-a)); }\n  let axis1=axis*min(1536.0,3.0*sqrt(l1)); let axis2=vec2(-axis.y,axis.x)*min(1536.0,3.0*sqrt(l2));\n  let clip=frame.projection*p;\n  if(clip.z<0.0 || clip.z>clip.w) { return; }\n  let extent=(abs(axis1)+abs(axis2)+vec2(1.0))*2.0/frame.viewport.xy*clip.w;\n  if(any(abs(clip.xy)>vec2(clip.w)+extent)) { return; }\n  let rgb=color(address,position.xyz,colorTargets[i]);\n  projectedOut[i]=Projected(vec4(clip.xy/clip.w,depth,1.0),vec4(axis1,axis2),vec4(rgb,opacity));\n}\nstruct VertexOut {\n  @builtin(position) position: vec4<f32>, @location(0) local: vec2<f32>,\n  @location(1) @interpolate(flat) color: vec4<f32>, @location(2) @interpolate(flat) state: u32,\n}\n@vertex\nfn vertex(@builtin(vertex_index) vertexIndex: u32, @builtin(instance_index) instance: u32) -> VertexOut {\n  let corners=array<vec2<f32>,4>(vec2(-1.0,-1.0),vec2(1.0,-1.0),vec2(-1.0,1.0),vec2(1.0,1.0));\n  let entry=order[instance].y; let gaussian=projected[entry&0xffffffu];\n  let corner=corners[vertexIndex]; let offset=gaussian.axes.xy*corner.x+gaussian.axes.zw*corner.y;\n  var result: VertexOut;\n  result.position=vec4(gaussian.center.xy+2.0*offset/frame.viewport.xy,0.0,1.0);\n  if(gaussian.center.w==0.0) { result.position=vec4(2.0,2.0,2.0,1.0); }\n  result.local=corner*3.0; result.color=gaussian.color; result.state=entry>>24u; return result;\n}\n@fragment\nfn fragment(input: VertexOut) -> @location(0) vec4<f32> {\n  let r=dot(input.local,input.local); if(r>min(9.0,opacitySupport(input.color.a)+.001)) { discard; }\n  let alpha=min(.99,input.color.a*exp(-.5*r)); if(alpha<1.0/255.0) { discard; }\n  var rgb=input.color.rgb;\n  if(frame.geometryFlags.z!=0u && (input.state&1u)!=0u) {\n    let tint=select(vec3(1.0,.72,.12),vec3(.49,.824,.573),frame.geometryFlags.z==2u);\n    rgb=mix(rgb,tint,.72);\n  }\n  return vec4(rgb*alpha,alpha);\n}\n@compute @workgroup_size(1)\nfn pick() {\n  var transmission=1.0; var strongest=0.0; var winner=0u; var depth=0.0; var opacity=0.0;\n  let minimum=select(0.0,1.0/255.0,query.z>0.0);\n  for(var reverse=0u;reverse<frame.flags.x;reverse++) {\n    let entry=order[frame.flags.x-1u-reverse].y;\n    let gaussian=projected[entry&0xffffffu]; if(gaussian.center.w==0.0) { continue; }\n    let center=vec2((gaussian.center.x+1.0)*.5*frame.viewport.x,(1.0-gaussian.center.y)*.5*frame.viewport.y);\n    let delta=vec2(query.x-center.x,center.y-query.y);\n    let local=3.0*vec2(dot(delta,gaussian.axes.xy)/dot(gaussian.axes.xy,gaussian.axes.xy),dot(delta,gaussian.axes.zw)/dot(gaussian.axes.zw,gaussian.axes.zw));\n    let r=dot(local,local); if(r>min(9.0,opacitySupport(gaussian.color.a)+.001)) { continue; }\n    let alpha=min(.99,gaussian.color.a*exp(-.5*r)); if(alpha<1.0/255.0) { continue; }\n    let weight=transmission*alpha;\n    // Distant centers still obscure eligible contributors behind them.\n    let eligible=query.z<=0.0 || dot(query.xy-center,query.xy-center)<=query.z*query.z;\n    if(eligible && weight>=minimum && weight>strongest) { strongest=weight; winner=(entry&0xffffffu)+1u; }\n    depth+=weight*gaussian.center.z; opacity+=weight; transmission*=1.0-alpha;\n    if(transmission<1e-5) { break; }\n  }\n  queryOutput[0]=winner; queryOutput[1]=bitcast<u32>(depth/max(opacity,1e-20));\n  queryOutput[2]=bitcast<u32>(opacity); queryOutput[3]=bitcast<u32>(strongest);\n}\n", A = "struct Dispatch { count: u32, groups: u32, blocks: u32, digit: u32 }\nconst RADIX_BINS:u32=16u;\nconst RADIX_MASK_WORDS:u32=128u;\n@group(0) @binding(0) var<uniform> params: Dispatch;\n@group(0) @binding(1) var<storage, read> input: array<vec2<u32>>;\n@group(0) @binding(2) var<storage, read_write> ranks: array<u32>;\n@group(0) @binding(3) var<storage, read_write> output: array<vec2<u32>>;\n@group(0) @binding(4) var<storage, read_write> counts: array<u32>;\n@group(0) @binding(5) var<storage, read> groupOffsets: array<u32>;\n@group(0) @binding(6) var<storage, read> blockOffsets: array<u32>;\n@group(0) @binding(7) var<storage, read> binOffsets: array<u32>;\n@group(0) @binding(8) var<storage, read> splats: array<u32>;\n@group(0) @binding(9) var<storage, read> states: array<u32>;\n@group(0) @binding(10) var<uniform> frame: Frame;\n@group(0) @binding(11) var<storage, read> transformTargets: array<u32>;\nvar<workgroup> masks: array<atomic<u32>,RADIX_MASK_WORDS>;\nfn depthEntry(i:u32)->vec2<u32> {\n  let address=i*frame.flags.y;\n  var p=vec4(bitcast<f32>(splats[address]),bitcast<f32>(splats[address+1u]),bitcast<f32>(splats[address+2u]),1.0);\n  let state=states[i];\n  if(frame.geometryFlags.x!=0u && (frame.geometryFlags.y==0u || (transformTargets[i]&1u)!=0u)) { p=frame.geometry*p; }\n  let depth=(frame.view*p).z; let bits=bitcast<u32>(depth);\n  let key=bits^select(0x80000000u,0xffffffffu,(bits&0x80000000u)!=0u);\n  return vec2(key,i|(state<<24u));\n}\n@compute @workgroup_size(256)\nfn generate(@builtin(global_invocation_id) thread: vec3<u32>) {\n  let i=thread.x; if(i<params.count) { output[i]=depthEntry(i); }\n}\n@compute @workgroup_size(256)\nfn rank(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {\n  for(var word=lane;word<RADIX_MASK_WORDS;word+=256u) { atomicStore(&masks[word],0u); } workgroupBarrier();\n  let i=group.x*256u+lane; var bin=0u;\n  if(i<params.count) { bin=(input[i].x>>params.digit)&(RADIX_BINS-1u); atomicOr(&masks[bin*8u+lane/32u],1u<<(lane%32u)); }\n  workgroupBarrier();\n  if(i<params.count) {\n    var localRank=countOneBits(atomicLoad(&masks[bin*8u+lane/32u])&((1u<<(lane%32u))-1u));\n    for(var w=0u;w<lane/32u;w++) { localRank+=countOneBits(atomicLoad(&masks[bin*8u+w])); }\n    ranks[i]=(bin<<8u)|localRank;\n  }\n  if(lane<RADIX_BINS) {\n    var total=0u; for(var w=0u;w<8u;w++) { total+=countOneBits(atomicLoad(&masks[lane*8u+w])); }\n    counts[lane*params.groups+group.x]=total;\n  }\n}\n@compute @workgroup_size(256)\nfn scatter(@builtin(global_invocation_id) thread: vec3<u32>) {\n  let i=thread.x; if(i>=params.count) { return; }\n  let bin=ranks[i]>>8u; let group=i/256u;\n  let at=binOffsets[bin]+blockOffsets[bin*params.blocks+group/256u]+groupOffsets[bin*params.groups+group]+(ranks[i]&255u);\n  output[at]=input[i];\n}\n", j = "struct Dispatch { count: u32, groups: u32, blocks: u32, digit: u32 }\nconst RADIX_BINS:u32=16u;\n@group(0) @binding(0) var<uniform> params: Dispatch;\n@group(0) @binding(1) var<storage, read> source: array<u32>;\n@group(0) @binding(2) var<storage, read_write> offsets: array<u32>;\n@group(0) @binding(3) var<storage, read_write> sums: array<u32>;\nvar<workgroup> values: array<u32,256>;\n@compute @workgroup_size(256)\nfn local(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {\n  let i=group.x*256u+lane; var value=0u;\n  if(i<params.groups) { value=source[group.y*params.groups+i]; }\n  values[lane]=value; workgroupBarrier();\n  for(var stride=1u;stride<256u;stride*=2u) {\n    var add=0u; if(lane>=stride) { add=values[lane-stride]; }\n    workgroupBarrier(); values[lane]+=add; workgroupBarrier();\n  }\n  if(i<params.groups) { offsets[group.y*params.groups+i]=values[lane]-value; }\n  if(lane==255u) { sums[group.y*params.blocks+group.x]=values[lane]; }\n}\n@compute @workgroup_size(256)\nfn blocks(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {\n  var value=0u; if(lane<params.blocks) { value=source[group.x*params.blocks+lane]; }\n  values[lane]=value; workgroupBarrier();\n  for(var stride=1u;stride<256u;stride*=2u) {\n    var add=0u; if(lane>=stride) { add=values[lane-stride]; }\n    workgroupBarrier(); values[lane]+=add; workgroupBarrier();\n  }\n  if(lane<params.blocks) { offsets[group.x*params.blocks+lane]=values[lane]-value; }\n  if(lane==255u) { sums[group.x]=values[lane]; }\n}\n@compute @workgroup_size(RADIX_BINS)\nfn bins(@builtin(local_invocation_index) lane: u32) {\n  let value=source[lane]; values[lane]=value; workgroupBarrier();\n  for(var stride=1u;stride<RADIX_BINS;stride*=2u) {\n    var add=0u; if(lane>=stride) { add=values[lane-stride]; }\n    workgroupBarrier(); values[lane]+=add; workgroupBarrier();\n  }\n  offsets[lane]=values[lane]-value;\n}\n", ee = "// Frozen Windows geometry.hlsl, with the native camera matrices and byte RGB.\n// The first 160 bytes intentionally share the Gaussian frame allocation.\nstruct GeometryFrame {\n  view: mat4x4<f32>, projection: mat4x4<f32>, eye: vec4<f32>, viewport: vec4<f32>,\n}\n@group(0) @binding(0) var<uniform> frame: GeometryFrame;\nstruct GeometryOutput {\n  @builtin(position) position: vec4<f32>,\n  @location(0) world: vec3<f32>,\n  @location(1) corner: vec2<f32>,\n  @location(2) color: vec3<f32>,\n}\n@vertex\nfn pointVertex(@location(0) position: vec3<f32>, @location(1) color: vec4<f32>,\n  @builtin(vertex_index) id: u32) -> GeometryOutput {\n  // The two triangles match the desktop triangle strip, with the same corners.\n  let corners = array<vec2<f32>, 6>(vec2(-1.,-1.), vec2(1.,-1.), vec2(-1.,1.),\n    vec2(-1.,1.), vec2(1.,-1.), vec2(1.,1.));\n  let corner = corners[id];\n  var clip = frame.projection * (frame.view * vec4(position, 1.));\n  clip.x += corner.x * frame.viewport.z * 2. / frame.viewport.x * clip.w;\n  clip.y += corner.y * frame.viewport.z * 2. / frame.viewport.y * clip.w;\n  return GeometryOutput(clip, position, corner, color.rgb);\n}\n@vertex\nfn meshVertex(@location(0) position: vec3<f32>, @location(1) color: vec4<f32>) -> GeometryOutput {\n  return GeometryOutput(frame.projection * (frame.view * vec4(position, 1.)), position, vec2(0.), color.rgb);\n}\n@fragment\nfn pointFragment(input: GeometryOutput) -> @location(0) vec4<f32> {\n  if (dot(input.corner, input.corner) > 1.) { discard; }\n  return vec4(input.color, 1.);\n}\n@fragment\nfn meshFragment(input: GeometryOutput) -> @location(0) vec4<f32> {\n  let normal = cross(dpdx(input.world), dpdy(input.world));\n  let lengthSquared = dot(normal, normal);\n  var lighting = 1.;\n  if (lengthSquared > 0.) {\n    lighting = .35 + .65 * abs(dot(normal * inverseSqrt(lengthSquared), normalize(vec3(.4,.7,.5))));\n  }\n  return vec4(input.color * lighting, 1.);\n}\n", te = [
	"layoutVersion",
	"kind",
	"vertexCount",
	"triangleCount",
	"vertexStride",
	"indexStride",
	"vertexBytes",
	"indexBytes",
	"revision",
	"contentRevision"
];
function M(e, t, n, r) {
	if (!Number.isSafeInteger(e) || Number(e) < t || Number(e) > n) throw new g(`Invalid geometry ${r}.`);
}
function ne(e) {
	if (!e || typeof e != "object" || Array.isArray(e) || Object.keys(e).sort().join(",") !== [...te].sort().join(",")) throw new g("Invalid geometry descriptor.");
	let t = e;
	if (t.layoutVersion !== 1 || t.kind !== 1 && t.kind !== 2 || t.vertexStride !== 16 || t.indexStride !== 4) throw new g("Unsupported geometry layout.");
	if (M(t.vertexCount, 1, 4294967295, "vertex count"), M(t.triangleCount, +(t.kind === 2), 1431655765, "triangle count"), t.kind === 1 && t.triangleCount !== 0) throw new g("Point clouds cannot contain triangle indices.");
	if (M(t.revision, 0, 2 ** 53 - 1, "revision"), M(t.contentRevision, 0, 2 ** 53 - 1, "content revision"), t.vertexBytes !== y(t.vertexCount, 16) || t.indexBytes !== y(t.triangleCount, 12)) throw new g("Invalid geometry channel byte count.");
	return {
		layoutVersion: 1,
		kind: t.kind,
		vertexCount: t.vertexCount,
		triangleCount: t.triangleCount,
		vertexStride: 16,
		indexStride: 4,
		vertexBytes: t.vertexBytes,
		indexBytes: t.indexBytes,
		revision: t.revision,
		contentRevision: t.contentRevision
	};
}
//#endregion
//#region src/renderer/webgpu/geometry.ts
var N = class {
	renderer;
	kind = "geometry";
	descriptor;
	vertices;
	indices;
	drawGroup;
	count;
	revision;
	contentRevision;
	retired = !1;
	pendingUploadBytes = 0;
	retirement;
	get deviceEpoch() {
		return this.renderer.deviceEpoch;
	}
	constructor(e, t) {
		if (this.renderer = e, this.descriptor = Object.freeze(ne(t)), this.count = this.descriptor.vertexCount, this.count > 1e7 || this.descriptor.triangleCount > 1e7) throw Error("This PLY geometry exceeds the native GPU preview budget.");
		this.revision = this.descriptor.revision, this.contentRevision = this.descriptor.contentRevision;
		let { vertexBytes: n, indexBytes: r, kind: i } = this.descriptor, { device: a } = e;
		if (n > a.limits.maxBufferSize || r > a.limits.maxBufferSize) throw Error("This PLY geometry exceeds the graphics device buffer limit.");
		let o = [];
		try {
			this.vertices = a.createBuffer({
				label: "Readonly PLY vertices",
				size: n,
				usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
			}), o.push(this.vertices), i === 2 && (this.indices = a.createBuffer({
				label: "Readonly PLY triangle indices",
				size: r,
				usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
			}), o.push(this.indices)), this.drawGroup = e.bind(i === 2 ? e.geometryMesh : e.geometryPoints, [[0, e.frame]]);
		} catch (e) {
			for (let e of o) e.destroy();
			throw e;
		}
	}
	get allocationBytes() {
		return this.vertices.size + (this.indices?.size ?? 0);
	}
	async upload(e, t, n, r, i, a) {
		if (this.renderer.requireScene(this), !e || !Number.isSafeInteger(t) || !Number.isSafeInteger(n) || t < 0 || n <= 0 || t > i || n > i - t || a.byteLength > 1048576 || a.byteLength !== y(n, r)) throw Error("Invalid readonly PLY geometry upload.");
		this.renderer.device.queue.writeBuffer(e, y(t, r), a), this.pendingUploadBytes += a.byteLength, this.pendingUploadBytes >= 16777216 && (await this.renderer.device.queue.onSubmittedWorkDone(), this.pendingUploadBytes = 0, this.renderer.requireScene(this));
	}
	uploadVertices(e, t, n) {
		return this.upload(this.vertices, e, t, 16, this.count, n);
	}
	uploadIndices(e, t, n) {
		return n.byteLength % 4 || new Uint32Array(n).some((e) => e >= this.count) ? Promise.reject(/* @__PURE__ */ Error("Invalid readonly PLY triangle index.")) : this.upload(this.indices, e, t, 4, this.descriptor.triangleCount * 3, n);
	}
	dispose() {
		return this.retirement ||= (this.retired = !0, (async () => {
			try {
				await this.renderer.device.queue.onSubmittedWorkDone();
			} catch {}
			this.vertices.destroy(), this.indices?.destroy(), await this.renderer.releaseGeometryScene(this);
		})()), this.retirement;
	}
}, re = "struct Sampling { viewport: vec2<u32>, grid: vec2<u32> }\nstruct Histogram { bins: array<atomic<u32>, 768> }\n@group(0) @binding(0) var image: texture_2d<f32>;\n@group(0) @binding(1) var<storage, read_write> histogram: Histogram;\n@group(0) @binding(2) var<uniform> sampling: Sampling;\n\n@compute @workgroup_size(16, 16)\nfn histogramSample(@builtin(global_invocation_id) id: vec3<u32>) {\n  if (any(id.xy >= sampling.grid)) { return; }\n  let center = (vec2<f32>(id.xy) + vec2<f32>(0.5)) *\n    vec2<f32>(sampling.viewport) / vec2<f32>(sampling.grid);\n  let pixel = min(vec2<u32>(center), sampling.viewport - vec2<u32>(1));\n  let color = vec3<u32>(round(clamp(textureLoad(image, vec2<i32>(pixel), 0).rgb,\n    vec3<f32>(0.0), vec3<f32>(1.0)) * 255.0));\n  atomicAdd(&histogram.bins[color.r], 1u);\n  atomicAdd(&histogram.bins[256u + color.g], 1u);\n  atomicAdd(&histogram.bins[512u + color.b], 1u);\n}\n", P = 768 * Uint32Array.BYTES_PER_ELEMENT, F = P * 4 + 16, I = class {
	device;
	deviceEpoch;
	callbacks;
	enabled = !1;
	disposed = !1;
	failed = !1;
	reportedFailureGeneration = -1;
	generation = 0;
	desired;
	sampled;
	resources;
	preparation;
	pending;
	retiring = /* @__PURE__ */ new Set();
	retirementWait;
	timer;
	lastStarted = -Infinity;
	constructor(e, t, n) {
		this.device = e, this.deviceEpoch = t, this.callbacks = n;
	}
	setEnabled(e) {
		this.disposed || e === this.enabled || (this.enabled = e, e ? this.failed && this.reportUnavailable() : this.reset());
	}
	reset() {
		if (this.generation++, this.desired = void 0, this.sampled = void 0, this.cancelTimer(), this.resources) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
	}
	cancelTimer() {
		this.timer !== void 0 && clearTimeout(this.timer), this.timer = void 0;
	}
	requestFrame() {
		if (this.disposed || !this.enabled || this.failed || !this.desired || this.pending || this.desired.identity === this.sampled) return;
		let e = Math.max(0, this.lastStarted + 200 - performance.now());
		e ? this.timer === void 0 && (this.timer = setTimeout(() => {
			this.timer = void 0, !this.disposed && this.enabled && !this.failed && !this.pending && this.desired && this.desired.identity !== this.sampled && this.callbacks.invalidate();
		}, e)) : (this.cancelTimer(), this.callbacks.invalidate());
	}
	fail(e) {
		if (!this.disposed && this.enabled && e === this.generation) {
			if (this.failed = !0, this.cancelTimer(), this.resources) {
				let e = this.resources;
				this.resources = void 0, this.retire(e);
			}
			this.reportUnavailable();
		}
	}
	reportUnavailable() {
		!this.disposed && this.enabled && this.reportedFailureGeneration !== this.generation && (this.reportedFailureGeneration = this.generation, this.callbacks.unavailable());
	}
	retire(e) {
		if (e.retirement) return e.retirement;
		let t = this.pending?.resources === e ? this.pending.task : void 0, n = (async () => {
			t && await t;
			try {
				await this.device.queue.onSubmittedWorkDone();
			} catch {} finally {
				e.readback.unmap(), e.bins.destroy(), e.readback.destroy(), e.params.destroy(), e.release?.();
			}
		})().finally(() => {
			this.retiring.delete(n);
		});
		return e.retirement = n, this.retiring.add(n), n;
	}
	prepare() {
		if (this.preparation || this.disposed || !this.enabled || this.failed) return;
		if (this.retiring.size || this.pending) {
			if (!this.retirementWait) {
				let e = this.pending?.task, t = Promise.allSettled([...this.retiring, ...e ? [e] : []]).then(() => {
					this.retirementWait === t && (this.retirementWait = void 0), this.requestFrame();
				});
				this.retirementWait = t;
			}
			return;
		}
		let e = this.generation, t = this.createResources().then(async (t) => {
			this.disposed || !this.enabled || e !== this.generation ? await this.retire(t) : (this.resources = t, this.requestFrame());
		}).catch(() => {
			this.fail(e);
		}).finally(() => {
			this.preparation === t && (this.preparation = void 0), e !== this.generation && this.requestFrame();
		});
		this.preparation = t;
	}
	async createResources() {
		let e = this.device, t = this.callbacks.admit(F), n = [], r, i;
		e.pushErrorScope("out-of-memory"), e.pushErrorScope("validation"), e.pushErrorScope("internal");
		try {
			let i = e.createShaderModule({
				label: "Rendered RGB histogram",
				code: re
			}), a = e.createComputePipeline({
				label: "Rendered RGB histogram",
				layout: "auto",
				compute: {
					module: i,
					entryPoint: "histogramSample"
				}
			}), o = (t, r, i) => {
				let a = e.createBuffer({
					label: t,
					size: r,
					usage: i
				});
				return n.push(a), a;
			};
			r = {
				pipeline: a,
				bins: o("Rendered RGB bins", P, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST),
				readback: o("Rendered RGB readback", P, GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST),
				params: o("Rendered RGB sampling grid", 16, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST),
				release: t
			};
		} catch (e) {
			i = e;
		}
		let a = [
			e.popErrorScope(),
			e.popErrorScope(),
			e.popErrorScope()
		];
		try {
			i ??= (await Promise.all(a)).find((e) => e !== null);
		} catch (e) {
			i ??= e;
		}
		if (i || !r) {
			try {
				await e.queue.onSubmittedWorkDone();
			} catch {} finally {
				for (let e of n) e.destroy();
				t?.();
			}
			throw i ?? /* @__PURE__ */ Error("Histogram allocation failed.");
		}
		return r;
	}
	async map(e) {
		let t = this.device;
		t.pushErrorScope("out-of-memory"), t.pushErrorScope("validation"), t.pushErrorScope("internal");
		let n, r;
		try {
			n = e.mapAsync(GPUMapMode.READ);
		} catch (e) {
			r = e;
		}
		let i = [
			t.popErrorScope(),
			t.popErrorScope(),
			t.popErrorScope()
		], a = await Promise.allSettled([n ?? Promise.resolve(), ...i]);
		for (let e of a) e.status === "rejected" ? r ??= e.reason : e.value && (r ??= e.value);
		if (r) throw r;
	}
	observe(e, t) {
		if (this.disposed || !this.enabled) return;
		if (this.failed) {
			this.reportUnavailable();
			return;
		}
		if (this.desired = t, t.identity === this.sampled) {
			this.cancelTimer();
			return;
		}
		if (!this.resources) {
			this.prepare();
			return;
		}
		if (this.pending) return;
		if (performance.now() - this.lastStarted < 200) {
			this.requestFrame();
			return;
		}
		this.cancelTimer();
		let n = this.resources, r = this.generation, i = this.device, a = Math.min(t.width, 256), o = Math.min(t.height, 144);
		if (a < 1 || o < 1) return;
		let s;
		i.pushErrorScope("out-of-memory"), i.pushErrorScope("validation"), i.pushErrorScope("internal");
		try {
			i.queue.writeBuffer(n.params, 0, new Uint32Array([
				t.width,
				t.height,
				a,
				o
			]));
			let r = i.createBindGroup({
				label: "Rendered RGB frame",
				layout: n.pipeline.getBindGroupLayout(0),
				entries: [
					{
						binding: 0,
						resource: e.createView()
					},
					{
						binding: 1,
						resource: { buffer: n.bins }
					},
					{
						binding: 2,
						resource: { buffer: n.params }
					}
				]
			}), s = i.createCommandEncoder({ label: "Rendered RGB histogram" });
			s.clearBuffer(n.bins);
			let c = s.beginComputePass({ label: "Rendered RGB histogram" });
			c.setPipeline(n.pipeline), c.setBindGroup(0, r), c.dispatchWorkgroups(Math.ceil(a / 16), Math.ceil(o / 16)), c.end(), s.copyBufferToBuffer(n.bins, 0, n.readback, 0, P), i.queue.submit([s.finish()]);
		} catch (e) {
			s = e;
		}
		let c = [
			i.popErrorScope(),
			i.popErrorScope(),
			i.popErrorScope()
		];
		this.lastStarted = performance.now(), this.sampled = t.identity;
		let l = (async () => {
			try {
				let e = await Promise.all(c);
				if (s ??= e.find((e) => e !== null), s) throw s;
				if (await this.map(n.readback), !this.disposed && this.enabled && r === this.generation && this.resources === n && this.desired?.identity === t.identity && !t.scene.retired) {
					let e = new Uint32Array(n.readback.getMappedRange().slice(0));
					this.callbacks.publish({
						bins: e,
						width: a,
						height: o,
						frame: t.frame,
						deviceEpoch: this.deviceEpoch
					}, t.scene);
				}
			} catch {
				this.fail(r);
			} finally {
				n.readback.unmap();
			}
		})().finally(() => {
			this.pending?.task === l && (this.pending = void 0), this.requestFrame();
		});
		this.pending = {
			resources: n,
			task: l
		};
	}
	async finish() {
		await this.preparation, await Promise.allSettled([...this.retiring, ...this.pending ? [this.pending.task] : []]);
	}
	dispose() {
		this.disposed || (this.enabled = !1, this.disposed = !0, this.reset());
	}
}, L = [
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
], R = [
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1
], z = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ new WeakSet(), B = (e) => {
	e.signal?.throwIfAborted(), e.current?.();
};
function V(e, t) {
	if (!Number.isSafeInteger(e) || !Number.isSafeInteger(t) || e < 1 || t < 1 || e > 16384 || t > 16384) throw RangeError("Invalid raw image dimensions.");
	let n = y(y(e, t), 4);
	if (n > 268435456) throw RangeError("The raw image exceeds the image budget.");
	return n;
}
function H(e) {
	if (!(!e.closing || e.borrowers || e.retired)) {
		e.retired = !0;
		try {
			let t = e.pixels.buffer;
			t.byteLength && structuredClone(t, { transfer: [t] });
		} finally {
			e.release();
		}
	}
}
function ae(e, t, n, r) {
	let i = V(e, t);
	if (!(n instanceof Uint8ClampedArray) || !(n.buffer instanceof ArrayBuffer) || n.byteOffset !== 0 || n.byteLength !== i || n.buffer.byteLength !== i || typeof r != "function" || ie.has(n.buffer)) throw TypeError("A tightly packed owned RGBA image is required.");
	let a = {
		pixels: n,
		release: r,
		borrowers: 0,
		closing: !1,
		retired: !1
	};
	ie.add(n.buffer);
	let o = Object.freeze({
		width: e,
		height: t,
		pixels: n,
		dispose() {
			a.closing = !0, H(a);
		}
	});
	return z.set(o, a), o;
}
async function oe(e, t) {
	let n = z.get(e);
	if (!n || n.closing || n.retired || e.pixels.byteLength !== V(e.width, e.height)) throw Error("The raw image owner is unavailable.");
	n.borrowers++;
	try {
		return await t(n.pixels);
	} finally {
		n.borrowers--, H(n);
	}
}
async function U(e, t, n, r = .95) {
	if (B(n), t !== "image/png" && t !== "image/jpeg") throw TypeError("Choose PNG or JPEG image output.");
	if (!Number.isFinite(r) || r < 0 || r > 1) throw RangeError("Invalid image quality.");
	return oe(e, async (i) => {
		B(n);
		let a = V(e.width, e.height), o = y(a * 2 + 65536, 1), s = n.admit(y(a * 2 + o, 1)), c, l;
		try {
			c = new OffscreenCanvas(e.width, e.height);
			let a = c.getContext("2d");
			if (!a) throw Error("Image encoding is unavailable.");
			a.putImageData(new ImageData(i, e.width, e.height), 0, 0), B(n);
			let s = await c.convertToBlob({
				type: t,
				quality: r
			});
			if (B(n), s.type !== t) throw Error("The browser returned a different image format.");
			if (!Number.isSafeInteger(s.size) || s.size < 1 || s.size > o) throw Error("The encoded image exceeds the image budget.");
			l = n.admit(s.size), B(n);
			let u = l;
			return l = void 0, Object.freeze({
				blob: s,
				dispose() {
					let e = u;
					u = void 0, e?.();
				}
			});
		} finally {
			c && (c.width = 0, c.height = 0), l?.(), s();
		}
	});
}
//#endregion
//#region src/renderer/webgpu/diagnostics.ts
var se = /* @__PURE__ */ "maxTextureDimension1D.maxTextureDimension2D.maxTextureDimension3D.maxTextureArrayLayers.maxBindGroups.maxBindGroupsPlusVertexBuffers.maxBindingsPerBindGroup.maxDynamicUniformBuffersPerPipelineLayout.maxDynamicStorageBuffersPerPipelineLayout.maxSampledTexturesPerShaderStage.maxSamplersPerShaderStage.maxStorageBuffersPerShaderStage.maxStorageBuffersInVertexStage.maxStorageBuffersInFragmentStage.maxStorageTexturesPerShaderStage.maxStorageTexturesInVertexStage.maxStorageTexturesInFragmentStage.maxUniformBuffersPerShaderStage.maxUniformBufferBindingSize.maxStorageBufferBindingSize.minUniformBufferOffsetAlignment.minStorageBufferOffsetAlignment.maxVertexBuffers.maxBufferSize.maxVertexAttributes.maxVertexBufferArrayStride.maxInterStageShaderVariables.maxColorAttachments.maxColorAttachmentBytesPerSample.maxComputeWorkgroupStorageSize.maxComputeInvocationsPerWorkgroup.maxComputeWorkgroupSizeX.maxComputeWorkgroupSizeY.maxComputeWorkgroupSizeZ.maxComputeWorkgroupsPerDimension.maxImmediateSize".split("."), ce = Object.freeze({
	available: !1,
	reason: "GPU timestamp queries are not instrumented. Initialization observations use CPU performance.now wall time."
});
function W(e) {
	try {
		return (e instanceof Error ? e.message : String(e)).slice(0, 2048) || "Observation unavailable without an error message.";
	} catch {
		return "Observation unavailable; error text could not be read.";
	}
}
function G(e) {
	if (typeof e != "object" || !e) throw Error("WebGPU observation object is unavailable.");
	return e;
}
function le(e) {
	G(e);
	let t = /* @__PURE__ */ new Set(), n = 0;
	for (let r of e) {
		if (++n > 128 || typeof r != "string" || r.length > 128) throw Error("WebGPU feature observation exceeds its bounded contract.");
		t.add(r);
	}
	return Object.freeze([...t].sort());
}
function ue(e) {
	let t = G(e), n = {};
	for (let e of se) {
		let r = Reflect.get(t, e);
		if (r !== void 0) {
			if (typeof r != "number" || !Number.isSafeInteger(r) || r < 0) throw Error(`WebGPU limit ${e} is not an observed finite safe integer.`);
			n[e] = r;
		}
	}
	return Object.freeze(n);
}
function de(e) {
	let t = null, n = null, r = null, i = null;
	try {
		t = le(Reflect.get(G(e), "features"));
	} catch (e) {
		r = W(e);
	}
	try {
		n = ue(Reflect.get(G(e), "limits"));
	} catch (e) {
		i = W(e);
	}
	return Object.freeze({
		features: t,
		limits: n,
		featuresUnavailableReason: r,
		limitsUnavailableReason: i
	});
}
function fe(e) {
	let t = null, n = null;
	try {
		let r = G(Reflect.get(G(e), "info")), i = {};
		for (let e of [
			"vendor",
			"architecture",
			"device",
			"description"
		]) {
			let t = Reflect.get(r, e);
			if (typeof t != "string" || t.length > 2048) throw Error(`Adapter info ${e} is unavailable or exceeds its text bound.`);
			i[e] = t;
		}
		for (let e of ["subgroupMinSize", "subgroupMaxSize"]) {
			let t = Reflect.get(r, e);
			if (t !== void 0) {
				if (typeof t != "number" || !Number.isSafeInteger(t) || t < 0) throw Error(`Invalid adapter info ${e}.`);
				i[e] = t;
			}
		}
		let a = Reflect.get(r, "isFallbackAdapter");
		typeof a == "boolean" && (i.isFallbackAdapter = a), t = Object.freeze(i), !i.vendor && !i.architecture && !i.device && !i.description && (n = "Adapter identification fields are empty or redacted.");
	} catch (e) {
		n = W(e);
	}
	return Object.freeze({
		...de(e),
		info: t,
		infoUnavailableReason: n
	});
}
var pe = class {
	observer;
	now;
	stage = "start";
	status = "initializing";
	events = [];
	adapter = null;
	requested = null;
	device = null;
	failure = null;
	startedAtMs = null;
	observedAtMs = null;
	clockUnavailableReason = null;
	current;
	constructor(e, t = () => performance.now()) {
		this.observer = e, this.now = t, this.publish("start");
	}
	get snapshot() {
		return this.current;
	}
	observeAdapter(e) {
		this.adapter = fe(e), this.advance("adapter-observed");
	}
	observeRequest(e) {
		this.requested = Object.freeze({
			features: le(e.requiredFeatures ?? []),
			limits: ue(e.requiredLimits ?? {})
		}), this.advance("device-request");
	}
	observeDevice(e) {
		this.device = de(e), this.advance("device-observed");
	}
	advance(e) {
		this.status !== "initializing" || this.events.length >= 9 && e !== "ready" || (e === "ready" && (this.status = "ready"), this.publish(e));
	}
	fail(e) {
		this.status === "initializing" && (this.status = "failed", this.failure = Object.freeze({
			stage: this.stage,
			reason: W(e)
		}), this.publish(this.stage));
	}
	publish(e) {
		this.stage = e;
		let t = null;
		try {
			let e = this.now();
			if (!Number.isFinite(e) || e < 0) throw Error("performance.now did not return an observed finite nonnegative time.");
			t = e;
		} catch (e) {
			this.clockUnavailableReason = W(e);
		}
		this.events.length === 0 && (this.startedAtMs = t), this.observedAtMs = t;
		let n = Object.freeze({
			stage: e,
			status: this.status,
			atMs: t
		});
		if (this.events.length < 10 ? this.events.push(n) : this.events[this.events.length - 1] = n, this.current = Object.freeze({
			schemaVersion: 1,
			kind: "splatview-renderer-negotiation",
			status: this.status,
			stage: e,
			clock: "performance.now",
			startedAtMs: this.startedAtMs,
			observedAtMs: this.observedAtMs,
			clockUnavailableReason: this.clockUnavailableReason,
			stages: Object.freeze([...this.events]),
			adapter: this.adapter,
			requested: this.requested,
			device: this.device,
			failure: this.failure,
			gpuTimestamps: ce
		}), this.observer) try {
			Promise.resolve(this.observer(this.current)).catch(() => void 0);
		} catch {}
	}
};
function me(e, t, n) {
	return typeof e == "number" && Number.isSafeInteger(e) && !Object.is(e, -0) && e >= t && e <= n;
}
function he(e, t, n = !0) {
	if (!me(t, 0, n ? 1e6 : 4294967295)) throw Error("Invalid Duplicate scene count.");
	if (e === null) return null;
	if (!n || !e || typeof e != "object" || Array.isArray(e) || ![Object.prototype, null].includes(Object.getPrototypeOf(e))) throw Error("Invalid Duplicate range.");
	let r = Reflect.ownKeys(e);
	if (r.length !== 2 || !r.includes("first") || !r.includes("count")) throw Error("Invalid Duplicate range.");
	let i = Object.getOwnPropertyDescriptor(e, "first"), a = Object.getOwnPropertyDescriptor(e, "count");
	if (!i?.enumerable || !("value" in i) || !a?.enumerable || !("value" in a) || !me(i.value, 0, t) || !me(a.value, 1, 1e6) || a.value !== t - i.value) throw Error("Invalid Duplicate range.");
	return Object.freeze({
		first: i.value,
		count: a.value
	});
}
function ge(e, t) {
	return e === null || t === null ? e === t : e.first === t.first && e.count === t.count;
}
//#endregion
//#region src/renderer/webgpu/surface.wgsl?raw
var _e = "// Surface projection uses floored map dimensions with the desktop's scalar\n// low-pass/axis-cap scale. Visibility keeps the separate full-frame projection.\n// Host packing and flags: surfaceQuery.ts. Struct field order is a 48-byte ABI.\nconst SURFACE_COLORS=1u;\nconst SURFACE_VISIBLE=2u;\nconst SURFACE_DOWNSAMPLED=4u;\nconst SURFACE_REGION=8u;\nconst SURFACE_TILE_SIZE=16u;\nstruct SurfaceParams {\n  full: vec2<u32>, size: vec2<u32>, tiles: vec2<u32>, coverageMinPacked: u32, count: u32,\n  channels: u32, dispatchWidth: u32, scale: f32, coverageMaxPacked: u32,\n}\n@group(0) @binding(0) var<uniform> params: SurfaceParams;\n@group(0) @binding(1) var<storage, read> projected: array<Projected>;\n@group(0) @binding(2) var<storage, read> order: array<vec2<u32>>;\n@group(0) @binding(3) var<storage, read_write> counts: array<atomic<u32>>;\n@group(0) @binding(4) var<storage, read_write> candidates: array<u32>;\n@group(0) @binding(5) var<storage, read> tileSpans: array<vec2<u32>>;\n@group(0) @binding(6) var<storage, read_write> output: array<vec2<f32>>;\n@group(0) @binding(7) var<uniform> frame: Frame;\n@group(0) @binding(8) var<storage, read> sourceSplats: array<u32>;\n@group(0) @binding(9) var<storage, read> sourceStates: array<u32>;\n@group(0) @binding(10) var<storage, read_write> auxiliary: array<vec4<f32>>;\n@group(0) @binding(11) var<storage, read_write> visibleBits: array<atomic<u32>>;\n@group(0) @binding(12) var<storage, read_write> colorOutput: array<vec4<f32>>;\n@group(0) @binding(13) var<storage, read_write> mapProjected: array<Projected>;\n@group(0) @binding(14) var<storage, read> transformTargets: array<u32>;\n@group(0) @binding(15) var<storage, read> opacityTargets: array<u32>;\n\nfn coefficient(address: u32, i: u32) -> f32 {\n  return unpack2x16float(sourceSplats[address+10u+i/2u])[i%2u];\n}\n// Frozen ungraded SH evaluation. Selection tint and display grading never\n// enter color-connectivity maps; the current geometry still affects direction.\nfn rawColor(address: u32, position: vec3<f32>) -> vec3<f32> {\n  let direction=position-frame.eyeDegree.xyz;\n  let d=direction/max(length(direction),1e-20);\n  let x=d.x; let y=d.y; let z=d.z; let xx=x*x; let yy=y*y; let zz=z*z;\n  var b: array<f32,16>;\n  b[0]=0.2820947918;\n  b[1]=-0.4886025119*y; b[2]=0.4886025119*z; b[3]=-0.4886025119*x;\n  b[4]=1.0925484306*x*y; b[5]=-1.0925484306*y*z;\n  b[6]=0.3153915653*(2.0*zz-xx-yy); b[7]=-1.0925484306*x*z; b[8]=0.5462742153*(xx-yy);\n  b[9]=-0.5900435899*y*(3.0*xx-yy); b[10]=2.8906114426*x*y*z;\n  b[11]=-0.4570457995*y*(4.0*zz-xx-yy); b[12]=0.3731763326*z*(2.0*zz-3.0*xx-3.0*yy);\n  b[13]=-0.4570457995*x*(4.0*zz-xx-yy); b[14]=1.4453057213*z*(xx-yy); b[15]=-0.5900435899*x*(xx-3.0*yy);\n  let bands=u32(frame.eyeDegree.w)+1u; let count=bands*bands;\n  var rgb=vec3(.5);\n  for(var j=0u;j<count;j++) {\n    rgb+=b[j]*vec3(coefficient(address,3u*j),coefficient(address,3u*j+1u),coefficient(address,3u*j+2u));\n  }\n  return max(rgb,vec3(0.0));\n}\nfn surfaceProjection(position: vec4<f32>, covariance: mat3x3<f32>, opacity: f32) -> Projected {\n  let empty=Projected(vec4(0.0),vec4(0.0),vec4(0.0));\n  let p=frame.view*position; if(p.z>=-.001 || opacity<.0039) { return empty; }\n  let depth=-p.z;\n  let right=vec3(frame.view[0].x,frame.view[1].x,frame.view[2].x);\n  let up=vec3(frame.view[0].y,frame.view[1].y,frame.view[2].y);\n  let forward=vec3(frame.view[0].z,frame.view[1].z,frame.view[2].z);\n  let focal=frame.viewport.zw*vec2<f32>(params.size)/vec2<f32>(params.full);\n  let jx=focal.x/depth*(right+p.x/depth*forward);\n  let jy=focal.y/depth*(up+p.y/depth*forward);\n  let a=dot(jx,covariance*jx)+(.3*params.scale)*params.scale;\n  let b=dot(jx,covariance*jy);\n  let c=dot(jy,covariance*jy)+(.3*params.scale)*params.scale;\n  let middle=(a+c)*.5; let delta=sqrt(max(0.0,(a-c)*(a-c)*.25+b*b));\n  let floor=(.01*params.scale)*params.scale;\n  let l1=max(floor,middle+delta); let l2=max(floor,middle-delta);\n  var axis=select(vec2(0.0,1.0),vec2(1.0,0.0),a>=c);\n  if(abs(b)>.00001) { axis=normalize(vec2(b,l1-a)); }\n  let axis1=axis*min(1536.0*params.scale,3.0*sqrt(l1));\n  let axis2=vec2(-axis.y,axis.x)*min(1536.0*params.scale,3.0*sqrt(l2));\n  let clip=frame.projection*p; if(clip.z<0.0 || clip.z>clip.w) { return empty; }\n  let extent=(abs(axis1)+abs(axis2)+vec2(1.0))*2.0/vec2<f32>(params.size)*clip.w;\n  if(any(abs(clip.xy)>vec2(clip.w)+extent)) { return empty; }\n  return Projected(vec4(clip.xy/clip.w,depth,1.0),vec4(axis1,axis2),vec4(0.0,0.0,0.0,opacity));\n}\n@compute @workgroup_size(256)\nfn prepareAuxiliary(@builtin(global_invocation_id) id: vec3<u32>) {\n  let i=id.x; if(i>=params.count) { return; }\n  let address=i*frame.flags.y; let state=sourceStates[i];\n  var position=vec4(bitcast<f32>(sourceSplats[address]),bitcast<f32>(sourceSplats[address+1u]),bitcast<f32>(sourceSplats[address+2u]),1.0);\n  let transforming=frame.geometryFlags.x!=0u && (frame.geometryFlags.y==0u || (transformTargets[i]&1u)!=0u);\n  if(transforming) { position=frame.geometry*position; }\n  var payload=vec4(0.0);\n  if((params.channels&SURFACE_COLORS)!=0u) { payload=vec4(rawColor(address,position.xyz),0.0); }\n  if((params.channels&6u)!=0u) {\n    let c0=vec4(bitcast<f32>(sourceSplats[address+4u]),bitcast<f32>(sourceSplats[address+5u]),bitcast<f32>(sourceSplats[address+6u]),bitcast<f32>(sourceSplats[address+7u]));\n    let c1=vec2(bitcast<f32>(sourceSplats[address+8u]),bitcast<f32>(sourceSplats[address+9u]));\n    var covariance=mat3x3(vec3(c0.x,c0.y,c0.z),vec3(c0.y,c0.w,c1.x),vec3(c0.z,c1.x,c1.y));\n    if(transforming) {\n      let a=mat3x3(frame.geometry[0].xyz,frame.geometry[1].xyz,frame.geometry[2].xyz);\n      covariance=a*covariance*transpose(a);\n    }\n    let forward=vec3(frame.view[0].z,frame.view[1].z,frame.view[2].z);\n    if((params.channels&SURFACE_VISIBLE)!=0u) { payload.w=3.0*sqrt(max(0.0,dot(forward,covariance*forward))); }\n    if((params.channels&SURFACE_DOWNSAMPLED)!=0u) {\n      mapProjected[i]=Projected(vec4(0.0),vec4(0.0),vec4(0.0));\n      if((state&2u)==0u) {\n        let opacity=previewOpacity(bitcast<f32>(sourceSplats[address+3u]),opacityTargets[i],frame.gradeD.w,frame.geometryFlags.w);\n        mapProjected[i]=surfaceProjection(position,covariance,opacity);\n      }\n    }\n  }\n  if((params.channels&3u)!=0u) { auxiliary[i]=payload; }\n}\n\nfn support(opacity: f32) -> f32 {\n  if(opacity>=.2141082512) { return 9.0; }\n  if(opacity>=.0289764008) {\n    if(opacity>=.0787660238) { return select(7.0,8.0,opacity>=.1298632188); }\n    return select(5.0,6.0,opacity>=.0477740084);\n  }\n  if(opacity>=.0106598221) { return select(3.0,4.0,opacity>=.0175750755); }\n  return select(1.0,2.0,opacity>=.0064655090);\n}\nstruct TileFootprint { first: vec2<u32>, last: vec2<u32>, valid: u32, }\n// Invert the same local-coordinate rows used by fragmentAlpha. Projected axes\n// are orthogonal in real arithmetic, but using their actual dot lengths and\n// determinant also covers the small FP32 residue of rotated / unequal axes.\nfn candidateExtent(gaussian: Projected, center: vec2<f32>) -> vec2<f32> {\n  let a=gaussian.axes.xy; let b=gaussian.axes.zw;\n  let quad=abs(a)+abs(b); let aa=dot(a,a); let bb=dot(b,b);\n  let determinant=a.x*b.y-a.y*b.x;\n  let opacity=gaussian.color.a;\n  // Keep the previous quad if the inverse is poorly conditioned or opacity\n  // lies at the cutoff. Exact fragment acceptance remains the final authority.\n  if(!(aa>0.0 && bb>0.0 && abs(determinant)>sqrt(aa*bb)*.001) ||\n    !(opacity>(1.0/255.0)*1.0001)) { return quad; }\n  // Alpha survives only within r <= 2*log(opacity*255), additionally bounded\n  // by native integer support and the quad radius. The .001 squared-radius\n  // allowance exceeds WGSL f32 exp/log error on this [0,9] domain, including\n  // cutoff equality. Do not shrink using an unpadded transcendental result.\n  let radius=min(9.0,min(support(opacity)+.001,2.0*log(opacity*255.0)+.001));\n  let x=vec2(aa*b.y,bb*a.y); let y=vec2(aa*b.x,bb*a.x);\n  let extent=sqrt(vec2(dot(x,x),dot(y,y)))*(sqrt(radius)/(3.0*abs(determinant)));\n  if(any(!(extent>=vec2(0.0))) || any(extent>vec2(3.402823466e+38))) { return quad; }\n  // Cover the local inverse, dot/divide/sqrt and center-subtraction rounding.\n  // This is at least 32 relative FP32 ULP plus a small absolute pixel halo.\n  let padding=(abs(center)+quad+vec2(1.0))*.000004+vec2(.001);\n  return min(quad,extent)+padding;\n}\nfn coverageMin() -> vec2<u32> {\n  return vec2(params.coverageMinPacked&65535u,params.coverageMinPacked>>16u);\n}\nfn coverageMax() -> vec2<u32> {\n  return vec2(params.coverageMaxPacked&65535u,params.coverageMaxPacked>>16u);\n}\n// Counting and filling must use identical conservative bounds. Keeping this\n// shared also avoids counting once with one rounding rule and scattering with\n// another at clipped or partial edge tiles.\nfn tileFootprint(rank: u32) -> TileFootprint {\n  let empty=TileFootprint(vec2(0u),vec2(0u),0u);\n  let gaussian=projected[order[rank].y&0xffffffu];\n  if(gaussian.center.w==0.0) { return empty; }\n  let center=vec2((gaussian.center.x+1.0)*.5,(1.0-gaussian.center.y)*.5)*vec2<f32>(params.size);\n  let extent=candidateExtent(gaussian,center);\n  // Exact ellipse/alpha/top-left tests still happen at each pixel. Clamping\n  // only after rejecting a disjoint box avoids wrapping at offscreen bounds.\n  let low=center-extent; let high=center+extent;\n  if(any(high<vec2(.5)) || any(low>vec2<f32>(params.size)-vec2(.5))) { return empty; }\n  var first=vec2<u32>(max(vec2(0.0),floor(low)))/SURFACE_TILE_SIZE;\n  var last=vec2<u32>(min(vec2<f32>(params.size)-vec2(1.0),max(vec2(0.0),floor(high))))/SURFACE_TILE_SIZE;\n  if((params.channels&SURFACE_REGION)!=0u) {\n    let minimum=coverageMin(); let maximum=coverageMax();\n    if(any(minimum>=maximum)) { return empty; }\n    first=max(first,minimum/SURFACE_TILE_SIZE); last=min(last,(maximum-vec2(1u))/SURFACE_TILE_SIZE);\n    if(any(first>last)) { return empty; }\n  }\n  return TileFootprint(first,last,1u);\n}\n@compute @workgroup_size(256)\nfn bin(@builtin(global_invocation_id) id: vec3<u32>) {\n  let rank=id.x; if(rank>=params.count) { return; }\n  let bounds=tileFootprint(rank); if(bounds.valid==0u) { return; }\n  for(var y=bounds.first.y;y<=bounds.last.y;y++) {\n    for(var x=bounds.first.x;x<=bounds.last.x;x++) {\n      atomicAdd(&counts[y*params.tiles.x+x],1u);\n    }\n  }\n}\n@compute @workgroup_size(256)\nfn scatter(@builtin(global_invocation_id) id: vec3<u32>) {\n  let rank=id.x; if(rank>=params.count) { return; }\n  let bounds=tileFootprint(rank); if(bounds.valid==0u) { return; }\n  for(var y=bounds.first.y;y<=bounds.last.y;y++) {\n    for(var x=bounds.first.x;x<=bounds.last.x;x++) {\n      let tile=y*params.tiles.x+x;\n      let slot=atomicAdd(&counts[tile],1u);\n      candidates[tileSpans[tile].x+slot]=rank+1u;\n    }\n  }\n}\n\n// Sort each tile's global ranks ascending. Zero is an empty slot and ends up\n// first, so the reverse traversal is precisely the stable near-to-far order.\n// Every comparator pair has one writer; a workgroup owns one disjoint tile.\n// Ordinary spans stay in 4 KiB of workgroup memory, avoiding global-memory\n// traffic at every comparator stage. Dense spans retain the storage path.\nvar<workgroup> sortSpan: vec2<u32>;\nvar<workgroup> localRanks: array<u32,1024>;\n@compute @workgroup_size(256)\nfn sortTile(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {\n  if(lane==0u) { sortSpan=tileSpans[group.y*params.tiles.x+group.x]; }\n  // This barrier/load establishes a uniform value for the early returns and\n  // barrier-containing branches below, even though the plan is storage data.\n  let span=workgroupUniformLoad(&sortSpan);\n  let base=span.x; let capacity=span.y;\n  if(capacity<=1u) { return; }\n  if(capacity<=1024u) {\n    for(var i=lane;i<capacity;i+=256u) { localRanks[i]=candidates[base+i]; }\n    workgroupBarrier();\n    for(var length=2u;;length*=2u) {\n      for(var distance=length/2u;distance>0u;distance/=2u) {\n        for(var i=lane;i<capacity;i+=256u) {\n          let other=i^distance;\n          if(other>i) {\n            let a=localRanks[i]; let b=localRanks[other];\n            let ascending=(i&length)==0u;\n            if(select((a < b),(a > b),ascending)) {\n              localRanks[i]=b; localRanks[other]=a;\n            }\n          }\n        }\n        workgroupBarrier();\n      }\n      if(length==capacity) { break; }\n    }\n    for(var i=lane;i<capacity;i+=256u) { candidates[base+i]=localRanks[i]; }\n    return;\n  }\n  for(var length=2u;;length*=2u) {\n    for(var distance=length/2u;distance>0u;distance/=2u) {\n      for(var i=lane;i<capacity;i+=256u) {\n        let other=i^distance;\n        if(other>i) {\n          let a=candidates[base+i]; let b=candidates[base+other];\n          let ascending=(i&length)==0u;\n          if(select((a < b),(a > b),ascending)) {\n            candidates[base+i]=b; candidates[base+other]=a;\n          }\n        }\n      }\n      storageBarrier();\n    }\n    if(length==capacity) { break; }\n  }\n}\n\n@compute @workgroup_size(16,16)\nfn composite(@builtin(global_invocation_id) id: vec3<u32>) {\n  if(any(id.xy>=params.size)) { return; }\n  if((params.channels&SURFACE_REGION)!=0u && (any(id.xy<coverageMin()) || any(id.xy>=coverageMax()))) { return; }\n  let sample=vec2<f32>(id.xy)+vec2(.5);\n  let tile=(id.y/SURFACE_TILE_SIZE)*params.tiles.x+id.x/SURFACE_TILE_SIZE;\n  let span=tileSpans[tile]; let base=span.x;\n  var transmission=1.0; var depth=0.0; var opacity=0.0; var rgb=vec3(0.0);\n  let count=atomicLoad(&counts[tile]);\n  // The complete compact allocation was admitted before filling these lists.\n  for(var i=0u;i<count;i++) {\n    let rank=candidates[base+span.y-1u-i]-1u;\n    let gaussian=projected[order[rank].y&0xffffffu];\n    let alpha=fragmentAlpha(gaussian,sample,params.size); if(alpha==0.0) { continue; }\n    let weight=transmission*alpha;\n    if((params.channels&SURFACE_COLORS)!=0u) { rgb+=weight*auxiliary[order[rank].y&0xffffffu].xyz; }\n    depth+=weight*gaussian.center.z; opacity+=weight; transmission*=1.0-alpha;\n    // Native surface depth accumulates all surviving fragments, with no T exit.\n  }\n  let normalized=depth/max(opacity,1e-20);\n  let finite=(bitcast<u32>(normalized)&0x7f800000u)!=0x7f800000u;\n  output[id.y*params.size.x+id.x]=vec2(select(0.0,normalized,opacity>=1.0/255.0 && finite && normalized>0.0),clamp(opacity,0.0,1.0));\n  if((params.channels&SURFACE_COLORS)!=0u) {\n    colorOutput[id.y*params.size.x+id.x]=vec4(select(vec3(0.0),clamp(rgb/max(opacity,1e-20),vec3(0.0),vec3(1.0)),opacity>=1.0/255.0),0.0);\n  }\n}\n\nfn topLeft(edge: vec2<f32>) -> bool { return edge.y<0.0 || (edge.y==0.0 && edge.x>0.0); }\nfn fragmentAlpha(gaussian: Projected, sample: vec2<f32>, dimensions: vec2<u32>) -> f32 {\n  let center=vec2((gaussian.center.x+1.0)*.5,(1.0-gaussian.center.y)*.5)*vec2<f32>(dimensions);\n  let delta=vec2(sample.x-center.x,center.y-sample.y);\n  let local=3.0*vec2(dot(delta,gaussian.axes.xy)/dot(gaussian.axes.xy,gaussian.axes.xy),\n    dot(delta,gaussian.axes.zw)/dot(gaussian.axes.zw,gaussian.axes.zw));\n  // Pixel-center coverage of the native quad follows the top-left fill rule.\n  // This matters when an ellipse boundary falls exactly on a pixel center.\n  let u=vec2(gaussian.axes.x,-gaussian.axes.y); let v=vec2(gaussian.axes.z,-gaussian.axes.w);\n  if(any(abs(local)>vec2(3.0)) ||\n    (local.x==-3.0 && !topLeft(v)) || (local.x==3.0 && !topLeft(-v)) ||\n    (local.y==3.0 && !topLeft(u)) || (local.y==-3.0 && !topLeft(-u))) { return 0.0; }\n  let r=dot(local,local); if(r>min(9.0,support(gaussian.color.a)+.001)) { return 0.0; }\n  let alpha=min(.99,gaussian.color.a*exp(-.5*r)); return select(0.0,alpha,alpha>=1.0/255.0);\n}\n@compute @workgroup_size(64)\nfn markVisible(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {\n  let source=group.y*params.dispatchWidth+group.x;\n  if(source>=params.count) { return; }\n  let gaussian=projected[source]; if(gaussian.center.w==0.0) { return; }\n  let center=vec2((gaussian.center.x+1.0)*.5,(1.0-gaussian.center.y)*.5)*vec2<f32>(params.full);\n  let extent=abs(gaussian.axes.xy)+abs(gaussian.axes.zw);\n  let low=max(vec2(0.0),ceil(center-extent-vec2(.5)));\n  let high=min(vec2<f32>(params.full)-vec2(1.0),floor(center+extent-vec2(.5)));\n  if(any(low>high)) { return; }\n  let first=vec2<u32>(low); let size=vec2<u32>(high)-first+vec2(1u);\n  let count=size.x*size.y;\n  let word=source/32u; let bit=1u<<(source%32u);\n  for(var pixel=lane;pixel<count;pixel+=64u) {\n    if((atomicLoad(&visibleBits[word])&bit)!=0u) { break; }\n    let at=first+vec2(pixel%size.x,pixel/size.x); let sample=vec2<f32>(at)+vec2(.5);\n    if(fragmentAlpha(gaussian,sample,params.full)==0.0) { continue; }\n    let mapAt=min(vec2<u32>(sample*vec2<f32>(params.size)/vec2<f32>(params.full)),params.size-vec2(1u));\n    let surface=output[mapAt.y*params.size.x+mapAt.x];\n    if(surface.y<1.0/255.0 || gaussian.center.z<=surface.x+auxiliary[source].w+gaussian.center.z*.005) {\n      atomicOr(&visibleBits[word],bit); break;\n    }\n  }\n}\n", ve = [
	"bin",
	"scatter",
	"sortTile",
	"composite",
	"prepareAuxiliary"
], K = /* @__PURE__ */ new WeakMap();
async function ye(e, t = {}) {
	e.requireScene();
	let n = K.get(e);
	n || (n = e.checkedAllocation(() => {
		let t = e.device.createShaderModule({
			label: "Native composited surface map",
			code: p + _e
		}), n = Promise.all(ve.map(async (n) => [n, await e.device.createComputePipelineAsync({
			label: `Surface ${n}`,
			layout: "auto",
			compute: {
				module: t,
				entryPoint: n
			}
		})])).then((e) => Object.fromEntries(e));
		return n.catch(() => void 0), {
			module: t,
			base: n
		};
	}, async (e) => {
		await e.base.catch(() => void 0);
	}), K.set(e, n));
	try {
		let r = await n;
		t.visible && !r.visibility && (r.visibility = e.checkedAllocation(() => {
			let t = e.device.createComputePipelineAsync({
				label: "Surface markVisible",
				layout: "auto",
				compute: {
					module: r.module,
					entryPoint: "markVisible"
				}
			});
			return t.catch(() => void 0), { pipeline: t };
		}, async (e) => {
			await e.pipeline.catch(() => void 0);
		}).then((e) => e.pipeline), r.visibility.catch(() => void 0));
		let [i, a] = await Promise.all([r.base, t.visible ? r.visibility : void 0]);
		return e.requireScene(), a ? {
			...i,
			markVisible: a
		} : i;
	} catch (t) {
		throw K.get(e) === n && K.delete(e), t;
	}
}
function be(e) {
	K.delete(e);
}
//#endregion
//#region src/renderer/webgpu/surfaceScratchPool.ts
var xe = class {
	device;
	maximumIdleBytes;
	maximumIdleBuffers;
	entries = /* @__PURE__ */ new Set();
	disposed = !1;
	reused = 0;
	created = 0;
	constructor(e, t = 16 * h, n = 32) {
		this.device = e, this.maximumIdleBytes = t, this.maximumIdleBuffers = n, y(t, 1), y(n, 1);
	}
	get snapshot() {
		let e = 0, t = 0, n = 0, r = 0;
		for (let i of this.entries) e += i.size, i.busy ? r++ : (t += i.size, n++);
		return {
			allocatedBytes: e,
			idleBytes: t,
			idleBuffers: n,
			activeBuffers: r,
			createdBuffers: this.created,
			reusedBuffers: this.reused
		};
	}
	acquire(e, t, n, r, i) {
		if (this.disposed) throw new g("The surface scratch owner was retired.");
		if (y(n, 1), n < 4 || n % 4 || n > this.device.limits.maxBufferSize) throw new g("The surface scratch buffer exceeds the graphics device limit.");
		let a = [...this.entries].find((t) => !t.busy && t.owner === e && t.size === n && t.usage === r && t.buffer.mapState === "unmapped"), o = !!a;
		if (a) a.buffer.label = t, a.busy = !0, this.reused++;
		else {
			let o;
			try {
				o = i(n);
			} catch (e) {
				if (!(e instanceof g) || !this.evictIdle()) throw e;
				o = i(n);
			}
			let s;
			try {
				s = this.device.createBuffer({
					label: t,
					size: n,
					usage: r
				});
			} catch (e) {
				throw o(), e;
			}
			a = {
				owner: e,
				buffer: s,
				size: n,
				usage: r,
				credit: o,
				busy: !0,
				cacheable: !0
			}, this.entries.add(a), this.created++;
		}
		let s = a, c = !1;
		return {
			buffer: s.buffer,
			reused: o,
			release: (e = !0) => {
				if (!c && (c = !0, this.entries.has(s))) {
					if (s.busy = !1, !e || !s.cacheable || s.buffer.mapState !== "unmapped" || s.size > this.maximumIdleBytes || !this.maximumIdleBuffers) this.destroy(s);
					else for (; this.snapshot.idleBytes > this.maximumIdleBytes || this.snapshot.idleBuffers > this.maximumIdleBuffers;) {
						let e = [...this.entries].find((e) => !e.busy && e !== s);
						if (!e) {
							this.destroy(s);
							break;
						}
						this.destroy(e);
					}
					this.entries.delete(s) && this.entries.add(s);
				}
			}
		};
	}
	trim(e) {
		for (let t of this.entries) (!e || t.owner === e) && (t.busy ? t.cacheable = !1 : this.destroy(t));
	}
	evictIdle() {
		let e = 0;
		for (let t of this.entries) t.busy || (e += t.size, this.destroy(t));
		return e;
	}
	destroy(e) {
		if (this.entries.delete(e)) try {
			e.buffer.destroy();
		} finally {
			e.credit();
		}
	}
	dispose() {
		if (!this.disposed) {
			this.disposed = !0;
			for (let e of this.entries) this.destroy(e);
		}
	}
}, Se = "// Adapted from PlayCanvas PR 9819 (MIT). Attribution/license: steadyNoise.ts\n// and docs/third-party/STEADY_SPLATS_REFERENCES.md. Compiled with frame.wgsl\n// and splats.wgsl so sampling and PDF evaluation share native alpha support.\nstruct SteadySettings {\n  inverseProjection: mat4x4<f32>, inverseView: mat4x4<f32>, previousViewProjection: mat4x4<f32>,\n  flags: vec4<u32>, // sample frame, valid history, stationary camera, stationary samples\n  temporal: vec4<f32>, // width, height, color retention, background shade\n  stripe: vec4<u32>, // row start, row count, noise cycle shift, unused\n}\n@group(1) @binding(0) var<uniform> steady: SteadySettings;\n@group(1) @binding(1) var steadyNoise: texture_3d<f32>;\n@group(1) @binding(2) var steadyRaw: texture_2d<f32>;\n@group(1) @binding(3) var steadySamples: texture_2d<u32>;\n@group(1) @binding(4) var steadyWeights: texture_2d<f32>;\n@group(1) @binding(5) var steadyWeightsOut: texture_storage_2d<rgba32float, write>;\n@group(1) @binding(6) var steadyPrevious: texture_2d<f32>;\n@group(1) @binding(7) var steadyOutput: texture_storage_2d<rgba16float, write>;\nstruct SteadyEntry { id: u32, depth: f32, horizontal: u32, vertical: u32 }\nstruct SteadyPixel { entries: array<SteadyEntry, 4>, state: u32 }\n@group(1) @binding(8) var<storage, read_write> steadyHistory: array<SteadyPixel>;\n@group(1) @binding(9) var<storage, read_write> steadyRest: array<vec4<f32>>;\nconst STEADY_NEIGHBORS = array<vec2<i32>,4>(vec2(1,0),vec2(-1,0),vec2(0,1),vec2(0,-1));\n\nfn steadyAlpha(opacity: f32, local: vec2<f32>) -> f32 {\n  let r=dot(local,local);\n  if(r>min(9.0,opacitySupport(opacity)+.001)) { return 0.0; }\n  let alpha=min(.99,opacity*exp(-.5*r));\n  return select(0.0,alpha,alpha>=1.0/255.0);\n}\nfn steadyAlphaAt(g: Projected, pixel: vec2<f32>) -> f32 {\n  let center=(g.center.xy*vec2(.5,-.5)+.5)*steady.temporal.xy;\n  let delta=(pixel-center)*vec2(1.0,-1.0);\n  return steadyAlpha(g.color.a,3.0*vec2(dot(delta,g.axes.xy)/dot(g.axes.xy,g.axes.xy),dot(delta,g.axes.zw)/dot(g.axes.zw,g.axes.zw)));\n}\nfn steadyPrimitivePhase(id: u32) -> u32 {\n  let state=id*747796405u+2891336453u;\n  let word=((state>>((state>>28u)+4u))^state)*277803737u;\n  return (word>>22u)^word;\n}\nstruct SteadyVertex {\n  @builtin(position) position: vec4<f32>, @location(0) local: vec2<f32>,\n  @location(1) @interpolate(flat) index: u32,\n}\n@vertex\nfn steadyVertex(@builtin(vertex_index) vertexIndex: u32, @builtin(instance_index) index: u32) -> SteadyVertex {\n  let corners=array<vec2<f32>,6>(vec2(-1.0,-1.0),vec2(1.0,-1.0),vec2(-1.0,1.0),vec2(-1.0,1.0),vec2(1.0,-1.0),vec2(1.0,1.0));\n  let g=projected[index]; let corner=corners[vertexIndex];\n  let offset=g.axes.xy*corner.x+g.axes.zw*corner.y;\n  let clip=frame.projection*vec4(0.0,0.0,-g.center.z,1.0);\n  var result: SteadyVertex;\n  result.position=vec4(g.center.xy+2.0*offset/frame.viewport.xy,clip.z/max(clip.w,1e-20),1.0);\n  if(g.center.w==0.0) { result.position=vec4(2.0,2.0,2.0,1.0); }\n  result.local=corner*3.0; result.index=index; return result;\n}\nstruct SteadySample { @location(0) color: vec4<f32>, @location(1) sample: vec2<u32> }\n@fragment\nfn steadyFragment(input: SteadyVertex) -> SteadySample {\n  let g=projected[input.index]; let alpha=steadyAlpha(g.color.a,input.local);\n  if(alpha<=0.0) { discard; }\n  let id=input.index+1u;\n  let offset=vec2(id*3242174889u,id*2447445415u)>>vec2(27u);\n  let coordinate=vec3<i32>(vec2<i32>((vec2<u32>(input.position.xy)+offset)&vec2(31u)),i32(steady.flags.x&63u));\n  let rank=u32(textureLoad(steadyNoise,coordinate,0).r*255.0+.5);\n  let rotated=(rank<<24u)+steadyPrimitivePhase(id)+steady.stripe.z;\n  if(alpha<=f32(rotated>>8u)*(1.0/16777216.0)) { discard; }\n  var rgb=g.color.rgb;\n  if(frame.geometryFlags.z!=0u && (states[input.index]&1u)!=0u) {\n    let tint=select(vec3(1.0,.72,.12),vec3(.49,.824,.573),frame.geometryFlags.z==2u);\n    rgb=mix(rgb,tint,.72);\n  }\n  return SteadySample(vec4(rgb,1.0),vec2(id,bitcast<u32>(g.center.z)));\n}\n\n@compute @workgroup_size(8,8)\nfn steadyHistoryPass(@builtin(global_invocation_id) global: vec3<u32>) {\n  let p=vec2<i32>(global.xy+vec2(0u,steady.stripe.x));\n  if(any(p>=vec2<i32>(steady.temporal.xy)) || global.y>=steady.stripe.y) { return; }\n  let base=global.x+global.y*u32(steady.temporal.x);\n  var state=0u;\n  if(steady.flags.y!=0u) { state=steadyHistory[base].state; }\n  let head=state&3u; let count=state>>2u;\n  let sample=textureLoad(steadySamples,p,0);\n  let id=sample.x;\n  var depth=3.402823e38; var alpha=1.0; var neighbors=vec4(1.0);\n  if(id!=0u) {\n    depth=bitcast<f32>(sample.y); let g=projected[id-1u];\n    alpha=steadyAlphaAt(g,vec2<f32>(p)+.5);\n    for(var n=0u;n<4u;n++) { neighbors[n]=steadyAlphaAt(g,vec2<f32>(p+STEADY_NEIGHBORS[n])+.5); }\n  }\n  var ratio=neighbors/max(alpha,1e-20); var duplicate=false;\n  for(var k=0u;k<count;k++) {\n    let entry=steadyHistory[base].entries[(head+k)&3u];\n    duplicate=duplicate || (entry.id==id && id!=0u);\n    if(entry.id!=0u && entry.id!=id && entry.depth<depth) {\n      ratio*=vec4(unpack2x16float(entry.horizontal),unpack2x16float(entry.vertical));\n    }\n  }\n  textureStore(steadyWeightsOut,p,ratio);\n  if(id!=0u && !duplicate) {\n    let next=(head+3u)&3u;\n    let occlusion=(1.0-neighbors)/max(1.0-alpha,1e-6);\n    steadyHistory[base].entries[next]=SteadyEntry(id,depth,pack2x16float(occlusion.xy),pack2x16float(occlusion.zw));\n    steadyHistory[base].state=next|(min(count+1u,4u)<<2u);\n  } else if(steady.flags.y==0u) { steadyHistory[base].state=0u; }\n}\n\nfn steadyYCoCg(c: vec3<f32>) -> vec3<f32> {\n  return vec3(dot(c,vec3(.25,.5,.25)),(c.r-c.b)*.5,dot(c,vec3(-.25,.5,-.25)));\n}\nfn steadyRadiance(c: vec4<f32>) -> vec3<f32> { return c.rgb+(1.0-c.a)*steady.temporal.w; }\nfn steadyCubic(t: f32) -> vec4<f32> {\n  let t2=t*t; let t3=t2*t;\n  return vec4(-.5*t+t2-.5*t3,1.0-2.5*t2+1.5*t3,.5*t+2.0*t2-1.5*t3,-.5*t2+.5*t3);\n}\nfn steadyHistoryAt(pixel: vec2<f32>) -> vec4<f32> {\n  let base=vec2<i32>(floor(pixel-.5)); let fraction=fract(pixel-.5);\n  let wx=steadyCubic(fraction.x); let wy=steadyCubic(fraction.y); var color=vec4(0.0);\n  for(var y=0;y<4;y++) { for(var x=0;x<4;x++) {\n    let q=clamp(base+vec2(x-1,y-1),vec2(0),vec2<i32>(steady.temporal.xy)-1);\n    color+=wx[x]*wy[y]*textureLoad(steadyPrevious,q,0);\n  }}\n  return color;\n}\nfn steadyTemporalAt(p: vec2<i32>, current: vec4<f32>) -> vec4<f32> {\n  if(steady.flags.y==0u || steady.temporal.z<=0.0) { return current; }\n  let pixel=vec2<f32>(p)+.5; var previousPixel=pixel;\n  var historical=textureLoad(steadyPrevious,p,0);\n  if(steady.flags.z==0u) {\n    let sample=textureLoad(steadySamples,p,0);\n    let ndc=pixel/steady.temporal.xy*vec2(2.0,-2.0)+vec2(-1.0,1.0);\n    let unprojected=steady.inverseProjection*vec4(ndc,1.0,1.0);\n    let ray=unprojected.xyz/-unprojected.z;\n    let depth=bitcast<f32>(sample.y);\n    let world=steady.inverseView*select(vec4(ray,0.0),vec4(ray*depth,1.0),sample.x!=0u);\n    let clip=steady.previousViewProjection*world;\n    previousPixel=(clip.xy/max(clip.w,1e-20)*vec2(.5,-.5)+.5)*steady.temporal.xy;\n    if(clip.w<=0.0 || any(previousPixel<vec2(2.0)) || any(previousPixel>=steady.temporal.xy-2.0)) { return current; }\n    historical=steadyHistoryAt(previousPixel);\n  }\n  var mean=vec3(0.0); var second=vec3(0.0);\n  for(var y=-1;y<=1;y++) { for(var x=-1;x<=1;x++) {\n    let q=clamp(p+vec2(x,y),vec2(0),vec2<i32>(steady.temporal.xy)-1);\n    let value=steadyYCoCg(steadyRadiance(textureLoad(steadyRaw,q,0)));\n    mean+=value; second+=value*value;\n  }}\n  mean/=9.0;\n  let sigma=sqrt(max(second/9.0-mean*mean,vec3(0.0)));\n  let gamma=mix(4.0,1.0,min(length(pixel-previousPixel)/4.0,1.0));\n  let extent=max(sigma*gamma,vec3(.01,.005,.005));\n  let delta=abs(steadyYCoCg(steadyRadiance(historical))-mean)/extent;\n  return mix(current,historical,steady.temporal.z/max(1.0,max(delta.x,max(delta.y,delta.z))));\n}\n@compute @workgroup_size(8,8)\nfn steadyResolvePass(@builtin(global_invocation_id) global: vec3<u32>) {\n  let p=vec2<i32>(global.xy+vec2(0u,steady.stripe.x));\n  if(any(p>=vec2<i32>(steady.temporal.xy)) || global.y>=steady.stripe.y) { return; }\n  let raw=textureLoad(steadyRaw,p,0); var spatial=raw; var mass=1.0;\n  for(var n=0u;n<4u;n++) {\n    let source=p-STEADY_NEIGHBORS[n];\n    if(all(source>=vec2(0)) && all(source<vec2<i32>(steady.temporal.xy))) {\n      let weight=textureLoad(steadyWeights,source,0)[n];\n      spatial+=textureLoad(steadyRaw,source,0)*weight; mass+=weight;\n    }\n  }\n  spatial/=mass;\n  var color=steadyTemporalAt(p,spatial);\n  let frames=steady.flags.w;\n  if(frames!=0u) {\n    let index=global.x+global.y*u32(steady.temporal.x);\n    let sample=select(raw,spatial,frames<=8u); var average=sample;\n    if(frames>1u) { average=steadyRest[index]; average+=(sample-average)/f32(frames); }\n    steadyRest[index]=average;\n    color=mix(color,average,f32(frames)/(f32(frames)+8.0));\n  }\n  let alpha=clamp(color.a,0.0,1.0);\n  let rgb=color.rgb*select(0.0,alpha/max(color.a,1e-8),color.a>0.0);\n  textureStore(steadyOutput,p,vec4(rgb,alpha));\n}\n@vertex\nfn steadyCompositeVertex(@builtin(vertex_index) index: u32) -> @builtin(position) vec4<f32> {\n  let corners=array<vec2<f32>,3>(vec2(-1.0,-1.0),vec2(3.0,-1.0),vec2(-1.0,3.0));\n  return vec4(corners[index],0.0,1.0);\n}\n@fragment\nfn steadyCompositeFragment(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32> {\n  let color=textureLoad(steadyPrevious,vec2<i32>(position.xy),0);\n  return vec4(color.rgb+(1.0-color.a)*steady.temporal.w,1.0);\n}\n", Ce = "y/19OVfvmmgmTo4IxmIQM3lKGu9WC0t7RsT+qg5Z1DEaXtqoCJC+Dv7guEH41VS9pGS25M2fmOwC4C+awpHkPrIpvGSCMG7OPVwUk3eGF+eROiV1LWvZGIymYSN5B1CgdkicFutRxpPtfNIf7DCrRAD1xoVBrV64OUPoukr5xvAAq/nEP98hBIcuwU1bo2lx0FwTlftOH/Jz1H8TlGIgh2tUDXuLZ9WkS2KuBtb2It6+oLB9BtC9LBCkaN3JL0POcpg40BlW+iuz8YE8h7eVCkok7C/kcJLLWbEDNviFs+UR87XpqWG8EHScKL0RUe07g3RQWBuOYfhImepSnQslwIoxTyFGldFvQNnL+3BgLMKL2frInEAROOKDHXqtSdFaFtjJhngzF+dTBx2OM6ngF5dGArhurL4oZrfUQLtk+5U/dfGnAt6Br4nFSnvPnGX4D6dkNoTd8KEGdDEV7nCkJ0+fZz3E/yZb8qLksz0DttImfcrnIApUfv/Hkt2LBb3jE7NaDK1rTJ0MLl5tJOx3RE/wryvDSI3QKlGfH1s1SIn659cuisAU1GmUGP2GVJEvoFcSX6S8axuxQW7A964kxzFRGZN34jexRd65yQ7ZwfZt2HqT9zbq2GPihArldc2AYat8xST3Yx3qpzt/NGOqGQC94kIPgVwCoRA8lkNcogC7mkHrVKHJkodwA1TxoSFLyjSbG89NmSz8vHry1BJr8ScN1W0RSAIyWvkp3Y5u5pKDPv50jWzZwYk1YB+sKt2JsuE3lrWA26XQFr99PA3RK+5hqya27R5Cz6hwyFGSRlZ9YPUdynXzP5hLZpfHr1l2uAbIUd4NXbJLFecG7r4y+gOHRahmK8AZ6a4H4yX8TBN/2J0XfaYx9Hef3Sd5l9AWwssvUe4IXIViLbdvQJ6p3jVgKUT5aZoDjDO3gTpatXXobY7ZoOSxPPyO1VUcagPyicTsdZG71+pnVsNPD/JiIKf/GhC4WCVwqQ59xOeCI89QsjqjCi1HEs0a/Y/ho9MtTFyAlEJ4mdcb60Qyo5NbumceFd5hU76ErkGgKQdEkT3gnmMp1PkGyU+9WQHg+EsMhvScr/+XHOYx0Gxzrb54FQG48cI5poo2bK2XzXE7xqcxa0kocNR6WJTE71Eb6Px8xTRpC1Eh5e9IIv1lJ30X7tqPuoHLAeslYxE7hbdZZpfXg+vJgmJzlHoPoYXYr55GDVboEqxPPZ3520yVCNAsIFWuTJIS17sE3r8wX+gFV8N7N/dFML+LfwymyiasRfVABp8o9kKzXjXTGvJMOLWIbCTFlXGkX+HQIGaG2e6ee7aKE3C/4B1GpYOubaiXIOL9qtgGhLMb9iyxclE2GXNk6Ed/0LilQtzyeMMraICXonOy86YWzWmaSeh8Evzj1Rip5wtUTNcWDWpVqQGOPA7IPt8DgGE6DNtZ0iBjApFFeMpp+m8f7bOXOYHHsvdHutllLe3FtJMfhKloNp/JObyCJjrWwHo2oUnmkRxR4XLrGZOIdTFD41DJBfqjT4XbUgmcjlgBpIhky/8uvSV+CjKks1YM1fmXfPBAvC3qjyTzsOoUqsj0Jgt2YAXZoMprRcBSIb4ZY7coFFd4zxoQYKRzLeA+lDTouESzUIhal/UnzP3gmD9vM6nFj5pt4bQ/1Ulm/V10UxbQh3HkQLAQ5ngGf2nti6XeSecI+DVLe/aAwBu2g8bXnfkjFPMuH2fcj6s2QbYBWRXLhF0dzb0MassIl0YfBCurWICfzrrGQlsao0vTKJV5+kFrqLFVPIskM6fsiuN6Smq2O2MPeKnvkjDBX/QcsOW/IS3Yif/ko5rdVnDNNr2R2wfi8Ys2VgTS+QqDcNxRC3Oc8ARGcxJPYfUvEO9dqf0jQpQq136fPGx7UOWbLYtmTNG9YJMg1MAFr3rWj1MNwxlyrU3CE+2uzB2zwxW8/qk0hBDpLrjxhERmshtrJ5pm74O5+mtiJUrgMpFFPlgFyEGbeGusVTqQKcWAQKL2sk7KWDegAM6Il/wPdNfyIn7o2SX63hjJbdz7E+nPSTXiB34tFN8h6lIrnl2qhW+ZaF8ThkijjCi8Cp1elAGE3CK+iqbUcZletwq+yy8C6sU3r8+2UQBameJ5IVQ0rnZalUPm9mNJq8R8QuhnSdwmpQf4OnLD7zhl7UHI1fC8/xZw0FQeMZM7/hpYixb8sVaKT5UgqA98ia4Ub4efahCmNbgGiMQUewTh0Ci1oNF6RBnka9wr5rgj1DD6BUwj5X9mq+9srOe5oV+H7246DZLxvdB/SJxg+E6hXsJ6uVxCmyvYJTqaUdl2QUwIltd1XShoNP/KBoU/Cswbiq0339MDUJaFRftbDSPNumWuE+4+rQS3FlPDbrl37DzZC/Ydh+j0tw7kHcSGnS/j+1Iuy+aZg1tzlyOb3zOlaVGTqERichfNX3OtaDjrjhmpgR+LwRtNzeE49NIPso73JWR8yL+wkj8vnAXcgLgHWnjUokRsqvqziwxdRmojVgLF5J4OM0b5pN568khR+ZU1SPUE3lQnET7qLtmGlui9gy5A7iBbiABTIca6JxTLZN++iWIxfvGgZnYgq3L9Thmm1HCN27nTaO47gqpa1qQ/cSQLzLWQ0cQAg7pUwwbRbDD0DZw3c6HjwhlwCIfAHZp88KxD4xRvSNflQp4UOZBCxoBnTf4KMpgojF78kjBM6RXVWf4fUSaSWSz6ea/vJreYVa8jwF+pD13+M4oKt00jwZoS6z3xNo5tVYaY6v4Uzkx0qDS5WIfF0gCYzmTbp2/72n27G88P1vMwvWAsozqLnPUK6mIgQnEmu0t9KZ3oOFUCrFqWQl6dqhV1yxxQ11kghcVJy973nD7pbvgTQg3DiUUnhOBntiVT6Qjej3+y4r1nF3+jBlq2kBfgs4Nm8pJ3xtX1Mgb+woc8aLk+dABhM0f7MHQ2vw9+M1fDO9WqJWKkGHCaqXhLy6I165ut9iXptZLSr+ZE79lrqwyaU+QzC9tDzB9IgNoX9IIOV0QT06h2AyppHqKYTSL8kSvKGbT5nFG4jO8sCrInYrwsxYltf8pD8o53XMwChnhJXPGKZHs4AetXb8FckOPQmv3alh08WRmd3QribrPTMui/BXFBlMiq5BDWPfxrRAJ7R10G7qLQgsJQOcYqSPOhFqjetyLaWTBnHZOteRukMrFxH8FQa/c2DbL/H4mYE2FrOpVI9hShiH7ON76e3lbwzorqtTHhrCuKe2Ko7jyAvswfg2nPLLbuSvliBU4Ot38mPwpmkBBc0m7pGFoGuVfb+lGuDeJbAz28JJnpLYb2YxLApNmAQySh2U20hZrhMksAei6YwY2odpEWbcW02DqWz0qb/hfwyJgJQMTPJxLwo4vR5lVA/zFm6+BQin0ZWHXvMVNwYLw8afopcfVmkHIhXbMadxGFyQnOPq00/SrjwrEh4QeOS7MUkOBGsVm1OMPpcJ71vWGmSx9d0wFlphRgA6x91co2o+mAwANNoNb9C0Uo2TZHKraY+b6BnknXcpE96iqH+Q11JF6qGjJ8FVKnlmQJyG3f7Q2GcxPLN+8gu3ajVr5FsN1TL/SJ5ctth+GB87CQFo16O1glseNuhppD804UYyFqmLbVc0K0Hu0CJcE+TrjRUhvWufQrUQ5c0q8IzIXY8AA89xeRwyudW0vQaSx7Bf1xpcJCk8Wr+6UsG+I5lsF4ib9IgwhT+JDYungO8NyDSDHrDJ1ifwRpSnmOZ/5ZJDaqD8pspGJ+FDz8pMVZOcyhiSPfTxM42+qbyNysC0rmZNudXdbquyPHR4oaM5+XElrRa1+y9oy+GTIjVUKhtX8WjvwzIUs4eAqqVdd2X+ke/K4BNnLTIFJehO69jB30xHZSKrQCi9yeY/RrtY4Du3RMvOONpz7MlK/LBW9iK88IROzUk3LL+j+/KecPQfWrK5M7Jhj/W+l6EjrT+pHhN7OgEVrDGk6BCDKFx04g1WhX5MZ8uJ0KKEaiaLF9F1lIgfdsrX3fX6/kSZR14ME1g6D4CIdr3k6rw/chTNsKuadf4y8hPe8UzvNsohusVvB3FUPSUzBms4N0AZvlQMglbpMEvNhUmIosG7UpYtkJa0DUcoj7nCztGs5iNIw5xW8XvzKnIDyQRO85hRjHVIPimn0FSiO6aoaeWZBN2BvnhSmXavFeygK2eM6e7pKoSv0fNOqTYNcYN8D/CS7wyl2s+8SC1j+Y/yVTiwhpQtswsm+8U8afywp13UKstaF6Dkg9BFMUKHuobdz0EsV8JQJa0aQP9yl/Vu+RIoFVZSbXnbqK5bPyYME1sV7VPK6+kOkbaItENOOnYhPS6XEE+I017k1joHTeBxpLhHAe/FWbOc+Es+8AvUmEuThLzJVH4h9u2g1FMYev5aAxuueJbBn0Rl0kcFGXG8cH8agzw7Vfv34X0MMkkE8+9yQDpUQKtcJ5Df7Sw5Ar/J1qIFsUgwc6n3Kr+7btFmzMmd99Y82fKpWrjzF33khfcrKQ2v2wKOXzUidoANangsNdTcEi2ljwPEvhZwf0qtcLPueHVG2ZzIxDk55beVYOQLHsDfc0jmoDyh+zWBc5fMpOLAF9QDILZBPrPh3kN/KPdRqXYUiBueOdX+6Ajboml+CSwKTqsXXfvda1h6XJJ7s2inDXpRH8L4hCwVCnavEOYvVGJNX6iVtNCXf+ZAXZWc7vO7Aqvxd11AfeFDHG064cc55eERvFKDvLrjJMlPQgCoDhAVnHkT2obiP6oEFZhErXybQ9Zo+C8JgfcBChaastxGKg9uZlUu+Tu2R6Augj/gaLMJnhrAK3WeCEwug4jFS9Q5ROHTXLDjPpTdeau5Y7qnHsB09590EWp1FE1nf8rw8ibYSsi3SC260sGnMUUmvRWEH1uDFuyCqQ+bUTKWTM7dK1Bt69/yUIm3zM+DHmgt8nvWIf1NcP6Hw0xm4bn0d7L/U/FklYwmpRQYnVpkgekhDLqIGMWrJolQRJqOSBJphbpsdsotY2jvS9EF1qwbX6pBdt6gVCmVLv3GKL8Ahw3wyOfSzoApsbtt8pnDQBUUB2YEs7/8Y2GbYhzSu8rUDGYjX6vJRi739mRof5oevHipfN4LQhhuafbIBdNlb5Ha/aURhDH7M40AyrF9J/Wxwr7wgv1n2qT8MU1vINn3fUhBDunYjgU6wvdu08VXI3pb96VJ8VWnIP+TKKuk7ikTxOZ8x10g5d/XvJTb3kBs/9ENU0jPWbLELhlWVHb8MI/qUisypFv3ME2R6OEmK0iEhwZ1vqwLdTya8EoukbhS/qcJpY8+WOOobsaaL3I5grrbvfPIEAHmd1hNEpPse3Va7WABSUbR6mKZY9s1du9NqRG8klR+L9pjki91vvDaAmRoo6xKFNy/ZhU8cJzYIOPlIFm6h40o4R2pt5UbNpk3Rd4fd5NLoWsegTrDXgRnqy5XH4sQ1PY7JK5wmG0uISv+BV8QVy2cqFrP4dNt2LRr9wAMLa8jEDsZ9TvtFr6YonzEGrjL5SNBkr04RrYy3rIZo9J59jh0fDaOoQjzq2BviUHoJKEPlh4poH6LcD+leFq4x3Tgvj7jgmyUf9LGKevRFp6MkiknjDW6cmeZzDSRHk0/oXr3G6ln4YddqwG0ZRMPhcN6+d7kgWck7XOax+zGxUK8OoLVcH3qBaqMCC8XvVhadw10AAibzzyV8M5h3yMwWU6n9e/CGv9EAyAW/gs5sGuksTd8shLj+hgiySP3akuWcdzT6d1GpPjuvKZA5B0B0q3o7/V6Xd1BL4wt5gs0SC2EwL4oU2vBEqmCKi5lT8j2LrxS9vtWiMSZdQcRf+JMrxmVJ1sAXdXHjTiF65N2qsQrRaCuc7DFzlIgJ/uqAMYy+lYe4ZisZr/6pNFit5FMcDhEqVHYf6nDCyaNhY6Yw5wwPbK5U+6DQfDNzC8ZyBIvZuodrLv3O8d/OjxTUU01aT+rVnzalVnLPthKM81kaN0DzlJlBhOg9M1UEpm0l04GocKEX0gBxxYSw3AmNU4LMtEHirBMfppxuUBu2G+LpAyHyJpE4RuvfUTM+VePwZaL7wkl71miGKb+S7ZlofkQgy6tRbAOF7kBVnu+sRrX9USJ83FklnxfdQgyayEKnRTaEPsZzFL6w226aMPsc0nM4G3W2y4aIuVzfdwkdu7F2F+25SIvdsRuwJUHooXenbJ4b3MYrMDH2tAZcT/n02txvXO3vlFWC/gyP+xbAEch23ea1CIuwZ1mbxiM4uk8XgBJjDK4uX01WSzBZhb5L8WqVLCdNUlGBsuTskdVauQChqrGLyuDIFrnRDojHYvD2OFM9kuv9+wkeh6KnYDWHzpOlVSg5D4H89+NSI5ApS0Eb1H3OXNBEm8jUdT5nliEgKciKIz2ymyB8Ll1Yb8Sad4IPsw0zeia/Udwlx+Ra5eseZ2b78nyNj8Lc4ZoCnTHxsAD+pI28Fpjzgy5FZNMogPfUXXgE3iuZNb8P6r8jXNb6UYrRYjPZdaBOeRmai1oxQpi25eVDXDZ0YhjADdV8Rni/aC+/RSsN7/cAut+QF7ldu4ZDtm4E9x1rVQ5LsIfnjccp4GTejHIQzAe2DJXNDmbQdW0El06z9JOKkK7RHjFsehTHkvJJA5ZxtHazRZA/E/wjLsBFlNHR+vQ9m0E+3FEL0m08NWdewSMlbTIn3rzCAi6RM8pW5Akpg9YtuA9V9psFptPxwJ9ASd/LgNJ1SJGs559JrGcjel7AbOazf/pEq0z8cj3wD7o07tgkVfNfill8OLH9Q+j8p7tedH1k1oQ5ir+ktoUllu1GYptBeGbH0RXW5k9Yed4hcCXtDx3GEkp3pHJ9IMQ2b5HwyTXePHKb3KnbsqVIF03Nm6RpftHL/O2gqtJBY90WnzBTTK2u2fc5WlR7Ba/MtsQ6LN9ZCI75V2s0QxYJwuCQ5iqrnJQq/3mixOGCgRhu7k96fagXF5hV/oWDvKNQGZttcdfzIO04Wcy7/FM3iffBTO8zzd66NNPJLPRyZeu2vVLsERF+t9OWMxEvaiFQzlyQQTKUdLFHXBHngqcBBMRL4kx+Ei59nBkOnDXiYBKpw2bzlXIgRy3S8sv0Las7jbkei1OQx2BuczLNi7ibJ+hZhfDmZ+mBAlVktR5QhiFusfSdZD3SWVir1gx9PpVq1isLxAG+qhMP2JKSC1zLHAJgZ9b3GTv2BPnE042rRQzmUKUnUMtsJS+gZ3XFft/rVPOxhpzoIzuG9AdiPwRCC3wlmplfsHrJrj6sH9FIVpEaNc7UWkHcmol+yF/xLnB6u7cUSlnK9RV99NsA9kn8jV94qSW7ntxKSRS98qmcy9V1+kDr9yifm1RLLZ9PlBu7Emw3J2WPxrmnd8FqKA7raSC7WeE2ehKU/8pgoTZ58QGx2+IMiP1I0nQnMHz3pznegDb0i4wQXrzJzAbf+ZBy30jhQqQKLzfmCWI51t5k7JU9j7m5at1P52Z1gikjKpTELsl3lmdYpE6dE0/8Ua8kH+okYq302kW0OqS3DECTik/CMF0R+u22yYi7CI1Jhj+K0pOBAxNBhHXrvUeVqhVbUaHv9py8e7pDjDaHgqfEwfkxxJpkQ6y7dP80Ksvk8v0woBcdy218ITXoylIIARK8P0jq+hv5OjLhWkHSCmwai8Vu4n0c20J3zwFP8R9p4nl0f8VtKCYHDFe2kLyFcux7eNRPmXIizF2c5yhts0CjoxpAD05VosCVwNb3RRdtukWfEgY32DSjViq2A7A24OG/7gDKp3UGj9WFSfwXzqhL/PJrSQm+8VuhuBiSTo1etEE6YZ8ke53oM2LLmTJcsdEOmCSwd3XpMmf4u30Foj78+s9YVTS2KOsaDKRpyyeGGzuhi8L+nATLApVvFdvUWYfAce/NdtPsSrD73abczWwsiWLJHiPo712QPizq2AtEr3UOiccwCbKBXmYsAovCKvdgxkXloFZuRryDPVZbiS36Fma0n5Y7PNOoh1cJVRRRj+qgGn9FULe933yv5qRts/cY4DlR6HUK5Y6/mF32rmcZOP8Ij7oC3CXBaRAuBwlwzCNfrwUvy3YEKUXE/+SQ2g+eTct1CF+U2oMzqkmkotqF0kmUUo5hbKJAuy1/gudcDXRoss2dSw6xhEr1Q1ORA8kokuFisCMm99hSnCE17bdDsvmSN/gKZ2/RHN4YAnA+Dx9w8h/0xfErfUvozkPReuapsGUu7Y6XAUpHiWnAQfUCRWqIqQwFXxYQHJYDPaTnN6ZWJIprKOK/uHvmfJNzDqPEfs2as1mw8sOpgwQp2nxUn2XRe7N9VitR0QBTAVYUrY5fabxZ9JvWWQYmnG02+QH5Q9q4rDkQGan+ZYM72POcWT/Y5vueTGblrUeKU1vywAck3FKJw8sAl3jCsD3aeBr7QeQ2GSd5g1TfEIesqcoVa4LiBjdBhqTr/kdi5TuFDaowuxqpWMaAE/YNJDWIzj/BHah/mUB22hhVbNXEokV+0JaH+mQfyx3KSr9ifrbwH0yiT/TZ8luRMx+Z9BPioGsziTFw5d7wWJ85bOX1n5x1Tp8YK1qwCZg6cPLTE6kTTewXnE23Ri2hP7gYU+CzCnXhgFnVUnzD30ncdi2YTV5ZxNI6x7yDfsqNxmeNYiT7d9TW56c5CjLtD7GAu16BOJPqk2GVFvzJEHLnCRtAatRBHsIAmY/EegVisxvyFCuA2woAPJ1SgAV17IztrqZZUfsoAltlKD5PhCCkTU3ao67VKXcX2reOW/NoJ9JEx/9ZiJW/5pXHDrV/MmWy6PchkHYoDO496cEDGpVLNE4QKP6LnTTYZiDz7LHlF89UAK5TycNXpnRoNLWCOOK5w2uuuHM2BttIGalGi4LIZcohX2hKlVbJG0fS8gurhScRiOnOaaFkp3p7puQ46I+dHm/+BLct9IGIw3XYUH2qgAiSQvwbiQPOsIXVb2H9WjMNkqDNJuQr8x4ZYSKi/k/Raf/pSu4YRklhGMY72mgO14hYH6dNRlDhrmQSx/TaGD9zGLRbuSabEcM3wvhtQcirPPpFhn3TuwRns1YpeGsxVZqx1nznZI/6DGAGtOKLKXHrwrRu8J4lEq0wp5C+z2aNDMeWCtGUJeTbUZJXabf0kuDSGQvcEaOJ1CqN6aT4GIrbUAx7CXInpQbhMdetDCdOOEHDQUsmwNtBZ9RLC7ZtMfPhW75nRUaOQ4SbHFFl9nk/1teRdFIMhjrabIIVyM9ySEYxnNw8hsy5f+YSmH+bDajwdnDF+2f5XxkMvufzMWKZvvymn4PxxA8MRkjev2CmSAr9Q7am7PRB37pRgCSfnwhdKtz98m8xJtmxW8HFHY+vNp3omCmVGaxrfT9Nsh0Q4/4XY6wdfVfE+254GwBJSiEJy9kei3vKZzKmAEJ9bs3gAcFobkNIrjB3NMqrzjN20DBm90ISUAzLCHzzjrvML0qXllMg2ZrAPeZNOdiFfM/44mSRWLl+5jHNf60shvmWJLEwj9X+34Z/W92jmyp17u2qs44fF/E44D7uKLZreRqraEZtTCUP9PQSAJxVGALEq00zuBXQV0uic+c52FbYkdlSWLQTN+VaaAfzTHK32Zw6Wv0jG97wH3Ze/hSkY/n7qReTVWnpItcsXRcB9Oukqg7gfbQIXjVU68lrVa41RpQavN2+OxQ0zpmxXlAxj2VqkMOPYm9LifBxyDOpLynMuZcTzEGveKIbuPuShtjW+BMs+doxZZSOsyJuRP7we39KUIIC8n+dOunkk0Yog+02UbO0c/0otNr/8TtwoBZ2EDFerRyZTE5Rc+BRJg+pmEa5Vhwy0xaTodwldha439F9D9pvmYf87rwLaqcdeMNB648YzltoVgK48bRvro0bIF+JuBNGEs3rINmiXQwawoRoq+HBIYvBmDvPUVsVoi7Y7Jo+/MRqg2B9I7HEc+Y67T96CBK+iJ1GfiLuQAC79eIDPqU91PwnvkaXBhtXndkU4nRTSP7ofx+E1RiLolRLH8Qdg+t7DZkx3LhFPKlwhz2m28XJVhPxMagywmnVP3FktQY2dfCfltlv7qsyA7gyViBlfv+YYmXfC2Pk80GisorjE6h0LrRVrmToDkbZtSr79pig6ywhdLaYVf2Ip7B4QcWU20U+Bu+zFI+IbVkDIJgDdUpd42qJA8cpZCL2MQ4b+lrBb25MzRIlT1Jv3p+OeZjWCr/gkZ7SOKN5v8qXKTHgB5kgi+XIG9HdfsTkReExv7dNOCkbrVocct083D+UmF4MxqaHWWizPvAuDJtlZksMdqBSPts85AXT3lYJUrNbA823NDBm3jZ0dR23ph7AH9S1+3DFxu5jYqEHGB9NlWj+OO7pjhnRB692k/8kXNs6bPmD+ylOCE+Rr6ie5MX6gDeAoS/3jUcgBNFJiKX2L4ka2bqIYJUX6NFiKFZ37IOxsrxXKpSOSOq2CtcGXTfFhGccCkejBaasGwk1jdZHcSZh58mCABtn2eRHwPQVvryR02TOpUdN/oCux0e89zARgxtkxVbBAaS+8Vp0f0d0OpPaMR/AWLnlMkOcQokaGNaYkjAqe55XBHOFi53KpQoHDKlq4hZYH9ssaaNsjaua8FP9o8L1FDtRNso1JzCz4UOljDTrWal7rPYdSOJn5tFpMgcMnOYdn94MlCJsSiWaUE5yrv/pFtKYmc77JA3gZ15V1AE7kzRpxrshe/Tiz2iK83zN+AB/GbuMK9Y6CVSeoQOCyZY+pWCyXM+hQonZLhT10ylSG4JkSV58/3zXVwfEQmCG4/AfDePEWfcHNBfJfCf4ma+2PMUrOY7iUG2GiMnE07WBKNtNFtgvWjx5Ep+XGnbQXz2Gu8dggC079zxSIxmmhDZOBY5/hP2pfLrSYMBJLQuQ2CXkqioDqs3puSfVWPtrNF7z1IIijI+d33G1Uh9B4qlL1oVwzqGpCK6kC4a0teNXASeHvUYTqa9+NDOsIUzdz1Ei+eCKUO1+2U//S4W2yCyV/Axm9nhQ5WPZ6SbV7xBvurT7zhMbe7i8MhpwBvjjxQqzRpmZe1cSWLSDXmzP2YaExEWoAXESh1shFIV75mNlPhucePvpJBqN0yFypE9+Of03OmeCqKo4VaHamjRYpZ7gPby+StHvb6Bxn/IgryglY6CCv+n4LbvaZtexV2IChW/3H4KAkbkKwgT1QwXNDpim+a4k9V9PmIzRNzjzA6wh6K45iwAjLiTAN45wB7oOx/mAFzDZQeL2wYgWFEalEIbtHDuxWSvcV7tG2ONxeSxTUnO2PFa2GGs1J2/NwY+TQUfWmO4ORuKhVZZIla8yTH21MLKPf8wk6/KJ5HbEviG2UtN12GjhrJsZMexO08j/hf8MYZENcwpaDXieUWADUNhRdA6DL1uieGOL7byyhCpo599B4sdxwK+1ByLjq/5jDI+aITCv9CUaLM6rA1VFiuCOOVecIIo9VqBfeD086faxX93LBrF1pfs9cBh6DQ/Xorg5pqYQ90LgFZ3eDptwbb0G6JDWTHLw/pfPbmnzGBIh0QME1/pYd4fgyzZxHiQrp0HsI2ITk8ZgocU5WPdeqG0ue2CXLWXJLjapiJfW/Ziqxj2L0VhFKAN6Qtw27MXEr+Yu8SRLugQe8VNcEQ1KW8E4ORcK1pm7HNoUg/99pgcnoZQR4prPlOM4e7XyunhHLf5/ldjQjftS/Q+pgmBSlUBBE25xRZCiZWqVpMONfIL07LNMd+ZFSZRWgdq01zPSxXo/KIPo/xhhu/Y4V2FBxqf5vR7ETnfDjLLMIRx+IPhdz7oO4MZKJ3sAIP7iC8inZCVqMzWqECTpM0vdu2bWV1So2mAZp2BBzsOk5dZsDQ4jpGrhULdfJp5ODvVjnAU/5WeIVTuerQ1dLlCC+0JG7ZKFz4fOgTyRn7BYnjj2BYaN8vbHDfB+D9yzFYvYxWe3HJTYRQpIH+1/BU6LhEavCJQdEbSxc7tsBpc5FDqhqOVF/0qd4yoE5rw59NPt3Lc/qm9L+iMs5s5gad4rbfhkK+rIA5lYXvNzqcUXUvIllSxZ2kCQUT54PX8JP5jS12L2LSJVn9y5qHomazAZOHnPzONtiqOm8j2r0PKP7HppBdPBhIquDTcaoO1ks77DZqpe3C0k+rwR6zyBXhgRJ4ySFPKPTP94RkOQLep9p5VUCyC1v94LfYSpCx6zTcmXLwZ8xGMgHtWb0R87/whUlk0CAUaLFWDOL/NqaCimQuFvzD+Zj/ZZZIXWiKF2FOW6n+94P7IkHzRy0c2fxQeh8E66JVZtuNIvMLrEBuEW/ntFkGLqRJmPopk0Pv4EcqTdN7sVoFcKlWhtCiL9tAnpg+i6VrkvqD9JwQbmaErMublwPTLDmIXn0NwzwXuaQUOKKVAf1Klh8O79aA4p1/xvL2ILekHL9OU+synstG6XVQxe1hNYZjan9gR3u21CUqbs2J1hD0wOLv55o0Zb3xBCo8WJqRLHLADWZ0V4naQvlXfeXsxNptirdUh8JSFyAJ3g7uxzrnlNq4U2vcb00gUNyAWbqzC+YXg/1dumyMLncBJjD3zDPeT8k9hgJpNb1yByfPSGG8XXOM4Kjjjxm64lY+XE5CF7yuqLHhetBT7V5361Ke8ZOG+BAtNYAyxWba08kqpOIqB4QV5RzKpmIDjFY77uSCqyaZPsfTHBW/9g9r+URWtjpftJIMl7A5h5u2JYP3Vb3NReFw1vcv5E2IgbFfEq4aCZR+JvhqQLJRLD7Yy13Pp/RuXADlCl+QriEofCOFvs1xIkNsRo/9HpSywMiqorKAmJF6qj1GKzsDs9eUifdzgqkPJJZ1WUnjelcmoTB9h0v3nkSVzG85Ep4mPiqPIFWc+Zpwy7+gZ4Us9wrR2hPneeElq/WUXRbIMErcByzZq6fIfQEt3BIqzlqkRjv1z28XChH7XjGAqNh3wo1yecFSJTZXkWHF+DBBfo/z3kHFZCtDMccPf6P05RE9Hm9kf0quhjEd5nuNM2FKb1Yn7HR42T4iaUqfhMvbNu2WIcRQc9wTTjlqSBtSrViohvrbDtTfDXOZ0u05sA+B54bOuOlW/OLywou05JT9Arkjn4o8MUf3JYD33FXoviMTs59aC92ALFSff1loRV52DFHwAGqnFoTP7iB7zcfELBw9Ni13pfsH72jEVnEzjporpr/TjC6d4r80RiqXtnIhWMoBS1UFolsRifX5UGH9yNQyRNq3/MIo1NkJHubSWki5D+Rp8SdYOeqdLQ0fg+6lga0e4Y4SMsp1oM2xAGy/JWhWsr/RAzTMFGQA/JhKY/ob9wiY4wXk3O8Td70jjMULusNSnzfIYK/+tSavkqvc1M/ne/UpOerPBDsDHFVzeBtt3eKKrRypBQ5QhtozgzG+hleLQrGeFr2aqWSuUGHTqbXG2H1NNpcSPBtitsmf6A70Ku8Rh9B4H4nzxpgIPgwBFe8n+kJlbt/yAapVem4Lt0Aj2P9tQScE8E1r9ycdMTL5oxBgy9lF+SeLHb+EF1z9E6abYLsX9k7iPtKZekJgjlTECPSsYz8TzfYh0TNlRw6hhPAKXhRkc5sVxSPsSphmvJzwFvuAsVyHu+6Ga175mSpytM2DfmqvAbtLafLEv6THtuoSXkkQaVemQdlUSPWQPIGU+CGJDJGnH7YcOFNtj2uNNASnd5ry7Ywi+H2oSzGfkehk5I4AfkmYnnuxywAQ669f0u/zuUhYJwKttVnGvhuozLDqNdklrWLohzfZP6hMuQiBZ92ZYvD+nVGN54n0a7LIFILgUDoFVfYRjuxhdNxUKr4QxQ+rtJOF7/pslYJSYZ0/bzrH2+7NPYGqCFUaBOKMF3Tt+slAnzbMXGQYdzxDy5bNXqe1F6NTIDrwZI28sKy4IduljW8h2KmBf9HlSPNmeKzTQb5EqnMa90RdugFm3kLShr7V+Ka8inGhTptqne/Zo+lyUeYIbIsWk600lkq0GononKqEVs5H9ESn9gr6hhE3SdY1+o/iwmdyEOmGvyeR9f0xD/Xg7bsQrvmDINTuQcfcIE4X8B+5PcXfy6HT+o4ghIzjghQdquTUWjE/D9h+LHnAqz9DkmZbjvtrbjEkQGsU7nso2b6LRx7XbAbcc2dR47Icx2f1iO+AtN2Zg9d48tsfCBHvRbhx0nwL6TZhjRdJGTeszt6YZFKXP8mNthVI4noWtPLApCGuxUDkDrvFG3rT5Qy8c7rMKqXHNyKcqi7GpswlDpxpfVAbt9+UKrTn8MKuhNajgfbhss+uQXrRvY+BvusgGEi3FWumf68CyysPXz8xUwiZ3gO8latgZwqeNTgZw/wwU0HM8cnYCDjdfHXRoVsp5iwOinEbBTmYhaQxF+vQCzRoHpd1nZGqFSGYhyaAOMY9spE5aN1SbU5vqVME4Sfjh/l97iUFuHABjXLtyiqXDPaY4FR95EszfpTbfIzyXWybBI3hQHuaCT6mBFO9XPST6ELuRsCwB9CEOF5AdMo/QpWwkzaqzyM0nB51TnmiL6NLpXhrnvammGjgyRjnd5aQ+qaZS5xm05bLbCBXqFEBh9n8TVba+owdq7F7b5BuYC2iCKo4xz0xw+k70Mhwhb/4H/MTIkOz1X7CDlNMo0dCPYTkdR7B7+0PuEC2nyWz1y5eBGl9yVHvZVnF5zZbKbhZs0w7UtagydJkbv8cDhJbKwiO9mQtWMc3YnmVvLJdyg8UXW8Oa3+5mVxMRukC/KTVuyexgRy7DzKC7Z6MBBZwaGxAmySGHjKEZvQUbPCMN4FNk5pLIJTqZsoRK6G/50T7NaB9t4/mSNXhO58ZiatcpeH+9Or2/QyduhhxgFpQIphTSczDs5gwkTdBJTZEulf0BB6RRyOCU4S+VLRIuK1MebHmlqfsIgKuqk6of1PxkEfo8Nau2enwtONmW9JlMRyBhe3eOVw+yzwjEsTLLyJf/PkFTP2JD9dt4MvFO2nHKNCgvhTNyTUUGId44Naag2bPK9siteX6HUHPdoqs31T8t1qyRKpAMJ9tdZxRrHR4DDBSwyTfFfMHPFmkftYDDuNzilLhuuXWzuQCPJXn/oz5R2ObSGs38FYOct/YE8s8qzmZzcg9reILMKoFNcDPnRN3DqiTplzMWcQovoTno1lfBahkN51yVNvYEOA8hvHppa7AO63Df5E07ZxReHQulMi1L1IpwkunO0LpJBirYElXnBZ0i+A3RmU9IgimjUR/ZjjAGk+5a02WsDbJ81H6gn74Yoej13FtCdhUrAE8EeGQLAle/mNGtH/fTtqDbmaUMESRyxrpwhM6C7G2md5kW8s3FfBmkp2uwQhiOIzdz0q1qfG6/jZU5B7qA1Ct83mCsikcvAPyyhulU+w9Yraa4VkmHKDFT6Xb/sX8I06H02WZDMcUbhiPfGz1hFZxB2r8w4kM1ahzSi/M8tdeKP6uRfzsd+SA4WeXi2ky29UAqHmXLnxsgrkQwGAmSrlBcY1V4TQN2r41RnmfUMi+NKvKUV34EF5YLVq9NJKp2tMitycBkW/gCWqTcAIkT1/FHTMiwfCGZLIhw9TrosQ27Iidu1sKaNT5zvMbP24YOyaT/o305ctTf0o58AhOf9bFKFEXs6U/hYIdt0yEabkNh9+tWZU8m+jqjpj3nqTbsot7+G2DkvZwGWchh9UeWm+Cd8voSK4XALQdhafRtYbvJp9OiOtfD+OsPZFxZazLdBFWZLsDXrNQL2FM+63BPhCTocAYZb0HHDNOFrx4wGE9qtuFr9h6YcU95dZC2OBsF7QqvzE1DPkXisMF6pecj3HG4v/1TaaK9dM5SbF03IjMuwWd2wLTKh77Ll9kyXMoU6WZ4AGSrtXrh5tqT7xiOAMkaJV2z28mgPSUOCHSA7X60G9MrN2Gt5lfYnNVRiiZkm85S6PHcqG9R9wvjr9tnksxuUi8dCl9wefMv0IspjMPiVwxEL6UzRLjC+lZxfiYwmEpnBZhjqWQBa10nM5G/lahfEFnHys6VsP2/I1c51U+E6wAJAmT7vs4EiUKlfktnXRphPdaApuwaS0BsaRsV8bLdZl5w/LbHZhxE/xvn8BMh6NRTXIt9YrdZVYHinbQJbjF76g9DCqBCl+EIibaa1e1vhk54kcSfsV4ndDhvbNtYs2UpNIhNn+pNUg4SY97chKJpnFXJE9nmM269SlBBN00ftuHbkMVow/bbBk/EUVj6G6CnIp8QHQvo9KumeAPF4ngsdA32jJM+u5CJCpxHYHUeWCVtSoS3r0Ciwb4FTDrkcYpHT4rBWYJU7GVzSC07Ij/zUZv222GLFXq2D+ng3w2ugIXSyGU9N4n/PaG0su4otaddjqlCVlMex8jck1bJdOsiLVSaHpOxCBRgy4cfVppDuuiBI9+5rE10SkBHYkjcpmlHy/CrP8YM0rieyWAbwdw94FR1rNgwxiTRbm0vg5IVmxp4TTMq+IzVif1O8iwZYOZ5MmQf6D7KRWM8xm77tKmPoY3j5p/6s8FXLmjmJD/NozwgmQ1DQhxkgWK6GPwnjNaitQe58CdeJgpRp+KMh4rB70Y3NRmnxpmep13joRRCTlksi7I1eF2CvFS1PdngVuokjWGa3wuQ3RgrhPhtSd8QasOQ7wtEb1B5it+gs07VGC6ZExzh1bKvUDXB/4qlYwXop955rJHmW6f0FolFvPtCS8YAKwjDrcwkWM4zMLt9rAckdSE16ROOAP0O+5gz8SOeB4RfllgEuVE2jJc2IehPsbtc0x/XylxDsrdyDojqX9C8qi1yvmpXW0/4+k1ZHrNQGi4muxBE3ziGCiAMZGZXO/VIEaDsXxJDhTBkAsDrBMZpJBhCzUHHGU5FDYb+onm4ohPbuXbkffGNmpv25+V9LE+CS87p1krC0UuyU6sBVa3e6PdVGhAM6HgV7u4KX1OQpyUdwJPejJsFb/nohm9jUDpk3f/DVnrZooeDFFGpqM2qZbg5Z3WQxBfssH4JXQs74t1AtduMhBV7r8ELXHJ2EVsjQZyyX8kG1J5zIfTF5+QGyeKpEd8yHlCEvSZel3w0Dmfe+kN9mhHcKpcYP0DXP35RbN7HGAp1/IipU2hAXzaZPWAsNLufQThV072slQqsVZmoVIA9wyoRVz9k8es89TK0JrXHpjKq3h8AGgFyqNHwpoOLRWjGrnLEPXpGcxjQun+poisgeVQ1I1erZEseAx78Ld/p4QsE7MfQ66yN9F6r9+Ed3nwXPVib2Xb/PPhkmjjkB4Kr0285auO1x3IYNkF9WSMVVAnhr8JhHcYwhWZ9QCYBSp7SLbbwee5xGZ/7BMaDyF9scKZlnlMV2hN37uI3PoyUiaYhh/Q/lPzlQyximl7r2sIYy1za1/yPYUrMC4GZPbU8KDWc/FLI+jBdxd5BUBUWlzRfM3BUiWIXDMSyr7M4o8brAB8BvhgcA68pGsY7TULhHemXlR27iQOOqXYlV/sREm16FzMbVacopGHniYRP2Q5KIqwx5h/xBUqHsF4tGj6jf9u0+UZhXq1A1oxFMkh8xOrQxs7oUvxdRAE60xZge3mR5eQM/3JU2pvPo27NkYdTpexY3SrwBpdvG/15rugmw/fRDirYLFYTl7hgScbbwI8LNBFlMl54ieSCKIWxtDj9zxv3AyBRjYni0bplzlLKKBKNv7pGQ02Ape9zvEUvknDVCbjUnmlqtU3/W5P39I1WWUEXjiT4DGsSybegLgr8+gwiwatP5tyzWQSMkRdMXqUMCLRK6YGO9w4hmpapU3cWF/WtNAhyYA6nQKYe4llh4K9i5tA7s5S4VVz+e7SxS2COT4rAxdf6f0QFgjltAS81yoJDprTC7gsI5Pu21E3Ggnzd2FClKVgL+c2JBn3lBx5JnXEsa5p1wM2x3xyCX+gBJ0nL4x+RI3TgNdxgxDsCk9AfB+HvuYFkWDcqMOis9WqPNdIG3hx+xzuOMm8J16wU+rj7s3ZMxv5123OmJ6Gi7ECOhBpFSKYRyHSHinFvvSH4NoVgjbejWr8yLR35ftuk2SfK/YASz7odKyMINqOIvhSMe06SSkD1S/AJ9SCkFboTQWZI/Qtxc5Z/QO5la2Ep4O9TRQjvbVR5OANvmJm+d1+sfvIz+Y4lUIlT1fzEHvXTCTb9CAYinEa+wqul7RIg63SlYMa300p7zG2Y6uJHfVvwSnG6AJ47EaUJAXw258K96LnOexyPZxeiMd/wDemmSu+lfdQzeJe/883aIH9jumrmku1IVLG89Rm0ZohzRH5SFsS+vIqFbSBXa1Yj/TUIcGHv48WwLmMYvB7aVZxHoVgzaMEHgd5melwjTqhSG48F7XmhTBn9JhC38TL7MKyvG9mMOwXy/zQxWMVA2ZzHM0kMhEeG2SQvlK2eN1+kBdoysJ/UfQhrSYKW754X9FpRTkVbTtK69oI6hrjyit0ZA7feNlI9kGXLvLoEmuGVf7A2uqEEnYhrnnBTe+GlVx3h5srUOUn24X3j4B1DVj2rGImSWB9SELzD96mtKGDvWpBe7NEz/2NYLvVZFx9Y4wv0DwOb+snFqQ/ktl8FrCRzObU4e32714r0sh6Kt8Cm0b1FzKdzNq3jkVsKUdLeJojNcud2QKLaYQacKjEULF5qV+UhH5TgCjJ+nINNl5AZ+6+CGkSuTKkDrQmC9e7ie5PgXbhx/l1H+ZCFNekvS3QhJyWcT7HFfrZPcaf7XUU4f/ZLaWsXI8wmuJ9oG/GFBj484/A5yJQ3wGqN91TJNsIZwuQfIqYalYHcxDI3Cog44nq+2C3XAjwroqQQnzNeQNdtnHVAfpFNxNuKQL4jf+B795bRYw1JNK1l2FyZ2pFtGv6hh6nreU/S7X7Vw+yZVY4Eg7u2Gw9g9rs/0gS2NxO45cSYnSNkFnBnSGrxzbZy0Ui/yezU0BpZU/2nnpw7TvAWi8IPRigLChFkKP9HuezafCCTIiiVfeGy+MEVYpkkEt/arWJxDikr/TNMRrAE4fhFNe2nznx3LxN82/BYfXwBWGRXGkyljwIkv4nSrWPePzs+xvlBg7ZIGvnGqlR/h6lsbjDVCHPXVgtIAOVb2wdEUZNKGuKv+4UyDsWhnaYR9uWji2evsuAovN3mV56QqaaM8GR8rWEJoD0kX6fKsw6tIE8hug2MHoay0Vqv45hC7DjH33V3mK63cpwZU3CLeaUKyNPkpnrh/ZAXOHsESd2F8PL3WIJfV3Ado9yEy7lQ1Iiy2tCoGQQTBgH1cYxihvHYzrCcJhF4KUVKh/NyZfn7Jm2+9R4VnwiZfjt3n0vjz+l8lXqOqbObFn5hD5tuoVN8YQNcyxE2if3Co+ZgbWqU+4ckgy0Q1J/i7TmmXFQJP3doFNmSe5PAu/pvuSU3wuD4PnGdq1cKbEIRd3A1R0WxusYOYCbcP4f2s3GblI5JPDOvYoZJTyQYDLUI7crcvY5CmI0O1DeFDUXwSry3DwJF8IqHaKBF4tmOu6RfYnIA0+uWegHaqVFK7fme2DHKLHabxR1Z45wBTfYAprhTuhgJHvBzYr/c8y6ilSM2M6CZDhfz/k+FPPh3Imn9S26GH+R65U17tPgGaRQrnD9XTaRTCrGmYkDbSaVO8aqjMBd1XIGXaahwk6GvwNgR+a0lmg/w/BjaKASP3ZQpJQfMLbD7jgbvNdxc21eGHiSagShlHNYDXQ41swrwU4vl34aiGVLaY5JUnsnGxU2b4GbegjuwWPcfZEGKbCcIvrEKw/0o1C5gWD1BavJpVE9okyspV67h+stgB4le5oFczfnypX+r+FZKF0NI0COa4cx1zzO0jYaD6F3mM60ylUIkSDx3AcS7H3Etz+V+Zem3rRLFTBGXTmKUzvyR6Oqnn5kgN67gxRI8lct0O+x4PYNRGYrd+CCsaYXKgJV9vxPrRh5Ki2z5zhNHKQHngN5E+6+nIBY6H7icsVfJI0xAyCvkwvFV0+bIjvEDue8yVspRZAgNq4JjNDsSLi/mtPpBk2b8b/JZOAANCqZNy0L+6NYeKPSlzpDmtY1LpHliPPVOfUoYXaUuulVhjDe1IG0kezI8w3pMV79ZyCDT/ZfPaJmQ5xBbQ4HcYs/D2bvYgS/58FZ5cuHHE65VEsaMEEr11FJ/NYQ7vcXqCNShrpNcpVc+VQ+ezRqwOiwIur5xw3uOLAga2PaPgHb+O3ZZRcroMgwReMD4BH1yBe7yZcjW3QE2IyIegYlkJ/M+93Ain1PXqy13AmuVmK/HEH3UGo/XlNnvHJp3MwxqwSI9nBmmcM3zOhRM2pZcgwRpS4w1MfmQLaPn4HSNXzhr5YokPQLI/vX5NNADzuDZ980RiDPOzUK4y5aVjlilAMmHP4FE/XqFYZrv3dkcA056fxKWmwCr1xSfwUoyi2Yck8KmDnh27JB+NsKYZUdCBPEmBUo/xFheWnHdyQM/J2IOy4rXkcPpcvttN8G/Obzrls3IqZEzDNZjNTncZtsADgVdYGvPIkfkigNlrFBkQ3gfwFLcHhXJMMsfQDVyNCiKVqOKBLZ8+r+ugLke1npuG0S6vUQ2u+7yJwiOJ42P/PHHqV+xjEZr7OHOvGFl42lvrowJGr5Gd8+QLbGMmdpk2HVf3dB3L3ErY5cQWnt9QIVLdxF9YeLblX1Y1Z9gjP7BRsx0GiStk+huQtmnv0h2mhKDyeR4vwyEynP38wZ8APf5liL3unAVKXqftYRSLeEU7O9GHGdjmjJAvtmOJDdDzerB30F7fuayV5C9C9XXOrLuIMgbwIaZlz012+Ka6N+S5L5r2MXzPNgd5PsBjmO8CKapobRfzjEoT5GG6HAaDD12oncRDFVq/yG4wrnJG1/3xD7ckpn1qTIcJItU/oYxwNVZ6C1ekrBkZlx/gCZDUQ1h+yhWXWrTzNMqb0JbtXfs+o5Ec3k3OG16M3ctrrUyZ3XQbhN1EEf+Z1DGiYNftBjmUEsxugQPUPl0u+QoCO8c46lb1y87pKYu+P38UGieEhye18/sqpU7PoE4kgtwyjVav5LowPIsHULUMVm3hdOrRLMpgLajLgI3pYzTPVbsTggg226WSXqFucH69szNYX9nXEYCLPnQ1kue2h+1xLGkIlalDcfDQXgvnchFMr5pOmD4rbQ3f3vow5bg0t3J1o83+bwBlA18o+AkvE8QpiR70p77ZY04NO3hmrRpJzB7LoNgD9pF+076x2JWaUuTeHAYBQcR0D7CNglvm7gO8XV6HRdizdSHIPjOGj1y6q/9Jp6TyakaBBca3VAVClMca1So9dvIp+MGkh/EIOUHoaXaC6GN8tygrAK4k/zBvfejgQ4h8T9QrUyEy8Xp7MtN06Ja7Q+0h79UvteONWaZpdic/vRVSb6ViU5gV9auw/EvGEUgiIbLScZx+mNrz1KOoDp3GNtDW6qHUrmjgoqY5XbJTGYTQP11nOEJIWhwx0tU3CL2XJgAQ9FPfWxoUJ+7gN10DywY4+uDFg/txLzqI8hCTc/6Qi9GfhiUoevd9xNJ7nH6l3G+p94ruarTlkHfnlXw0aUW7RmUReeKVQYdEbfy1pWpfKKokIVEJ/63q4i0SbzJGsK9wMrMAQzfRCmFSm38xKAvtRrGsc1CUD3zALvm818Eq8gzYXkuNsLADpwocK77F8Fdyg5Xb5Y6iPVtEXltgFd1vo+1i1PYYb2Hc8GEVvjTLBQfQ0iEcPybJrSOF9+mOxGMQ/ccn2Mau6kfijyiPVYrYgDl6/mupAKvdbpiZSOZuNJ6V6A5BT0X1baDBS5fmdglXQjXQwz2+6gADqibsQ78cc3V8fSd8OJ8cGsIxtBSmsxO8Cs1MMH8KRFTxqyyrVbk/rlLrznnNL/xjdX8VClU474CSm/tyLTvKkr9tinVmEM7QSzWI45raClu8dqXYS6lwtgUZglWox4HdFIHsKQv4GoUODKq1vI2E/NdO5I4nKmQVxMLsHcX090fh0ORrOa0LxL7FkiMwgXsPg9QGkJ/zbmPaFoMf9VzCwWsCBJvlXysJxDk2k6n9vUReSNoeyFacd5jUQ4GgijBfuP5DlLnsDWyC0/BY8ttwHSLfSRHXEOYO1VGCSt4ToCaPLD2munuGG2Zt2kTFqxpn5VyHrXuFskj/BKPQdS5y7RWK5hU898kfOQVXkC6kr5GetvX0ILEzLGepn0jynbdZ4KP4I1HEXL5XGI7vvWoQcPg+Npv3Wd+8BoYpSvwT2MlDsoR6W57YNaHkBjUqweKDwzC1TPBGeZKvVMhJ/4hmYzohaQMI0ilr6odI4c/sF009l3IaYXLsoRnpr/7FYaCWsEbVqqXvbxelAJeG1L8Upj7II6HP2HM2M3TnJKo678z191flMBxspr4YVZYJXnhJ/9SRBv06xV+4NX7cIpFXDSeYAM27rYnOUUsCo9h647Gw2yKwWgTGVfKboIITwLw6DcB26h6O+SdQF63cNyUFceZVLb57kAza+m09CZXjeoNKxV9+aPw/a/zFNXtg05qMZ0f4NYtn4ImkSxfvSthZPj0LzYyrEdB5/spsiiqZnCd0uujuJqUu28T6KBqcp62MDLsehFPiqOIxkxeEs73rEU43nfSfQcxqO2XNKcDqTzZnneCKFX9NC5w5SbgGSQ5lKIa1axQtk5DHJX7P0I6xdPbYO1E/CBLiX9zWuWssS+6FzAu4//Jh7BOoqFYXieRzaiVn6SJRsfh2fetXwhig74bRpiB6ySanDhJ9RvjXD/AZspSy03zLXUSq/QRplqsNgEMukNdxYPRH9W64MmWlGyuY3FXnsXAr0hBHgvHYu0vIfTOhkzXMmknDMQNRzFFKOKLGchiG+rMlis036kAhUe5FxnAcZ8aO33Ewg9ZDhpPHGdk8C8kSMNx+hazKjP7jeJ0P/toGLSTIHZeh+MLUfOAxe49OkYHL+mM8D5BeugxWawqkwVeMU+KB3wwRFWs+IvpY8bbYY2wtV6YBdxnD4zWRaAN9rzmGrySuYuadt/xhQ9J8iL0bCrSo6to5GKlId5TyLJJc1vm08WvMTTdqdQmOB2gj5j3rthmQP8pnXeqVr78jaDIVR6h3Vfyl67wx36CquWsxSnx2TSXXQIAWwLhd8Tbhy+6MClOBDwYo5JcaQD71vNeJlAN33u1FA48T7iZdCDy7JgiyqaguwV824X6pI8ZwfwKc8wyWEp2VzWTjUqmj03j4b0lXnjPljAfJ+1TFhdRX9gF4Sru4rC43rngkhtlOOnmTvexalJpNG3yFRBeyUR7baT3c4bZPTuRo/UMnnbQ6/s0vLPFDbv6MRl2e12agNjSih49cERf8upYR3YdcygEjEPxnfbgPzkxFsx6H4PQvGS1weig50XtcLgGvuWrBHI1aVXe8xnbTlQ5wpRr2scpp37KOxLbo+qjCRzKAYe85zpCa3To0i0mjBNuvch2DR/SjaAUXO7WxO+948JbvaMvngFNTsRHwHO616DYEXBjYbw1Vp+RWlG3cDibb0TI5nAj3HY2ymiPbXWvynUMXmn2WAQJ21c4/o0F8ZVgtkm+WDr5oKvRbLLx1zGZZB8lexkrvxCmBKJC+wwpl650AcqCt5/jRB8pJYSd+4LdVpdjsZ5SvTiNd78zndRpG8w/ZaUpRKhM90qmuezn4Aj8kf2FQNmjWtxhSKXBrJMW4krdYDvtoetCYIxzTqRfcUry76qI9Nb/s+A59opv8A4XcPiedxEl3vfVK7EGWXVaRKhehjgRfBYOlO3HXnQ09etTdmPied5pFixfobeIk43GLEB7TULKR8IZG5LRK3mIvG+pvS8wlQLdA2na7ZIqzre0IkPvIB4kXO9TmEo9YL8CEwdrDIiEDXqgJIcfJOBcoWb57HWYdlsRBewHElXD57zlUXRWClvXQcl1i5KM+EML3+fduVM27Kl1IIqfeR6WeoCOF9JRRn4v+IaxGb5Z9fVbEJUe8g/BiN5TvcHcROOLK7mfiRzTcie9LoMZM3cx3IRY8StUm9Me5bt3syhaQP/SlM1QHwVrBBFl/I+mYO8YvkL6Vx1HmrJskT0moG5NdjjVk5u2qXxfWtTwe8Td2tOtBk6yiTWAiEY0X6l3VInBlwhKgUekkOom6SPIa0J1ejfgi8ONuhP+GzlC1TwvIxzecn4MnziiZc2SrhdqEB924aSfyEFMHtjnAE2hI/rH8ExJRFqzHVd+0KxPbTGH3XuVTgmWBrHk4pW/S8guhatyNS9xs+XgO6mXBMI1doOzCTxT2yJsin/9SqGotHIHmgbOxkct+W5zwZt6M2j53B6YYgB4rqcwA2VXvHNM6m/Q1AwA+g0Hlr/i6vh8wR7kQLXfTVVkR625AUnWrpCGErstWHLoEKHk2M3EBe+WV4ya5pgZ7NlvW6Zya090yW3G2QSq36VjOmv8UQfOQFK9q4J07dLBY3C07I3j9dIqtT8zQcaObItmGAI+ugSKeXVB+MAvduomKsL4XwCnTAD86A4rwUQpZy8wBbLVO7dfJs0e1CucRG49WTG6B70o0wpAFejNR5Jjnd0a6Rzx0KnDgUk4MuV4gG+nGvRznkQZ3wSR+pTwntnkOLMvtq6LJg4EqoyxLQeaomVmQD/rYSZ3GH6ZTAzWW4VBR/D784hiv/unhi4e87GO3A38dNJ1Wxvdo2Kv6CG5H1eMmpSmNWzh6LA1MjjbdslTOA1JyO8h7GRgZjow3ke6LfTr7rPv+5KApePHORBayhYPWxNo9Bcw42gCNLscu3NPdkhi8SjHXPlKqFVfczuTnTEeIputz5t1za9gd0HGbCmndHxaxNWbYeaQ/eH2jKU5N8iWMJlVieesaLOOVaKUwYCdMmltqBNPnsob/SjCYK/VrPRtXtSyEMQr4SnfvWi/GwYOoOQ8EHPntHLACt63i8HDzDFn8ypONsq1R4zAFYvECbb/fOKZ/ktFyY221NOt2ybpeoU3L+tCbZkUepNmiD2x9Op31pimEZzTV8V4ifK+wO9yivAcJXhDFn8hvDjyx45joX4gJPtv4N5qTM/AxiSnbUNeZ+H+0PyBWa6U2t/gi0yozCVtySgEVmHy8ZqcGUhVvGjj1iz6BE3TxzEdOcVBqlW/otH74mrPCNvOFsQ8sEsRPbTrh5jG32toHiJmQ07UV+mj3sdkvVBHdQONkd9uYxafOeGvojBEsrpAq80Id03hRso9EKmzrJXfiEcowoVnyVvwdExpav2VZmfEDxlynItQ1hhfdzueksorEGtz6gq0kiYeBwUzu7kcWLIFgDrD71R+UxJFgYlkcR0mHoTN0Kz/GLLoHoEPAa+uGmy059GtWLv3nLsNqGaSN8rBf7a4h2M7YTzaMlX3IzSGm5/bE2lF9TqgWQTf8yv+SRN74ryg/pZ6z/fJpPqQZ/nBAm3WzmCynX80Agcp7wWApRe5OiX1I+2QFlNcyy2V7qPIV2VaTFSp5ngcalATq6Rd7TITj3jLQnkUXwvyL4RyzJvAAZ930b6ZUP3idihceNZe2vdwXWfBxt5FYLjBZ5l1La8GLORrQ4blK38bEX+qcdWwvNvEmgl/S4gqQ40+Nsrx2bqjWQCNL6XyvYeFEHQKAw9jsXZt40ES5yzmWS7wZAjU0twX/nH6OqDEmag+Jo2n2TcYbqwmGu1ANKuyUSv3b8gwzPclrHa49AuuwzJbyrVdEmoldC+U+A4P6eRGIz3SGiVO4ZSyjbhNUVbMeK+ARH8RmnBckcmyZZGYitx/F+ymbfPY2g9QhUMP5enxs8b8PYNrh7LXGOvu08cdRbRpQHWcAQr+J9N79zpUfQWYCwDo1l6Jfz1gmrbKaWHQWl2LVAb/0yXblmsecB4BHA4+4tn1jGRFNk5UcQUfgrNnr5KIubH9F4EiOWiCCZeSiSUGwf/wgXhze0JMR137LnVxlL2wHrnkrL+dw+X/M4ZKRE3Mp2rqPgkn3R64NgnWeQynVptixBjagDV4DRrb4M/NINhT5d0isS+0IALhq/FK7yOH9d4ch8bTCyFk4lb4a1L5civqDxTm2bY72UPNpDBSKT0AykGlLw1eSd7slI6Bp+TWnqAnvLH7LopVfyiDLwTXuNqHIugbZV45vE8IUj54ImXKPxrc/ktMN79YZkAsgtDelhxwPzQ83TQAAuXwuTOv1mfx5QckA0G07mOtD+dFug1EY82ZQUjB1uo96+babazUu6nwyIZPpZD65enbDghLoZxPtoM714YP48elO4ii8CPuqWKdvAppKC1SSQUgky6yhYrHwbmuUwt4foRRLtHsarWnwVs+0ByirjQBZw20GYbQ6DT+rPVwywJQjMl2NvePU24s4xbz1Sd7xn8bOHTKS28NYCnyHCb5LzoNk1+45DvgiMYEmAHd/zC57EIMz2EzfKjTpj+koqgk9dGU2004ITU6+e/4ulsl1LLXqVBVndc1Imr7p7QurTxrh03wMkO9fsZhnZDXU0yZHWOtNgLIKd+RFrpN8QagQtPYlfls2duS6mJsItu/YGbhj9jL+q5gqRSdiVFsSAqZn65n5L+A50V/aETOZWaIiq6U9mRG+7OrBh6jVQ9lXaIbwNMLFCapE+0Ax6oEAg4UK1MgP4FiPWfzDDJKyPGHY3jFccxduo7hfltpdv7tGiEcaXy9yG8FhtAfuEcM+97mHLp27yJXkCrmw7KccAMXtgfyFLc56uTsylux5CXQgrRJXiCEyOYjVQ1lyJ/JRbwvUrq+cuCT8dmBPjNvC01nOt/4E4v9SZgcGfHOATSboNltlVtmPS9oLTdItSnH6k5CQUPdlasA/3Lu28d35XN9FnHIcVkHpItCs6W9kNMRhPZ8KgcOsbRLd0JE0FstrqnkX+POHuJF7E3wX9s2P2ulvtzgF+Kd2LCuWnhfmiM4oMfcmZAkK9ohCTbaoeeceaN494mTFSYbNqRznEaCpdHLsjtW5WrTH4akztPpuESAfMIEP7vs/xgKLJVpIXya7e93VI1Gbdgg3MihbCJ9dV87DbYxGkjz8FG/rbDXrrR2qYKxKkuh9TnkXWWZLkYhcsa3475l4YN+F1lDXVuD0DqDVb73rlmCu16ngA/J+5duejlAqqy0uvu1m/JFNxjM/0g7LICD9x+xk2g78bQTWGA7tS8yOEavcng/Bprf+fEksc4jeM8b8Lmc9NtGpUqO9K0C+bb9e1C5hNogBFHC/GVL0la1KUIkeHX+Qvc8okvhKKtDzwHTVk6RXZiujTlWGrgJuGztqtc7jHCfYUrN95Y/9XCb5+Ws+leCBitT979twC8w9NGDZl7Dx8nFnskEMgcdyR5JcE4VMwwjbLcworRjWnxGf54QWeIkmK2jcFn881o0Ama7g8+LKG61Sc1rhsduNaKquCU8371Gsnwk6u9X8OsPlPdZ0RjytvGfsSVu2KItOccZW+HEGyD5nuXhhnKo1Y1BfKScDeBcY7YJQooAe8RhLyEnkqOFjUiD1KrSJvEjbvhQXdn9HpPSZnWw1A8HUnpYhrx6tis1DGF6ViA/+XtORPzHZcslOKGq36pJK2S+C6PzEe3Q7tdwflfrvO2UxdC6BDMRzAA/ThzwYwgNkYjgxNovWDcJcuofdqMDiMfR/AaOCJlaZtO0q8cELII2n/YbbYWjrDuEIg3E2c7hjFdPWjKvtz7CnEnHlViZnsOtCW53OLCeP9VIyxWw6SJ+JUNBnPO0wR12ILkxz1pglZsgElF85iSBRyowDPeb4+ZtSPqgHDt1yHyv20LtwUZsU0ffQwrJyTI8i89TPkYP2nCbl3ZYIg8p9AI1Hoe0+t44dK3FPAPNaEZix+HLBHEoZE7FPhmLNuSgTVaLpFz44qcLpjpfwD5UzrPlaJmMxztZcpNvoQLlXrjax3lgw6nx7wDUN+ImiPzQpw3MAH8iTfUBjDkEaGxtcqN/lcF973eV2S0Zc0GKxdtBb3p1IwbqLVfKpY27sHoBpwwMqIqla/GrXycMXsTyvTe4YeZNM3gu0G9XAiFmXkgUftJwBAa+kxBjla26CA/ZsxP+Wgjl4PLWQ/tJrCdv89mNVhtJDSnFLCjUAjDLprEFGxyAT+l7jFhs7kTTaSsQmiUXUg40kSrXqz+Xar1ijdj/BnTDreGVM4oCaKXNEpYLsR9sQ3fv4l3UUBlEsaiDhWoQ0nhXHR8mkB+xfeDu99NNBFno2nB4Zf6RjB4WDK9Lh308HsrSuQu0d8uaZSxZCp5GQVKW/vUMabg3HvPpp8F0kuXXsSYaTrH3CVMW1K5xsFesFa17UxaqzSIk+fKqwC+uGSH8pPCsZY4tUI9iFyhLH5MugX0EEcDPViOQnpWtFpPLLxQo/6JYKdO61cm9lGzVVti0egkVstjbjWfseMUqiBmAdrhc9lLxN2zsEPPbcjl8YC4n/7zVFzpRX/Zh2/Mg/cvuY3rrrjU/iPLfF9jg1m2yu8H2vAO9yyP0neoUD2cCZQF1mbBDSnZyS4a9+mN/5EdbJLCfCdWABqiSkTxORctZP+pR5579EKiEBgBu1xFarnYJirGI4l9NKU7mCcdgN7ySl/yjyMRrz8Gc1JvVLJnH881i/kf8u2NqwKgtU460PZTG2zZOlSom9Yki54oCExC/LFImJuQBZ0TchUsw+PrjQa8tASnx0r2O6x44XS9Wq1eUeJ7r2o/R984jD7ImicdeSUAVvgwnwIuiVpABxa2I9UA6ARL1lm2b6YQm3NW/YMvS2LRvo6l4lPxzmq50Ippvxl4tRQBrGJRwSjrxTaTjrUpGV9yyhKr2L+Dpd8lL0SNbOZPObDkvYa6HPyK5DBg+pVqhy2bfQTLYF128RL62/NHHxbTZjajq4nIMXug+Ox8KG8VPyAAlhFHnPfPJirHDIq6zfjDnXCBNiEcFIdBHlp2UatyhvhmRD2zLQFX9JMncWJXLqp/z2hXvaXMNNImTkTkXU152qrJ4JPnRbqcvpkeQHTkWZGMsxKvAxi/aPDIt/2BqA+wthiuG6nRS2SDOC1ShknfM8bcxGM43yuGIpdTMcojH1OMBHwNeDUg8ciQ66h804H4O5ZprU1WCnO8H5so2HwFrj+kXYAZ/g7W8LpGSuEprKcLn7IINLycQA6ur8KRNuwWISmzFMaeZu1ZpiJXdtBdWH8UZU+Z0agjeBPK/twwzgM3UYn4o2oJwrvOnL8yyHpFLkD2+eEErwlr5kPiCGUUu5pGLv0QMJW1kkXxhBVtiyAkjsZmsT2Vdk+62TN6J4sp3KKnDBjA/yBrOS7jGv0NqPBbF2uLQlvhR12WLF9AtTIQgmtWsuRpHEzUSuiBIXM5FT4Iel3TMqb+gbVQzte+iCB9eZ420Mh6mELltHdYAp8RKDWhze44ymlkrUW64tHk7o8UBu+ENOItfF8Wz6vlx40yAJkl9AOXkYx3XS/zhFkKcVwhyxUmjfJRyb+TsDnbtkYq07+Pm2tgeloJzefd+Sq2AOm/emvdQGPo9YPLD/6iVfsbxOMIPHHB423/w1XMfYUi99gfkIVac8dZ3/epkp5vzyo1N95wVgzqV/KiJzGS2pDPJchzcD4Vua6I3bPGrIJlH8uCmWkSRbzRSHeBYBe0pLBFnLtT6cqi50MZVCaMvIoxVP1nCPav5dSdbDwGLfoI1rbtC6aB387XffBBN+MY+VFu4ZfPueEBOQ5lS6OcDSk8gI6g9Fm3kfrkrAln1rEd6EB17QOUXO3o2zVIE/9mBGtw1GL+R+qFcku0XD/QBcj+BtqMP19yy8X+FbMuzqDXHhq5TULsVnZd0WI6QrLtJHbTMqWqkkg6l4LfuVoBrBJ9RyYxmPsjp46EaMsTYBnM16fejzwj2vRv4inG5/WJeE+2aIsdkAmw/VnXr2tiPG+6VYPwyrXET6xTTOPRe5xvZEHtVj7DqZwAOUc2XEVQwOZNblvBYWe/GjeAPliWM8SfWTSiEm53YFTmPxKK+EjrtAg9aTfWHcxHMqBxg62gy34Ijjre8lhIa85uM2ilflieYtQZD/nuZZP8D+yo1E2nadPrAIeOvQs0Qt5ZDSFtkjWL4ET0K8hDHqTJWoV54vO6W6+4Ztol+NCjsQT6QZZG+y/qP4scp3FXOSndthBJAZ4FkiPVMsXhqpM9tSDUr2dDnRaCdONSfbOCC7A8mTVW/+zKNgNtv1aBm8eaS1D8mXeO5i2QjJiGCiJaDqer5TFNIlm8X9Bd9u7pLlLmexPv4AUjtIjUAVbcaBIwrbql7jLlP7AWueVtVXmY4IBMIwg2kib6K73pT+RCn5aIjuHEFNnfQ4eyAOJGjMP/KbPa6sI+WALeTeC2CbvzW2jeN74Nyu1h9A4qPehd9Iqvlw+41FzuifDi1e1aeQZswBGxRew3KLuX3FRKMLkiDoXnfF/x6061lIX7BQ0hjzYjvVQemxEEiU/6bplCW6q82mQDjUklhn1nmXHqf6VVKRhJdG8k/tiyAF4j5reTVzHJbHPbeFkfUToczELTMkpdPAOL1cIn+C+gPkXQ8s+jOgEQ9lQ/QymtwaItZl+0wPitZ+M6YJNM5dZMc+wCyF8nmR1iROrWdI53yVb9GitNXtEHcU5cq8T7yiG42mj/iu6S+uzlzKFG8JqkUDbHVP8mlq+82HZy6Rt2A06jlS+Cd80GcYo5PF0T/y9pRIu1ooQbuBOGI8II0StvX3sFNQ/bpL6XXpIup8DInzrRYW0xyWwBJ0s/z7qYE/4nGRGcqG3UcEBpw/ZPGOtWswJb5xk7j97u4azbnyWzSECL931FinQYz6KzW2Ss0jXf6v2NBOQ0eZWNsvenwzGU5S4pncMjO6B4S/pI/gU5jEc4Uy4Uymhahz2YRQxSOd+2jdav1WXQxp2olJjBoiYVp5tAFva/XYIpkwmirpzZv0Zau3JIfuwyEy385s10UL8xy2njcwgSbDYe8TzkqgrrSWKR3yrOV4E2w8lgcK0DHdhvO9phb0+8JQOW90fBNE/vQbWkizR6oZljj/Uc++iMJMQGTzmCn9iNL8saUSzYOhN9aERRLV5GMCq5VpPG9tD7NhUb8SZI8qe5VPO8XiNnleEbcZmT/SkSS8Ilitfi36rZh6lL/PYWAX9fRiaCjXLENsf45wJJ2zZ+3HpyK0Euid0/4+xRxVzQY66RqfGcvkvsDV4wljiex43ng+D+TzjmUvGVwJ7wbXdpRzfXyKTURl6p/8crozRmrjLZCjBURnPCz3aYec0iWYncTrziNS96l6LOuwRQsAAUkyodm/sYXq0h++TIqFQ7w7MUwC5PWvdA8pI14AyYOaQLvIa0qMi3SsSqLkW4zmYdq7ooyeDD50sqHJU9Z5t/H0UvIhHB5bE+2gxS2XTBsT8YI96TPtbNvNorwYkyzsQrtVF4iz1hVA/gZvK9n8qrEMk2xmz2o9EthiPTLmH0ieXXGrGqlk3sL7oBHVAvYxtWRC9PGsIzsFf6uBaxZRDd9+kHgKSfesOa9ZfKKYM3PJOmu7IdawdnAswgxFwG/gJU/A//rpzGpg8HY2wVXrRG6OAX6Un9E9p1nb9qzfbabKeL8hwM2LguMrz3TT9FGczQ+QEL4xI3T6AJcxxwBZDzXW+Yy0JcslT+QAoqjtSBCqDDWorNvmM0BerYAvak4X3Tjfw0YNMOSls33PYmMS1/aLt1eOWVXpsLsTof1kzDd0bm1exmfW5n4u8SCIQ6kNlN5NyP70ksgFC/0kg8WykuCt+4wVEYwvZHK9i84N0vR9ZEocIZPTkocl8psqas+dUyxNurCHhzHn/Vj2nGDSAzav1wVDKcz2LGl08CogmRI9j+sSHkltJNROIyLbi1ZlHGtuQIJ3UC07vbdj3TF/YAKlKMDnoscJ/nuwMbU8G8mkrqHQuXDStut6TK7gVwIEe6XzacBRiBC7XRiihjS9cw3wD/s9p9oYUJHih0mec/EOhDMya8Iap4mzQXe/Bd9GU5rlWixCjwmNB6gSOPsUucdNWJLMZSveOHXysF0L7OSQNTTruHknjc1HHN2xY7YozvmmD8ylfQAvKm0vccQ+qnnPhl3nK2pwogvax4BsGqxTvpTqNdNa3kmcq6wO8gdNmtkKwJ5IAOLkOkh9CoLd33kpjAuOfxDZZ58VqPpj2USHyWxPVVWrpYsaietP+XZUgxCrRFk3+BqpRIIyvWhyLMcgFg/27iRr5VjLochA3UIf5fltulDLOfhH11S3MCtyoStF1pCNArHDQCUqbvsrktDm/qNnsJYpe23KlekXvb2DjlTJIxN6ZTpCvIoRbKhWRCR9Bu0idG66TNwJlu5E4gL8VafARXgTKMNztRab1aHzsX/ZqEn3M9Ewn+x6g5Qwm+h5Uy3yG9T52GGXEAlLZn0nPoQBV5WQ6udzIVrBBx4epnbGQ5SSju1r6rWyHNrwobRiGrbYxiAZrp38NX/E0cFvRP2AKbC2V4wc0154d0vuy3Td3ydqi6hORzk50lRPgTxrxMNm9UNJJtHMO6UyRC1pDmCD/TSla9Ugt5oTWsvfCAZRnf/4WjByZ8z61gViX7nPoDDtie8aLGpq/IgZqRCq3SuicP7J32iVfyGfPKgWFMb/Ljau5CbHdOPpAilOZo894IskFqGXuNL4W+WtGsdNvJqQWbEDSJnClX7znqxaCOo1d+FOFO1eJpHg5qOEgu/pF3VTl/FNh8AJMeg/TZfDjCi+5G+cRyt4AKZjqDIxTp2QDips0EKiPf8+fcsgjTqfXwnOtnpI48n9Wb2DAfTwX6oLTcBvKs+QrIDJC/lw0lBRmkD/TblGhxfwPyEz1MJXLR8Ql84d0Rvi125C+B7d9Uu0n/SwMtB1FppQmrNpwD55eL6pNaDsRm1gLgKZp89qGAsdyXOS+ad97O9Udh+VB/rJ6DeG/X9XGYugYSZwgPEbhrEqEmjXYBZvyUrZlAqeBINnrkRmlhDTxim/h0bFgvpsatw7uUI4qFitbtBX5ROlmsJUuqjGb1BT9fqztV9sZrXV/Sl/gIJ3CqO3WUaCXIoRX9sbfvQ/cPrFoCTJ3C00u58AE+1WDbOQDcXsLzWow0kkQch9B9XmNu1TinIu6xmQ8lGzVmUHPZJEw9oqs4RmmszfohVtPpTUc8ihe2PodhbIRqCuHDjRX3E8/HU1iRvl/vmYHlLbnYaDSQYECpHDwQtd6HOvJu/8jsLvI73kE2FI+nv7OKABvTQ7Iqk85JstYnfO5XTukFHrpB4MmvOaXkBMjpzB4rb/lf3bcmOu+iAhLKE52BZZv0Ys4onI0sSBv78ziVtuWRyX1FVnFaBGW+7HYjODLZUUst1TfXp0PR6NcaTlCEPlnN7CRQx4r5zZ9Yhg9oCKsXPgXyQ1m+9GA27YJs5DDH4TUCeJwtYOgQdumcL3sMvS/k3c+8I0wSlfyLorsemKkWrmdXv/LBFbOIlwA0hJ/UQ7Zu2mmsxzOBMBsGk284QTuSzCNOEfBeav4tntE5mia3zUrAVJ76ZqMN3f9KKA1FtAibevaEYbzThwznMeOIbGCTIn94EKpKGDSDardPoLzcqvCGaJpmD0N42CHKP5jCMXSpLZwFbzJf+qUacVRjVnaRn4nV7ot1WWivN4VVJ/wc1weRjNlCfpHMlsZ1SSbDriUBbH2c8is9yqSCXbNQjuoE/N/5diUIFWh4LIAZ+P7K2Tg1EQVhgRZcNpLlq8ruQJsi8iiPrNsroTzLIZ9rEDIMnuOOVHqnkbMHX/64m/W554vVAbtjjDODz6W7kZunhda+AzAZ88j8j60XjiqHE30KMJd0BJh+CN0v8lVsQ3S7bp0neWKGZR6uwjwKA+RYUHUlRtySXvXpgZmNB7gWzSSPRTHP7FLX+Cog6Nov4Sjeqx3+7OHvjnoUM//pJB6vSHobFUqAvvCORNPcMpV5AvvFzbdQqApWK2FmBZEA9b5TamCy47WZ4Mt9tU07T3HLFxTDmTFAfQUaB953LSEZG8Qm+Ef7UOgC31clwCNHrKau4XN6zOTstrI8jDAVO0oMdBAXgy8cfCz4yG90X//S203keN/dCVdfUuXOmEOopN36cSVqzJHJcWKbKpHYZ8I36koCrhO+UOK4wpx3vpKyrIBG09r/p0OTSvZCTPoeRvK85ZAHtXLqhs2m82shRosaPh/13PRj12o+FLBFbPYVWUz11ylZ/ARobUobgVbObqMQ5c9HuMTuOhrnFh9+S2HwAJuxoQJL3hX/sRRuOT4pw/ewF4uwnwCNIQd3Z9mQpcQ3f1MmeVtvY1MOu18Ist2UOsItqFL9JfURDqQ6gymT687jbokOYDGAdoangyKakhiiCPORXEkpmj5yRevKcjveNDpvwx1Os1J6kY0pOWP/13Wb+iAWyig0YLcI6MHjdgcUiJFXbjmIK8CyX5uTiCANxYtrPZQ4HOtXjh432XtN5eoitP9T5Dehyf7WxTywmm13ngImhHNGjH3m8UYWMBxA/M8oAYsaRe+d47XqjiWASmM8EJk2ZSHVeYGqUv/Na7NEl7Jc7LbpRBTZSuezFPmostPwK8zx0cOd4oo1GiVgyV52IccNZVC6T2x7h2HQF/5C3+OaiLyfbir8W1DGrXqMErxq1jC+oJt0AR03xLZrnMhPLcXnuVbPU3Xm43HEHe7AGxB418HtS3yxZtJYoIrWe3UV/4wAdKiJAo2W9w9VOCmvS4Ul9RNiRdYNfe5pZIDtJgQSN6SUXLpyPxzpvSTY/2QzXbvH6xj33YgfgzOR9vEaaKBvG3MGX6SH7MJKn4TnSFM24Y7m78mp7LlbDn9JDJQ5h1eOK32ZLw+VJ7LSTi3WoEOaDL/TNU+kk7FG5the434QNXCDSpMBILR9YzY6Sdv5bHBBJBsEe8IivJVvbARzaYIkXfwoo7a5mwuGXIIUcj4HJ7nVrzhfKNlFIXhcO8qO2LqFUXIW3kQp2A9uq1AY3ovPHhFpxszSrcvmUUCWYe6gd1znDa9+CU1xIX7lNYLlqPR3IcnsMP62h6rzNwlrsZGMR1Z4SKwUM/pBHvhKsFa8QZjUeiWAXRPbO15M5L3B2nQq/+DFJJ2nmZIjhj1sDiBI7b7ED3LV5o3DFS9P2AWtut5lgS6RPEZW7yuM1RtxxKPqlp7ZLqD5aj2oWPT352FVTNJymOK1yvgEGqCH9eh50bSih303SUV0CyOD34fPOYkCq3tJlPBk/qox+qWZEt6JvAznk2SMb9/Rrdx/aO6Z5B33ZlrPBSEQng4AP4+4AhxvAvJdwVuWPIHx0xeBDXXp/xZGsf1L9AKm0y5Goy+LadV17FA0eiqeeKZKofxykcRcD2xvHSk3levccuEz1/pkfdqSJf+EDNjPx/SsVV1nizoDNZQAmLsII5hDkgxnyGBEhthLoPHjRmf32wY5hzBWsaMJZp9iDUove/gr/IGRMd2ud2oI1e6rPFSt5g6aIX1rGtBXf7NobdAe05nwVuc0zLtBHn010tBgS4Kd/zOM0wd2bjgC03wCNGYHILkkvpYiFCdymAWbAHJk9dgpRO5AH7tcS04kmkYX/squnQ4CiNys0INhL6a4fkbTMQo22OhmFQRpsKA4nWKyQTeF0rrpcPY/S9V7yqwe2fqhETwdTTER7TzXBzSM+g6qWCjtNITK2gZkt2KQWQlOpwOr48H/YvlF26Qryu2V5xFfClqj4PyWqCrdQ7Sxwe+pk/MPh68ZzzKBEX2Ur8Ub/myYaWJ1rYao7Tm/3pmUkCabRQj3MN4MI85GNcO91xp8pVHwREucfCDWQETH6r1wYSs/TVonkG1B8Ot61YznN4NL+khVJ5DJNGNbK/HTXEFKFThfgHvW9D8hCxJl7YjvnqNzvl2rtqSVTfyfS3V7ZO6z0OXr4koTalk1XADjO5MXdsChb1pFfu4KOOZQqM4GGgNx18a1W8Qlh/fomHKPButnzdKYeYGl0bMChm+WYzigakt7Tbkoe7IRBMyr/sQg2nFEyrDOXkdvmaA3mH9ciM9+ZtJvwlAgSn3j+RZc9HpVfOR4rD4p1qMoUs4tZMPvNiKXHmFqlWzYHe8hQdFf7RADNZwiC5O4NTuc6wIKvBTpAIe3fcjbNsCmk4h8MAZNZgjZFEIm34lQRMx9896Q8lpQLFkGZXHLevVOM8+kGvlpzD8xLUX8cgAuYXcVpuxFNuY6jnLEIdFrxlmo/9brdOKdKQ+ldVbcZpgkS1tIOhahivBTvKpdGTzj3zKF3UuAVLM5w9IfOM3/cJG6wapMn7/jm4FnTa7KFIGs0kLmcL1YCqEOr1rHYlLphp7ynLVPAsk0XvcW5Pif8My3+6Gsh+d1rMD+KLPDSvgtNkRYvW9oK7nQb4LIP2sGm/UWDriRGgS7VRkKLHuVIRePpuNTkZnVhJj74fSPF2OUCmBo28cjtuTpjRzmcd1A/kiwO0oBLXdMHajKmwPuMr0Gd0H98FWgD2/FeFQQJDjbjRUo+LHg5j8tz+XyE3pe6Rmw5ZNLXUF8W7M/x4Lzp6q0xlgeToebhdc5AH2inAuBEGzEujNuJlHXSp9ZbY6SBSHapX91aZJiMUmd7JDIt7VnFN9YDakIQ7lw6KU1Fzl8sYMSr0v3xLsUp/ZNL8RrVv+KIsa2PxP0Y6zNwH2gy9zs6A9sQZ2lLTMCVpllvGCScmT7byEZa0+V3TbJFV3vykeU/aBJmfzPHAd+qjQGmo4DHQxAEWU9RnpiBNGnewOpeBo0umrUY3LMORMeVWQ2Oe4YsbS4m+LxS+p+23Kr2FMfRGTXzfdDGHBgLI/KcMOoyup9jkPJpsFeLpU3jMJjO/JOcIAukoilvIXogLfiPxBUReVXbN/71DOOxaRfOREtCifhR3W/rSDNeeQvFwkaJq/eIhKy2Y/IthnoirGXHMVU/njcVo7o1V1DWbMNNJ/4VjszxIp25QUs+qwBu4e9tSXZy6ngcYb0CnYRHH9kwwduAIy/22nhfabWECMSn+5qwaJSw7xYgP2ruugE7FgPPOoPqB85FQyHX0za8qa3CVgNcvekrUvj3lUPoNWIKPA3yZwSMIJyNR1BOT7Ugs9asZInifXGObKSpW6CuTxT3xmisuCrCBCKoo52Z8MmNQAdlz/L+W1FzGomD8K+5FN9KtB6og3mE7s4hWAZ0FfKuy92Jcif17E+kl9otq1M+icYSK0zRCkxmFKlKv2v7BwR6s2i8gDnd2FHNBdbhhYegB2hNkXcx+3LW8JzlQcOY3zFwtzsivwTmW8JvRFu8zTMEvB7j1l+4eqwzwl5oUG3cZQXvVBpm0OlTYC5J47jvWrE1MpnMfeRRe2+NqfdriZZeSG0hzakEXL7GuphAkhYXy4+ZBcewSRZ51yjFpAahIjvjWzVzz8vH0g1WNVvyzsnWkJ1iCmUfFYNRoBMe/Q6i+Pe3IJrYcQMpyvN/2WD9k6R+O6bcwqveV/+9O9IIRMqAT4nech31R08ksMdt+AyFSlhDIPhtk/qyWQsEajeOBey2dRv24to70a0rZDMKFmFbRD/9+uFU7IYgtcw2MM+5FDJxY+0YRb5ieJa8nrhiLzlQF3PWR486I63vAwmz4dutWk8N6OAP+nDpV5AxysX9PCU7Ik0ZkFjEWGzRWx2S50gVizZHw7Ucw211f3S8Q46C2M8UxrL+S5EZ9xUXvzjALtEyzJFLquSmXroyi5cAd+WacRyYD6VXot9SHoQsJXr0yq555vIN6FGMMzieFPkc4eZpyLB7EaxW3bvpYNZtIjlH83SPosm+90QnwGoP0UtO/kQzTq015NOwOLrDoapPxrzBCPYMhTCI/PIbDVaUSEO8Ru2IcjlqfhWP5Kx4LaBz+58dmogBfkumn0VivIXSgZolQML7j2gDGlaih05Vosd2JOAjLA9j6XD07mlBLzsdyN/Kt4SRzQuxGU7bA0i8Cf6q0hdENksjSpd7Y2v3CcfDcQXsLjAOt2hTzUDZz4H1M8keGD1AuFJPtFCIhh4wzSSubLnW9VviwWV8tHZgW82hZ7w1ij8NtaksbXpUBTJ3aqJWovIZNk+qK2YfSqOHptr/4OP2nAGm4t7mYhjP2gwO8UhvXWQQd+mB/XiROa31dLoCMwlbQ6AKt8vBPZTgWANZWmTxCy5kveOlHoairyygTw14rJVPieh0005bVkyUXpWbpiescmacUCtEGBvR5Gfo81cAzkddAe6guEO/UgryzaG/8yqRWGj/d4xgeUsWGoFrvqe08rPq5fzFWjdZFdbwHOl0nu01gwphuhNfwuwdY5ZULBpw/d/n+UGb0JzabmRH2jcbkKm+VEYtNs31VuB+CYWfkmk1qiRLTvLz9L/BS4kB47X0B+zRHvTK0PiiOB7x6wBYnIZiACcWPW45mENWjYJ6z0wZImcrZ/KFvzp824PXjY63I4y+Iqw6psHFlzxfgN43kEtP5YH8jnkThKoRRrSpFUC7nxeFSHEifA2weUTF3PaqEF6lw1jV8mcDC1FJWrGtqLx04ek8BP815HkWxJ2hCyLGWItP6mu9KQSaDfeUIzVW22+C1oAeSJE9iqJKB/ZjrQutcncgdVF/QCvz1j5cmkA1xBsMWgeiC8+ApV8MnnT6kdmkXjTK7sf2Gl0weCLv0fjtYy50kpccmVP7FxFngMbmLtkhLIbDuaJ/oibOyTu9tmmYMOpf1VOmvfzjCKRPbcPwB/XLY00xV2wlitTQ16OqsW81F7uQfriF8Cn9aYvIhW+zDfnfaIuUiNErSYUvEs03U932TUkxg0wR7/TC4kssOnjswpGlFl6NwyzuIYpmFHBMcis29G9LBPcKta7QtqEyFJcH0Dqjj4DGB/iUHK5Yq9fas1FIbWI+COf7944D6f81++79SMwJSjKj3/ayZy9x1a5vU+pLpnnRE2Ba/UT4bYCjehVW5NHnjTvgKiwguct0SWC8N2YDL3zOlHG2Qq56lBjxfG5ycH8ZBmSdwvVIDSJWiOUNAATxxbqHb0kwfIaHrhMmuvQcu0VBGs8YwZ6zraev4W75p+vpLYRL6C/LYVTfKmDfeCYOSZNLd4X6e6TQS0OanjJrQ/bA0imTQcWa6XJbxW2jmHIUz8F9RBGsZulc1rHVmE1zD96K1v3ELQhwRogC+W0gDIdqRn5yea+oUV3lKJw0MJdMhWOWGjxHTrR9X+vxxxt0TsLsOSeq5HNvNiMKL2Np+NGbYCgOMyIqg8jXkQUqD1bIoHVhPfYSDSB7uODb3S5Eap7JJMErqUCrRe6akp4zoVqbzXKYnCTqWbcx/fTXpdLGaDyp/yV2v5whM3ytyOTmPQgUJs8xDrWrZB+W2uGwP41zooYXpJ4imgRG5XDH8l3f2aNnW1zX4s5oTYLVWFlbl4HfsHpxWAyNmJ8pmzRqNaCxvhVAI/lxlnBTvFpe7RDVGt3sAwt5ocTwZzINT3u3gwj8b4n7CK11OpvxBHJVhqjstBfupo9DK9XeCvMF8Cw+6DuTkmXrvzKHT/jOOdtPgsbg+YVgCQb4OiF0GIlDyqSW0OZdB0CjTbkRpfd0LJHOJMo9Y7wdBK/ifE72/ktR3pVtqOH/BRokdsyrEvggKUYMWF/CKt3zRnsxHVTSYVYMkqrUGd4cN5pgTqN94T1fGwLgt5RBOgiAPOXJ2Bu/Z2gpf+AH1YFS/S906JvVZnJKY565dQX/Igd+VGLWyYA9ky0BRutvSqY48SKneq/EaHdL9YueXMPGq5kvcKwlHsr0eiUL07NYdKvOabawi3PpbkBNIlfZUv26tUON2iQQ9lIIrnKF/Q4iVv2Btazt0P7Bxgj3AZ9VCCEcgbe+fLh/xY1XX4CZp7EPCpO3yjMoDFL7T9QcdIpW8wY8z3dObYD2C5GIOp5VfPt0Mk1gq0h8VF1XOuin238dyTCy9MILEzUsea7gInaxLHBZNZPOgpgagfwCjlBRM9gRrp1aK9i3XjCo9UPL+gj+tRwvK6ck7eAm9Rl/dXqWGfKLNmRQDP/jtm2bN++ktvgiGeZhKWMv9dyboz2SPKeP3BXJp+bJYdr5waQ2Im6Nk5eeEuhdqwHJ3wD5F0QYutSAYt8xWsN0yF9TDPxHsMqhiz/EnRDUG/cDpL5hfz3RDjkdQ84Vfux3kF6YsSoFUt02QCm1h151CrjX/RsS9acTZio4F1wA4j3VszrGfiyO+McSPJqI+BHuAHKWWbtE7MpxnytijOi527bUe+gCNFk647uONFDPovuPVVxAGL8CHAalQ/A0JQLYLxF9T4A054zwxd9DZU02xhl9hEdoDaQp+CEuyr4PfJox9WQIWoNmL+L3sbmrLGiCcV6agOxikQdP/Si6J9bF8IlbFwudfpEJm83tZJcxnuvnFLNPtrkrsuml8mS9kWMOzF3xErnVPGbhdjpZAsogg+hM2KHlVKr+ECUcQcO7epQoxnTPx5G69GhvIAT8r8atWc5l/dpfRFyWaP5ohy/Fh8I9E8lMFgJeRzOr7qP1mrIlc6BLGXMQ6D8z26CJ7VEMvyAYPrCjP1za0SI3/djboS74HBFnjmb9NaInrtRjWQarGdTrtj2Z9Rl2DTcKcJL8dGa/cpYo8ctb8L16ZhKOMeXDLVcBmJQYAD/YwySXnfZo+3z6LaVfonmUIxxX/1msiFFP9Ep8rtLbpZoxbomPkcPi0KSjgChWmr73BVFtEJSb+UtCvkeA5L227uOVLLYLDYf5njs6DSSHnbBYy7pHVhIu8DilllsCfDCpq0wQJ2EaZc/R+BwmQpD7I4Xvsr3ud7M9eavyH3k3bOIXtbK4r0JW1QyzAN6fnHneWWGz1RrcxoTw476UmrN076qtXqRLuVzQd2vT5wVIchTmyx03IHRJH7edCCFWrdhxouYxNU3DmuWO6F2RXgK6rQ8AGFlLYkwqMbuNydAOulP+Gyb5MKguUql0motHmabw5IN2X2Fewx3l9FLFO6xFYNdM2H/sVKF2T2ORpeBjz1jLbXosR0WWqLBX9v9SRmg5Si7jobXanAAKGQyf+9SuZfIlV8KtxGoPPI57SYND75IksEJ59+8mzcd99QbNQtkq2+Gf09qxSzKFE5GNXBe7HJ5Weq2zBGzCQ0m7EefmUV3kTKik4E0ZJ5144NiE4H3hOCVb7sEFeLegdB6Y0C9KSDCHruonHmHl67R6f+m2p2RDGOzTySpuO6+lrQJ8NOrzdamyZpw0H5MnPbH2Iw7qyf+m0XZPYLNmcYbO4Qo9NlJ7lYn9DaFlfnZ0UmhFH1lSqFGfgH1Ba+3AbQkEssAu54kq2GbS5IyKbXihC6esppss9ieEeAYzzpWZh7Y/i6iDrnGU/vCuN3MnCc+eM4HUsEjS63pe2ctC4juMnfHZxe3A/KQF26kiFSCLEWTKpu7J38Vt0hjgB5y0aGNw9CfjPCpDCzZ4D8nbjeXJEtvtgnwRNCW8AyUV70GKP9bdSz6yFx9Y/aAEzROx7pc16DClR2gbLnEf/SnmPcCC6OUApbhz/UFinsbSPDf0LJ/Ziv8kij1pVzhzsNuUiD7tC9l2n7BpV3q5muiFvxpgQ6HczdOSUGOMYe4auSaBurVh7mrUjeXjVRPg/bGSuSumVMew5u67Vop1Ir7TnF6F53PSkTkMGi6Mr/a7maT+SH7Smmi2DQjxb4zlmBdiTZApb31slwMRyBA2TYffQHRMwUn/q65Fg0gkFilQf7oUm1aq9Vfg1P65wfwEUtsmh3NXDaRFEeAfOrohHbumw0wRMx4USSvNdttIY4lQ2Q1FKvhguyLWl9xU7iciaeTc5763QJou87XvoqVe7gTfsa5Y4hxux117hGG8w6810Vi9qQKmPSHYgMxBfRq25fpic7mvRaP6WKDO2cfIYE5qY9WZ6r+1PMqXpBnXYCLsa4fV7JEoE3lcIsbVkkwJG0LPgIGzqBJpQ2ZeVZ95Y/Ft8M9qJsvBr+QRjU+bFCbtVKZ/DH4nEA868UzbojsIvtaUTYTwCp21fjd49JC94vGIHMJ7JfTtjCbo5QCdxyS8B3rTUsb88ntGKgAslblupVuYtzmrsWhSwepu6BtSpl0x2Nnb6V8YZMH9D1M4dzpP0LQX4DVf/oQr5JL20VO/IE51kL+khjGK2CeDq/GcRjIqrc80Y0rKFi0OSJ9pdHqaGBxTLXcD3sBuMqtWzrnk830VyGyWwejxF8BFLFzoZbKc1Reh+4isWYXJBLENg/A5HmJp+149s8cfqjJmYLsPsaavCbEl3vGTLLn/xXp3zzccISUgqZLsNdjT/U3zZ240IHsziG269TdOEJeSTMljUhrmntSxyD0Qmq6rUcnVaQvGaVqv99LUGkY7o57mca4beNPoh2+bLlVzoUfWoswKQu7tVNFQLH6iDNGEeqhMJRX/bVzCtcRXQk8siVQ/gB3RdTII9CvWiZdvqJ5tgyCKAXMwGzopAGmr9gNNiKrl1JecyDcuZWKNZKBV7AckH+3at8bx9i59wYrYdwD0vpxGX8PK3bnvi0jTWesSUOW4mSSevE/E5Bty7+UeS+diWYDaCNBTIabQo/8MV6VJjMuyAvVQ+nMsNyikPMHgX5OX6zKbjyXNPEo2QS3z3nqThq8nefhutkxvYNNLIIqRZ4gkzbbRO10wvNfUyzwHsuZHiSE090QBp4U9Bt/99qNvPA7R4MeeHwcT+Z/W0Ak9H6R+nbM5vX4rkUii2CW0PQBGawMqXFTTcbjNctoUXeJVm4Pg5bfgQxTZfB7A/HnoojlOhdf9Ba+akFwh7wTxCniRzQoZCz/IWrYDeUUCjnVLpJEUDyLJwltmNWdofMtvR6ZrDvasdjHOQl833Dsgr8edWQhrxyB8HjRd6x5zpvFpY4KQkuQ1O91KJsGtt0PaVqJ+KvFmDqh5opFINpCjNY6EzWv3uk7go+SwOOOa0e2F0AN0v+UiB8Z8xOQKbXxP+ugpv4ItyCdJbKsFn0ZpbIg/PLn5Sz1i8E7fuXvSp0n0cFZxJfkjcXtf3gmw4z6hNNuClrCoBFz6uRWiCKAttdJpPRSeq4DlxuL1J5wICzWosNetsxu+NVoBF4NGTqfRXissJ1M873jNMkAUP2J0bg0UCn8TmZGm7DPN+zxac/zTaJHiuPrFB/4mW32I2jGW36rx9dyHb6KWL0R5zvDnH6WLv0C+BDBprvqEoWfc5TmTB1TOkPigjYkIAFI1GGk00YgWilw2MuGMA8lOUu8Qy4igLMn2W14z6kHMrTXbAqv+o7zFLtcNt0z1cHdV/Gaj3twFeCQzTUa7dKaf465AzZnHgAIpg//ougIuu8rCWd3mQg2P8knVQT6i6/m3WMHWhDtOSDqb0gYk6mazhR/RV5qDiyawrJe5b2VokYQq3O+IgsYPIUN34EtvYOi9NEt4NLC+WGTNZxrSWBp+MCx1gku9ZylVjE69wuyUqA4gRdKviQQB30vjdH2wwxwEtqgaEGPhFK06oYU4ltHMCVpu7VmspxppUA6x5nzZ5d/CzsT+B+/LoqZzqV5T70KXQ8GlgKwOFVM19/k7zpP4pz0RqvYC2mjQmg+nmspBTFTGK3fjJnJvYRz9dOhBQk77oKh5OdzOVtWNggXwJ+3LKQ6tesn024d65pG/2zPHiwSWwv4hJEHPAxtcpG0llo/iJ1RAL6FIya50ioLVihA86UVtb0XHHHhlC/dCvoDzecGCuE4F7MH1M6xgdw3X7lNPofvjkBpX8+Bo34rZZMhqnI01O/jz703A6HufVfkEW2EF6rebkn/9mfFmR9HO6+cAlK7hepaCN/lmwyqSHDF6Ro6JVKh+NivVPfNSjVslYt/I5jNHPmpcJN7cl4BfBU1oQmCdVsQyILls1u8lsA3XY6o+K2C4UvAdgXPt4nfz+OyDz4qRbN8bFHiQmnuEWLHMF6IUb3z1hh/oWuUqP3ujR07J9RjDl7YCrAIYU9neZfldZVm8kok7REmSxjkVwc3w5eIMPhA6K5/NQONqFoqfaEjhhmMhDgtjj+C4m5bQDRgGTxreAV56eC03ncuJNIvQZgzfyBi51zQ6lQgCrqQy0apj4GKMRKZLskO1cbyz1b5TSoHlGwW+xmGdXFX9qo/EvZd5E0fPeK7K/8jwPydA+Qm27pvQEry9uYMXsOU5OIDMHvYNS3VDkQcETlUoPP7iXFVtlC+Ii5B0v1rmrJONBdmW8hQscJpiaZtcEspWhMiDN8DSGWPBZq5Yo8H+ecIxKoPK7jgZfeyoDRYRQi27IYzKtjpMmAWKfEtARc230w9929ARv8WUkUaBmLn/q6QZnf/0i6T9zyMBx5/ZZBsm5ah01ncpMuevU04fBGelYAcjwKXOcpn3ViRVbWqYYH8Ea25i/F7M24q1x4xDAQh8rtkyRtiQ+RA+bKjhIqUs/CFY8LoVY2EKADQa2W32qqTirAfNDz1kS1rjdn8bpkG+OjO//RI5Zh0Iopcj4e1JH3ZOKuMDumHXH7IqHgOXaCJnNbsmqF4E766FXW81e2JghFGpcFUGPhhk0QfcMAmfzJMtVHAqsbboAZuZwOMXjqnNiEyXS8xp0tv9GSRV3aU6qOH+l89MU+MKEGXMmCpjhwsE79YBHxgQjuVWr0NLIVCd9glw8ospLASuIm/mYW3rgMLuaLQVO0OyG2piyVu+ptgT/Pp05Y2Oxseq5D1MVHVGPDJKQZ0JV1YugNdhqITR7A72cv+38MORiQvgGTH/iRnX7cNm/5KqHcjkLQq/031aJGEp2+iqpj9YVJ6TOpeA859ASxjtMJUKsY9VfEamAnr3vWbwNEILraKopeblbozq5Dc8BVZ+XDhCdmAjCDygeQ8ixc4cnxk3AO+tK7DJcmaeJLHvARPm9I4pam7JxU5xzHTLGhPTJWT5/FG7DyQIwZn8aZu4A0/7Id1m44ELLdM5iI+xV70uinFXRMLIDeW8r7ZC2QGrVdopBKwBb6ellEcAFfH3NmBbY+ZOV3AqZQNAOGQOzaAM8mDe5T1I2oY7f0wqnlkr0p84+gzTmYqyDjwXKsVMVD9HTGfGRCL8wmDdUiO0HZnkuCHwn+idpe9X2zD6IleWeLnzjhpSD1c+OHmmqBslgK6dPCRlYSxClBZkrqN/rVC064RwaYvBh+P1D6yxI09nwwXHAr7LJvFtO3jx6IV52C4yP71IRqsMUEqixcueNSFo23qYTRQJHvggnaqs0tGLs1sBNdLfFWnWLulYoGosWnavgN4COsVZ05avlbAnrX9WCPbndMzBTdIjfVcUfQdTYdm0lyYQHoxnUlL5nBbkmVxQPc55s7R4a26A8v/yBn3L7wksT9iCwU1k+05D+n7iBTfifApR34onVSnL1Zg5lCBC9Rx4M3EnixQfjhxuq0aiLSYvo+VjifWh4rklh6xzhTCT3zSiHppieBCjdfJkoZ3ogsvK2WgOmv+HLbqJkhuKqR4HSujm7Z/GbB1qWQ/TNc648PcMwHaY7KBjrm9k0T8YUZo1XFOgWHuFEfbH/KqpwVQNYy7rkZNmGCtRFlRH3ZYCq7DffQWRniPqAY3gJSaYKoUFmSJOJE11Imwp6LzwO/TxxDnWotrmPyz0e3N+W09AbH/3efXX6r/JZcK+BpN47tgJZ47qFHdQiJefZWKMVDIWWsDEzvxgRwHe3IDLL/V+JitwIe1ObFK1qtDtJxj3qZ3DDAiBC33j+HrDRDeSCox1E13UGFbxC82poipD0L1vA7bNMooFcjYxXVca+GPA4pxHX6pE81qPxMh+Ni/MNYFLiCX/o0k+N8o/mSWPHjmNtLsRXIKOqRYEATNH6sK3OLpABM6M12UcAJTL0bAJ9mjAboh1vTGrl6AbGOXOcHSvPbHpuyE4Qu7jkp32TNUyTSKz6hCYOc9Gbd68ydT9W5rSdmyEGPBZ6w0oZ1qEH4tW/ve1bcdEoyIC3DaR0RfYk8W3v1N9FY/m8g6ZUUwYQ5yZap/hfBxWytWD7/cjjAJOqVFNxytWIXw1RDW9gwHY8RZk0lr0QQ+JoIvnui2fZuzQaqRxyfMuONpAar+21h3bk01Gqde8/ohY8lqksEQ6RXnL+D+N59Ckrux4APsaDoBYzuC+Q6YCJOZ+PQYeYXjCrwNVQlZK0pzmghVzviUEJXvnWIK7misg3ZMw+ZgcjWZg3YjhK9l3M6mPeJt9AmgMoTPNf3GT999sNGifMkPU1ztP140k/x5RKm3EYBdBum/GCPAr9XkuoucLBPu6XrwZddRKwByC1dg28xX+uT8ZkxcqlQhWrOqBdbAHk0YB4D4hMpnXuJSq8I0RrDrGYQStUg8swzSNwJmdKj+tiRzYU6tmToOPYYnuL/vHonPN+EsuIRuaAk/HGEOeQqE21U8aZyvx3QQtp1I0BNiuZSu21AKJl35w21UB3BZICfsgtKfSr8lmqiVcGRZ6udFwnP/VmQYC9CiVXDju5IxjbzySHgihGsTQWCLloM0zf2dYiuBMTv0Wuw4Cx5FZZXJXSPP7fVWT3esOb1pR/tx5QhaTGd5BV2B/STP9Wx/w250QLqXmwH8x9jyBR9u3FIqtxLzkFTfb5cGstvAjth5ohlTpWpK8V5myyVOtc1YAKCWuwaqyeNNJpIpfAig9unLX7ZGu+ykETTX/t2UaDkkCi6eg740rX+aSm8059VMb0T+DdVRhVu2LgAiBCq8RrB+y+MpkNkAN7MV4kRTY5xBpZ4waLJfAzrI+BIv85qQAzSZ+hwoIzdZbL+BcM3SZJgM8ichzhrnsqp57HfzCXXMZ520eebH3nKQ4Ndr5z5G7TqdEry0QdM/hgpRnv2DFBe+YMVVEa1DucxJqERdE9n2BGNryPbYyiHgARUZ5KrbrIovmkJ2l7DkXP10z63xinkQWIAoHiWxFft3MigLHjPAZfHMO6fe004BqhskPADhJWn9c1O7hbUPnCksxs39EXlHVhxidLzrlrgxhUye1XROW4gWjKrN4i0DjD5ZhTejIBL/6pBIzAavYdD6ZfDG/tOm8KCct4HZOKTQVO4wV6kOrYPleAEzXD9aU8lXaCqK9q4FwvS+Ui8HvF5hwVy2Bvw1L1lUIWdtRHZB/TKdkkTY3vqsTCKqHc5ws0l5plRewdrJ3zupyA7mHuuiTptvOIDi0VUv54mWtcKnEiu/C89x6BJE8Nf+DJaQuUg0xH3sKIz/2Ab7ASE/Y1SZzMSvY51+eYv1lbdcsalZbkvj1dBw951z5RwQqxsFcbyqIHP42ELpZOICq+8Bob7TQHtZHsgCpwWMcu35EzRH3tiQwG6JVquR2chMPKVKhbboLeWNthd9aZjVfMOMJ093Bnsb4o02xzH53m4RFjUblXKJYXjckfUQK9/IaOJ7ViRtC2q05tO7384y48N6nqdgkbxrAW6KxKJ7AB22mbDJqUL/l8/8xa5ngJRa6kZOMUeED9kUueTd7PWJ8c4TQh1zILBTHkGW4UjZf5Km9ljsd/9zo+hHcJF+lFbn/iUuPQ2aRuhkc/jM6y924kp8oMyXHi5OfPXYGo1DZGBHDviFFXW6yc1r2qZ8Q47sM5DAruhCmwThSoJq7nNouhuvl+vnz6L2g/Ed0XUJl3AEXOP9lMofsdWkXLkOxlkItIFhi5+cwK07j1gCIThehrnmmfDPuOv7r5F+8Z776pJ/0/gJJjK/EpYjcweo/RW0S5J7IYilEkv2QKbMxBTgi2uk8VZ0xqibCTg+bpHK4s4phfLWQvSqmwgY4vgpo7WQndpDedHM62GmjERk2iueN9jswX/dIL0E7fOUihuvwP0tRmWfPhUFrhh0E5xxxj6u5RPotu1OFw/mXP3ShXnJmLcPaS3CsLx3Ajne/AAPFkMJXszYh7qw4zaDIi31JVceyD6UCdkhDZ3kls4rInk0Kdn59SXS6EBTivlRDd1qzXAzkaN2W/LoEUipiuZsx1z9kUTLIQQyX77nrDBHOwOaumYrAHsHlwv5cnzENlHU4a+yo7yt+EyYSNvVGakg8lKESxxV7Wk+7sFflG+Yv3FLTsIW51uQXjMqvAD3i37ebKQ8xqA0g5OaIW1bxeRA21976MZUNQg6YwY1IBCvQshWeG9QGM1i5caQe2oOd8/sSM7CKlFLltveJA4nO4pXxbNpfgF4VAVuZhVEZ9itzF+EsTocrcN+kjNE8NRGtehT26HI0rLeYlAJnfA104l8K6KK/ROjb8f4KWK5jB6/gS4M+SWObfrrgD00UIZ5o0/1WwddzjallaBAkK2WIbMkkbuD5+EH1RpxaA0bpTEB2GZyQSmvGUXxTpqz/gLYjUi132+LfzWjBRM2YSzIvx720opUpH+DKHyrSGdcY/ipsZ0VmMIP3HOLutcC+FQoxBp8sDnz0BUJn/STuoqGbtNDveTyt+lG6qUdUDyY4lD0TWkiX8uedhywBJcP9x+RPKjJz2aT/Nf5Q24wCrMnHUaugddFSCvluszkPazqMcCdVqyFtsMfDdmnX4eqATsI7D4ROOnzGJEAeRrDIQlXujBijRfeb9Is+7JO1H+cDjWwWFrmDj7v6N7rz7TmjpxlyHv0m/9qyAriwbXkFreSnyOUh7dWQxMHCmVVxje/EsStVEHxY1B1OJZNPgam4MPojIIx3SPhdrwavnEqSu4gNgxqZUoSwKgfm23z2WzMOvM+rSb8as6zlK1h0V1Y/AGomnPOfaE57wRkxh1SsUAXEGJFUgrEW8NjR44CdUWjkLCW+V6FbhmVi/86TeH5prYaXbexWTSuVzgweqdTnzLH3CKI5Nh3B2tek/HriI6bxK3JTSk7JYo/nQwabn44bA75/8QRME869GWB0beDnul7NFK84hT30SuP5UHiBguWKAAtVLLngZvLFugab6U/FgssJMDeRggyQFh6NckbZtedyrbp3LkUIX1ptPwKWPFgU8bQGHHbEqjm4N7xEixk+3QvU2LK/ogs0AbATqDQgmzkPW/ofqMKtz4UTj7U8sU+R9EEXteD8dhjdh1ucvsGW/ZMOMSNbrpYw4gLKIEdDNl2qaW0o80mn3nTf4kZFajzUsFhVJyrFiGkq/NbOHBhwp8Ouhs8a/cCDlsrIniK5XvPK2YftIIxEPVXPGPGlfqm7NbLgVVQ70mkrUNF5xIaA9ew99CKPR4IhKsfDu6S6lEG9/MuCH5oVHI8DJ927b11CWM/hRpnTq7/GUHMdHvcir5lYx4qnIWY9UeWsdBAo93rB06s1vbpsgs59mClRG0AcdUPBHkK5PfiHj5pbxuTTWebcvrfABRiUicVB/hWG28ftdpvknHAmyyPwk4ghr85Aq8UyqN9A6SasGzdTr/jRdKK++Z/UOdNE3ikerTV6iIXvEXm9Iydhr4NwNgxq+gNOenByJThtfyw6kRRWchxCrVR4U9Zrqv3qAj7YUUQtZmWn+xdNIOaByCJ3DMo9oGjjawyeUgx01ffdOY5Kwm9QO6yT6L7K47XL2ZYP8xf+ls+HUDnFj9dGj00VJ9E7O+8RhzhdWzejsYdQ4u3FVE5JLZPBucL/5YKEME25XsPW2Q0KYBNsQQZOC/WqfuxV+1cgCy74INv8yGoMFmTYkjCES3UyLwj1eVzvQ+fgeXJxLOiWVM0j+qfRnjEDCnyfXgmS3/Tmy5H+pRKZyz1jj5pUDrGHefIkv41m+z/UJ3G2ZbgNGrfZsTcIUFShlmeJFObbtatzfok4kpHFdhjdi7EaTrCkY0yuKmu/3bicge4b4G2h+u8wNirUWZyewFLIRJtZYc2PYDN0UtYq1Z7TWLfTDulIJwMcE55VClNHqs+uM5VHeNXqF6z4pzED3AdAyrPmAV1UPdEPXRbRKSuj4gc2Gg5yW/T2ce5PWiKdlW+9KiZ/lPp5h1UoIl2vNi18wGxNExEeCt78YJtkFrEpAhSsaICnnFLQe1ZIsBTjFsjhaVRPh+hzgWklp3msPugOeaKLg0ROavIL+i6M23Re6wgVm7awGay0gu2CVMrFxIrw1V2/SBzlv/ECh2WhmqciXTMKdN6mDCbeWC+QTTMhzha3iWFwhnN45JbT74mQjlPf4LtNk6Gv2lDpZpu/F5uaE6zbKM1nGs7d/D0jaD2oxfoiJ3kieJQbFK0B1ThRGO+gAsUPchMXycBYm1HWUtx33CU+HyY7kH5Cxh5y/HXkVm6r5iRpTJWBv6X1KWqPlHDjvNigNR1pdwfpK3QqbYJ5mqGG+j67Y7qBN9M9gYuFib7xdLnoDFMvFZAvucFt9/5zPQhBUD5CrB7UO68m8n6JRqrEP3Kh2zEtzBdDiKBk8dXLv+3HWDZpDgdAqeUADSNdwMu3jgZ5A9Txxmp+l5zMF0SCdAkzFLzaJoOeOFeshhiC7mmVbO96mJus4s82o8lfGNB6xZsrsNVSTVsKQVSvt9qSMWA2I2f+1DC5ZY1Q6yFKTYbeX4HTuXxP9jKcJeG+tSvMxxsi0QduBjoiA/gmUwUJdiIsig8HqINQ6M2bc0mmk69Yvbu6EjyP9Kv6z5zuO78zYTg14ERLXrVkj4BJFI1KcngkfsQVUAgSvnB3tdJQF9zkeS0izdGW/PrYB0E8blDVkb0V6Y3bJzZtZSkKBMxELgqHT6pmw5k5ke6CifT3CF/Z1nEfg0pRnCmhEqttxtEK9ZGL1TgOgKXTK5ZfLZPbYExzl9rpFGJvOG4zn1HYv7gi/lQQbKwKH4R8WnRRx3kOqsKnDZCejHWT1rqtBXNL1lnCaK9Up3GLBzDIwvwNAhSlu67x5lUIsE2HoWlWnKDOwSudZgjj4uyVjf/WoGl9+iQQubg827Np/rScEIrkujfVtQrh4J5baDIaA42FiAMWP54kwtpvtftpAfcP6DIzXzw2zflbypJILKuv0pFFr2TacUULHIWfx5m3IH4Y23CfTcbcyAnG7d8Vobmn3AMog+t+gIoPBnBadNIqTGVDOsjD1N/wRZQRA0k9RJ6dyicpzAR22VPi6t3DT01mtiIOWhXxCSKsj2sKJqOQN2XQzOJTX/1Id2D85gfhKKOv2/SXXT66rhSnIZ34T3t6iVPO4RZN4eVrLmw5lH6rgYyQCHOBi4HmLBPHvKI1UWQvMha67CfwEq9DeIVANwg55QcrD3fSiFmwSO7AuU2GXbvFPJjJZCq16ebyX60B2t0yPjLcxVw24y1k+xKsM1d5AJe+EuVPhovAvcRLqXPTD0ZI8MoUzqsPtniPJkSJz+oyzsFEnOF+zMfa0VXOR5p0pa25lB3QlbFuQh06hWARxOxWGHtKU/gyxR6HagCGr+w4cQ8mwoepKqewo/gMmzz0Rr1voocArbnBszz/IktBNELroaqM+5QME4+iyN8XGU7h+5BJZcwWGj9k9jiTHVgN9orXQx7FgelnBapBq6DTSFqFY74nvxIIt5swvEQKCVBMr2UI2BBe9NzuDAaTthT+EYn3EzxkqoAMlI2Fhp70klnDfbt0HfvZp+A4/q15v4e8vP7A2RJt46/TCSpxq85lJ9XhwMomUXL6pGLVMJqykPXX9GtPhY0HZlmyPkfwd005H8zIjVVf91EfS0zHUzir+tMR1hpYQRsO1VCsv6K6VkD7FNLGs1xiah2mWX/G3nQlH+jdoDnE0dvtuFQWu5PSPGMutyu5XljFmETRYit58B3ia5bcTlPnKOOBaQXZ3yiuFECqf0AD7TbwjwPtdfeNBalw46eSj5aqPH9OJL1hVitplaiiFSsxc6qMU0rRCCIfOIpe3UGIrKMAdFeLEBqlB+F8DPoWJ495C6fedV78o2tUZmVLpCXupYr8AiM3vnL/xwKeNAhMTgJ2AgQmyUp28I4St/EZir1B19/1vOokC53IZdBfktEU0Jy4bjAy5Lwhj1za79agQt4k4Pg23yCo4PRbGeddbqppb+Sp7UsXzcjCJ4WjXbg5Fxm9WnVZkkx1iW7R7AUrRfbz64EWb8KD+XYaEJx0kl8rE3BuwuseVi2DJ5SmgTii/fgNwbilu6UObUR7jtnmB6yUTAHEmJQxR/vP3ROaEk8gFWpzSf7wapF8sxiR6t4hVW+pB53Lj3ZqkZjAXle67DkB/MYME7f3Zu+hFSancFL71lI59qNgGbI80us13WNk+3+nQp484k7ECihMLvQ5XOo3AK7kvRhOtLV3SZ+GoLmhh66E2oD5XZZQCSKti6NPY/ht/KFq4sk9bD50UVqEPv2DplBo0+bFCtyeIcdWKB2xknjzzAXflAE35nJIbALFUB5VEKmTJVoGO9gK1IuZ8kFta8m3pEiQQ2VcEogPhkNCWkK32syxTuitwe+laFafA0plI39MQTnNbxaR2zu0utk9D0ax6EtUFpLQ7Ldc8K48OAEW6uZi7Lk3pBD+CObe8+hldk1v9zTprnkVGlOCa2Sf6T1AZW914fhqL+NQVaF8AHuBNGLAjIJqM7wN8cXJVAYHcq34vkqgrqSa3SdsbmKLHaoOq7kN1i8AODZ++esAHaIbWjRVA0dbwnZlCHpkVp9zF3TzqqGXvScEkUtXbnaMD4Nhd+whXPn38I3R/ue1OoHXCLn/EnV7osqdg1yiyGGZxtkNH9aehYyfe1FzKVAF4959MFYUf5CuOMlv0HQ9NUrd9YPQmIJEQ2cJFZvc9+m7wVg8W1fp2uOHNkIE6OpnQMS7bwKZO/nBDpojr24BHK+7AsbRLmzlwbUsbPgPRd4zAb2F+pbOB90l+FIWxIk010X0LzITOUDoW77SutELib9smXgAVP+h5Iuwau1SzqqSbRVYndRXL83I8AQGjdIzl7R4vsVcI4ErL0UOV1wX0dBrfuosGbtEs7YZWjFm5RwQNwFC7dsXKXJ12ANw5DVNZqfjIPYAVoqx/0ynyy8IGRs//HPmohyPB6pcCOnPww8Y2Y40x21i7ogg431VYwzuNZpR3opIUJZEDkBNsXp167PRnIqv+NF1y9mihk+kMaDTt2SpJG17o1yv4iWLTMcR/eA2VAH++ld85S7AWfwYiaZtS+B+9bUqERmUxsiECi+Hewz3BOygjhNLGRa3q2Keit8iN6beEWj35hKdDtBy/BT+kxirp/LHJD/RLeIdZgTAE6pjCbyyv0t77irH5W2huPnBLdJq5Yw2IdhalQO/mPcr1R9wyvRM9RADj1EJeshDhH+VaflA/qnsdKw50KvBiG3tBhjYI8Hm+LxSRDaf4LXtO8AT71R2vZBPMwgGruNa4hfRTI7lXU+5tjqXbOtinte7Fqz326L4gkdLTkkFuiU/o5SbQcpHoNSNkJg03Db6ZAI2DmF92bPtBdFkXJJNYOX5noWzOT5WC0LcAz6BOMA5zKHJZ3CK5m56OWfgg75sSyiQRxwSuqFI/k9R5lXOFU/EW+UfcpTvIKJ8v+q1h5MaBpzv/bGfFmVJdApIm8MNGpbYHQL6CRWrVuSB1m64faFTonU4NLtzXHawLYRGnvJI4R7Qy33EbhgTPXprtLAHS786SYDNN4iCLPfv2wDTi2YjyeXoZzHMAVl/QOnCvI4kh3GsxbpfydB06hdRjplXLcGq9JJfuqP9Jxi2FA91mpMpJj7kEXLF7c6jnEWYK8Qcb3d+HDATZd6gYt3HyOawnsIdKxcbnikKhGEpjX906PmhLyxlv3HE0G6W7dW36SO0feq/h20SpIyk0Qnceyzqc2RWp0JDp57meOG8xOsESlzQBcgkMVpOJyjCl+aRtlduzLqDG1ntjBLUCY/Q4k83Mg55RvNfC7arQE58JB2gAj/EsJ5pYVVw+w4mSCM5zBZi+9oSbIWQofO6RX9ZiAvI1euXvZNv/JcYQivKvT5gdS3IRBDeqYhvrckS1tDkriMyqIGk1kjkLcUPgESXRYja4U/rfYedFHYjbVuFGw+VtvndOj664LmTDEZX82pfIdRXyQThpdpiLEehLtHdCkEs3yBlonftAXovAfyhLiZMDV5CRoqzMC9Y8/Z5Z9O8c4k7Efdr/gboVYs0ibhJUrOlwKmc3yuZxty6gI4CiIBONHaro6RPNPN+gZ23L5ugigyfZHh3JLD+VTMP6yWGPceBlT/dmJBK4kkscAaU0y0nerbj4v376DQHzXGI2e7yOSrDCCD6Fmwl77Pqp7IeZhFX8f6QSfHCvvwV7Gc0y9WvbXj8tHqucWmW8wv4/YQsL7UIrGV9iUWrUMOatCCTMSuWYGcd8hVs6A3YkL9VeWsieT8Ki1J2n7b6Eh65uFzKN7QyacYz32MQmyQ1LrE2UDykcLOXgT0E6P4kpi2vxW3zrv1KfltotuJKVjvSqtn4A23GTjhvQGwzGvAHAatiq/CIpXFXwESNLzcuHJHGrTjfOkum9WvTxh8CWBxpRPc/iXd8Is/8hfkbAYNJd640ohXBAsQJUgppraeM/2NAtoNxjiUKU7hja+TfwBVz74Lrlszxr63slLixhHOLKdhabFSrNhkuggDnjVgavXkKkG4J6xeYq2aA3/ZakMWu0d2XLzJBHaRbPvokImajZev4JCV+g3AUZ1KL9A5m7dLaxeKc2diXXDalrcCMuJ6QvRcRb2U4Sb71Hij7SbTnzAjAVB5rACN/wZKpe+VLKd+R5Hk8sP2DDGqhTEAyHQOVL9lndbR8hjpYrnc4IYO0ooduCjPL4joX87V2z1huoPxRvSDS2E9bcLVEYw/d5957+4LvFsYusKbvmU0Uk0dI+AY6Kn4NVTL5nXtmAPzpJjEKxYfAOOQrrdGCqlX9iwJku46xNqIHaqI+WEn7AibVFChxnRsuRW0jVoifAdtgf63Vc39sFPzO4HRGv1AJYy7dqd/zYlTqB2krICx29PWpfMAZEpmGAWeY3CJ0+3fdSpCcNff7/0IA78WeGCP+2iQjFwe4q4Qf6gPOAT511G9yaGaz7hEKuHzqgvObkY2XjEGrTnN9gIhdNVspMucMk9E1Tyd5otYnRSJmXnnH4GJYfyYqhXIeVuLb4EftKqkaC2xSwDu9buGMaNC8FUmP9eud4/C5Ui5PGAkzXnoH7K9yLdBcvpKDHRGvA4uKPZgm/GoQNIXz9ZnstF1abgDEO8N6Z6kED1YIdzm+AgiAkx5iL6se3dCawYVgP4bixYmILoDkmvaBnC5UMLwbJCXctIkFUaiXrF/y+/j00c07DxZRnPWcXhfQaSUfhxe5PquaZk0DVqKkPUmSO2aYl3AMk8jnL2MB+cuKQjyWUn/jUXdQb1nLfrdWOCPdzurjOVUsIorIs92GtI0TkSo0kB15rHLDvbEaEfteUGXg9Hph/8bN4U6VAQ/YpV7LBt5VSLXPGtaYhaCPd8UMr1btaC5E8IpXyVX7V4AyzgkH6+oDBGfxzBTc6qlicYp70onD21czTXXMgmvqDVZcMZQwn3tRXfcI/mR8k3h+I1jXwJF/RgxBv5DEDvNn8e9Tqr1XljxJ4y/Q0pYLRp1FhK/chTqb2TgUeraYXJSbdwl2EnD+05BbhY2YPqE/mgHKts0C+IPuIs0e2QFeQNqFDQ7ozHUJiGaCSnQZMFR7885V+P6wgkcFICoiJWdJj/ACF8Wak923TmkcFy1XWaggopeAxG2432snXdxzvrYi/bQJDlF/tJ0C5N9x41S/G7zPaotMJkVbgRSF+bpxzNhLCgy2UtCrG/GgFctmixFzBAlBo21aEWzZh/KPI0jXgSXkoHv3eif2PxinzamYbn4FJZgORLhf4uPOm9CFK05ya5+TWc50KQIJrhCz0lVwV0yp1usgAndtNow26K/A7PaN5ZidUPVssxc7nI7tKoG4w0/A7wPpeHWgWsHtlFqD5+nSsbp23rxfZFUixhlP99uMQlaNipUvEioEl9YC6DcsEFT/SARiQCXqITwHcJSULbYK6ORxe5zt7G+A/umOUg99GRsd9mnI/broDyNuVZyx0EdSvsk2IyDXONJbbKURFAYzbCE806+ygNad2atGuEi/dSxX7cIYNpOlXYpzKSW63pbghTeKyGSNCNMRc98Kgxz+Q4CUK0/JzD50RlAeJ5mtkrhey3GFBuulerdtPCJBRLnq2XbVe9Bqt6FW68OfsYx0Sf9wsyyOvkHvcEY1GR6X9dHebwyxdMOPTNodONS4Emj75oV9uRCKI1Rom9DfZYyrJ2C2QroYaTIDHsESRa8BB0sz6kgSlyXHzasS+YKj0BbI/YPn/f/7N4YZZyuKzfzl0F5iTLrf4PlWrnqFzjtt4jR/WsHlACWMVBDOSIQmWYLPV8RtM5T7O7IBX8TH6NznmdxDi40WrYL7D5Tn01yBZQq8MciwDhjfFSdqQMxBJc+xlTjOsSpI/rGr0f2QL+vNaRYmv4d5xEK8sy0nCuOWgpug90YCdGhltunVOYp2yDPlcO7CpUvRRi2oJbrYQ3RxOhDDKpJYWxD16MQHmRtG0CvC0Wce6oHUz3jd0UZ9Ml67ZkXNi9BeP+NiTMCeYg0kph5f59lLviaAg4cfJQm4fifRr4j09BmmS1bfWqRZeBpkKKrzADz0IrzbEbP3SyCD6ZyaMvd959Gs+DFVjfN/MlvwvHWG9h+pB/6MafKMzcVUXsImwN8ck+K3SSvQxdohG0bD3ZqhdPoxFZjF+V/4EybwG0xJMYoVLX6rAp8Htn2zLnnSHzhrfcJfg60gwfpuN61fxfSzeu+WgETojPyEz80ISSUgY5dDHDALxqSMBnEblZOom/gXUiw6gYQ2+aOygWdEXA4NCjV5xuLPXUkVE9lBudK9buCDRZ4mH/IaUAi63uYyZ+EfJEfOqiWxl/6fPHqOQLq0m3nYt6ktk+wYDUWwq2MZi9ZSLWirhCmSuvBTVeI3FjPd7zDr8vB+pgufg138tX/o1OtBcIUtwL44dl2Yv7znoVmFQ/bM92qVEPlUybbHcG5jXigsova8ImcpsSQE+x47yG0xr3oR/MJ3TcKxvxpUbGFaw+/JOt60jQvO+njAAsIVs2r0uIT++POX3HDbclfpxZ0WZz8KIXX1gzH2pK9MB376SCEeZqAsNo/VOq22s0k/h6DCjBEIS1fwPayZo51Y8O4sosv7UX3pmwQZBh6wHgI7hEiD1PIpP+37BjgwpUbmaVSHSaX0NWHwnXJkiEzb9QbdvnWvTORXkVPCXpRvqqIzwE/jbMo/h/7MRwtxw6XxKhlwhzu53la6fAkG+/GeC205586SWK0jBehQ/8Tqd/8inTsRuKOSwKTvhT0DCjbF7uU8FqDEkWs5E1q8iPdOE3jWcw/IDhYrN/IZvbEYdICTGNHN2svnFZ3Os/CPAiqgPEXMlKAFfD0THrAkCTdPUpzbk3Q3rxyQCfKGdd1lKb+UcV3Y+4EvKadofHYK245YCncvejE5U8T/53zhZrvDF8161x6qEfaEEVqUz8GFbTEEaYA2iFLeEcjcOWRKLrG2CSRCQ2TteRb9sv5LszH5xPOOnZSsuxbqa4LyGA0LQ5DOiigf+vXCz8zHINkWiIxv9tGrskXvkGfFtM4/AFVINwwc8PSMZ0vANFIaO/8j+q4H6lVY/snT7A4BXGY0Ka+x+pLWqJGeOCp7buVHxKBF0qC75Cz3YOLEfzb6SSLNeMvDzsXs4KlD9QZNiHKNLpsslniPYXOLeV2ooJOq8SeOcBZpi0I9vxLxzlBzmeaxKXPdwxdK7Xa2CnzlJ697dpSSdX8z5VbZx5s5Jw+7odf1fzIJQBVp77FCeEHcI2Xd7NxIYR1ynHAvrFWHfQRO3Gb0mj08LsTS7GWPHdkKBRDzOZe6W5Nm0ErNxQZr1TJ7ArRZrGHbjK8ginXmvldZ4AXHHFYtwY8tAgdJMJ9LWVnWFvWOb3oYgu4T+8I4NHzFMyfJftha+bLb7rPxvUbRLzwQWydzWCa5VWG9D7Wgzwhx6zok4K5WOPU3rIKYI63EMh0aVADF0YsdyceTGvF7ji1SdC0TFy/EoNm+aqYIvqfI0x44a+1Un1AWHtQ8iSPmSl9RO6iyQRwTbaagv4UgC9Y1D+EI8r5X8zwYtwotp+TQ6BYMNZfaHRXXgvzZY2oq7PGG/JqnZSHqRtESc0Bf+ua82SON5FtPAWnrhJF8VnH+VHk1ci97jIRa75U+G1di0g6AT5rm4JhFfh/0OM2PQtd7feOWKaFYTnXMOWZRvR8JlBwFAaO5bYMSFvBHRbgQ6chAnRwTME3HQuCeyHWr41Vo1fo+Up97uOZ6e2pOzJP/xSIO2s8mmMPZElyX5HBqdt1iXGdKxkVAf01UATUyi/qDeXbUF8R8/9oxWyOJ7T9A/pfwaHts96S8UjmM2JSWgC1VuIpQ27HGC3bOP4GWKGKJ068hVFMxvmhTtf6Au5+JLoxRMr4aAs1E6VM3VCr8FKx2lW2yP7tJ0Pr/M1dJx7JbAc/Mpf6oZX8Ae6gJrfXRZ5y6iLA3PHWtptfbQb4VQ8bkuBakQAsXMvIdhPJwLtkrEw40rqoX8rjgBLKteoB7vRMI6r1yeX7cidi/qt0Ec99wpuk9E1UfJC0qDCVu9CZN71oxLEeUmEDzxhDVdynoHaIV62DmmyH8oV/WaXEcaQeANWOlz+HWXOo+K+HbYqD4q+dz/3GeOQcac8gijmSoUtIfCVwKnjr1L1fjWH2P+kz1ftoky4XbsqUOAJc5QYp6+73HcNLT8FjSNHbeliejprAzOOiNoFeqrsirZs+dVb7VBvi2TTm2reE6rEAU4axlLhyCpsO/NGD9M4VMNFIDTJCD0lzEv0hLoy1Z+S3TDxsRVlq7odXJWfZxyxA96jeJhn/LDlHqJWcPtaJutIvYSXJ/zmmX7BzeMm/36akGHmDteREoJ1B75FC3+bYIkHY6hIBlEtETWGTjvIci3rQiiEtk4yw/Eo1+Muzq0WdPo/1HlvxfGdpwFt77dbGFDQGmnyXZtDh1KulEPnHzey25O6HJDZSuFZ93cvDKTV86e+mc0quxnRO2alD8Jq71gMM1b0OBR3rETOldmISGd7N3ABPOJ5o+wC/3ZUgY/dpM4le+eyYYMeDb1iJMDpEciQIYpX+QtzSJ0i1TH2A2NMhcFspCLN+cI/7DEVnKk0XPu8TarLkN1gvoyzRq0ouheUPhHTi1G2kFyhfftBhd8GdtnvDzhlMBNQfOoUkdI79Kzh/isHROTXuWeh17U5wOCFz3pKid2eRlx+45IuVPsfowuferYMj3cTivEdYgckUhqcsQmVYyDQsnO7G9K4mUblW0AhTixJXMxEMXHJkqzyKuVf/SzrOw3wKppBdQmAcL2J+c1/8punEN6wgNpIeV23dTxOvtZ7p0hsEavp2vI3KRCt4Aa8G3T+hlEi6gu9QNYPoI9ZAmbiiv/LXYtIZpzRUW2TWjLH5jlfAZmjVfuEJt/LfLQjlFIs1x84tQ0vxRbqIqE91r1TkbX0xDYcbMeRB3AzE+/RroIGxJ99u/iEdNxG+4NreCoMoSZv6ImwL/Vkqeg/xXMXQfhoTO0aXAOqYXy2AhP4yEjQf2HfQQNQuR5XgvehL2HjVLlxMqPLmDNUwx6vpGXqc1qnFpXVyqN54TqwSQvYfZ01zJYi5T+J7yjikjVEjx463Q79TCeMNO4JwYhoHZS9Eu4Bf1dltNQPu3HyU9h/s529Ty+wcl+YGHDUKLjePaUqbNu/F/sIL2hHfhjNDfkxAuiGxuwdx92p+0qc9F3JSv2QOaZFrIToxKFc3Zepbl16q0JpCIC3P2RWIxFx6AV0tFaa1HjZjksc9q0DLD3IHJET9ZZToPYrAL6EzjePJonsDiBfKBBrPJfTN05p7XbfP8JgzjMV4WuQ662gTsJ8Ws0/+N9Q8cq6XiN74ou1Jv9O2AuM1LEfQ9B5Ft4K9xykMK6FwWWTLgL9iRC+pgmZuYAirnbwS4elxDBYX0GxZOWYAnKgGoLptFHXZOw+U400aKE7WCwF+XtQJP6BuNKLQtkjRtI9Wq10nsQbdRPPYNoB8+Vrm7hkjRTo2acULgfwflb/FMnhFjdIK5joSPe+LqwWqctD3TPPvG9GlmXCdk6psLxvJ6eWB/JY1a+CI8l9kzlckA1xsDwQnokjOvygHmoMl+NojfeEzGSQBT+oCuxPvHYb/eYggfFaAcnihVjcK/SHXE072DN3pBZr20sZbdL2KLXHXqJr1Er3vhhHtc3nMMMQALQowSDjN/yciVvhMEgEfogsBruOLnSraJcDG39EddHeYu1PcqxUuHzxtI6ewKtqQNJSOOCvIkHreV+ui6dL+Z4YhrYF3RPQJjtjPg7t3ViXy/Ofd+kNpNou+jvHFGyWOnzP+0QthFnIGrFrgiE2+3MKG4tkFVqEzAq9T+zVI7RPL2yUoa7uaJnWAdvLeRSiKq7WPbtE/pElnVeQbzUI577ZD10aeOIHS/9GhqdP6LttW+sntNxwq0nTHq3fmGSAHZ1C4MQ7vTJ+pB0y+FaRSc4RgJNUAMMyaPKCAz/AWPjKd+2EKVX2FrOUbj3FJwV79UKfafgZOOmmFXDH/CcQpkBmAbDOi1/VY+yeHEclWW0Dgd56QUq9djOBBeoRsBfUpH1R6WLYySMUU++7reM406q7jito/R2pJEhnQItTJuOPSii7F4Kq3sGTAy9mf6TCRVEQcs1axRDtoa/fK/i6bwzu2qI69i9YsoFb2MsN/BZi8umdFa6I4nFWk9d4x2hAkzRdjJpuRwt0QeQjmk0xdyiWPbYz208qyvwbATKIFaDT/SPMBOylaf7Dhm/xja7Q3YUg1mWiego3uWCzwlDopwZ+ZE18s+AWlTUeDFbHPgCicMNZBJTzwW5NkECpWidsvFOqGdQ/JFTOqOucum32SmPtEf8/I+lGz4EQ2Ot29ss8kfLGaJYy77xOOWHgDyOaNbmBqoxsnBKlH/WWNiGNENgvgxOv24JvAn7bG6ePUs3eHCpO4F7RO3jea7UHrF5Gsj/oIln4DdFdtMJz/TLoh3qzbdoItS2tvlcpTOGJ1aL7AHOZYT4lipgtQRfIRrBXBPm8RpT3U+aQAvvQZxhJeGq74rekxa3XSvIInoRpDXY9nzZmG3wLI2Q0hJt9yPEqizVLDjto/hxrWebYsyLV678Y1orE0qC676PCHEIN5h2tV9OO7SwDksyNYn4z94pblOMocvRaQHduSLA6XLW+gtr3F33KR+CrvTn0UKcsEkOjb00OqyPqFtgI4vVqnUuRcgioVLJtMnsRH6EF3Wa6yy39ftqWOohUmyt5y9cEM14pQoiaIfR1nFbRQnHGkuxFCojQYgTkyLb+Z444JcH7zrHxMOnWB8dA44LA/g9YfJ1ntiZJea8UTSGiCoJQqJUXdt9lEl5Kr/mVJLMzrCA6+MQb57P8P6dyxO/XWhPpfmYKTZbEpnsaOAJadpRq54IAqFWUOW0kkGA0Q7mYbdw5v6DTLrhU2I9k7NoLUtjLME7f0RF9vdYK3ecaz4gu9URU7iR3/z8ivKiHTPMmnRi5jXUnnvFKibB4lk8MsccCHYOwbgej5BFx0CzEfd+IPOxIZttbNgPIVSy8+idwWauRxeFBj2R7OveYFkW3Bl1vrcMJp88e6Gn1Ez1l66JIfPtbFNIp8qcC1GtWsED6ySUU8oRD+ZGvXaWdgNWQIckxsmszhq9IwoxRKO2DG23VkFCbNyRwfhVG2DQBwV3aF+I7A5/sVhd1t8fkEKbcS7t54WTB57Qwv3XOJm60TA2clvOCz7gN710dM5Jgm3I7ASv/Gs0GitoO+47jfD/5Y855UGdFIW3fndlMd/Yn6KJSqIReP5ZqUzlZqxm5jOUqHsAJ5pfFiy0/hQjPvwt90BG62bAwTuO1nOspZAtWOKqGXcsuOPdbp7b9l15Fszb5jHTuF534I8MIhdKS9cXUnnT/SWu0Es8Acx43jOtnY7uS3AOh+9ALQ++MD/e6PVYj0kCCE+a/m0q7fCXxyaA+VX1IwlpAddt+5TbPZ7Da7MEKq+5VZC3LJ6PjEFpv1fS24CJtK5LIVrxuIJR7T14ZkGaIR9ykdVEY/2NQkg0wNwyriBP0pTEaAZ1L8S8JoPc5vA/8wgSPrtJEnsOz5YOaS3Ltj9VnzPaLqV/C0iWCqXLOLJo1IGftB4NzFfgopmjIF8BSA0S3ejzhVROy50rbHkWufFvexYkw31o9zVR92fssPa2WXugnDs38OGOZjALzU+mF0Tz5QawhwG22CCCfYFXmeNshNGyXg6IGxnUzvWiSDRdwnFgTkdnrpYg55I6xD4O4DKT+w3VM20KsKOtczaK3MfQBtEl2USwRlfJNAMI39NBIZVau7iscbfS2hRs6Tdqo4X68l/MGe8ZG0XM0pBxskR7YiQRSuISWURDeef9sJ2RRIM84ades+2EkmO3VW34s48FAE+XPOr5gGKmbB5DMiUHpFF+HM50ZV69pgUz3rLM1b/mmJXug+eND0TjXSRic+rl0n8Ai5j6/B90mC0LLBZmFZFnGMxF2jgBrVLLypgtfI68F0VR+buuQup9f5nBSEuAYjO1N12gpt+11vy99U96CR/TbEIqkFjd8PMYgku+91USjtAyqRsE0lxqJJdm4OM2UPXgv9cRT1/5lsIe2SSt2Ost9YPvejM5b+RBdcuwCn2fET5tozi0Cdc0UMVsHjmn4JRqYcwohhE7gQq6YSBz+LKYJGrRJqR/xUZre+tbHm1au0+k5U7HnBKLHuPVqg7s32eP3j1pCvpcXrUVyoyATwz8FXKJryD17bSaLMRTQWZNwhinScoHZhzbqBIFP422I4Hku9M4Vnv1K1g1f5T/HDF5IxQg16QtiWcUoZPK3N0v/uJAkvkWXYR3A7qR5sh7tsBWn7CGSrvx6otWVLrAHnFcSb9tl7QrcrS1TZpvdKvlzilJs3U25HEmqPBN1yOsm0qmDAjmLMneEkwLFNkxjgtAzosB+PXXLELuP+1xHkmQ750uVrlXT9k7jz/sRlqwYqAQv/mQG4jB/ZSPlgiDce6HBKfnKIaEaP3Q0jCK+b9RK55co2JGe8czbUEDCAfi5EBrhcX5dwWm8DKVo2uxWOrxhw0gXsG9VCLcar5unL2iLXDfPBuwRkLLxW0SDMAz6ihx374EM9zfjbIn1dFZM7kGleZZGUKzcLxWYyM8XprOaK7RSocIpkqJH1ws6ltIJw939tSLpgEJg4ntT9JFwT+Bo8wDdbUNesXe/JmbjYrhtJxdZbtOmHcf+KQE1uV49CdBBlzO65yD9FjTthaocNIaeT8WaMgR5k2ixn3jWH/eIdBrVjkqEBQtTy53gGE9ml9UTv+seSrbehp3CP4VbOQCOJplXR476dSs2bYi40UYxrXaDU89slTp51wRvqQ/7e2y9E/GuHWCi1hX2A3XqCfEbQp83p8IH+lDKSfQl3cGz0F0zoAPZwpaDXsBSnCWzjcji+wOP7i8jkhmkMJCAUkAc+OCEbTnrT+1CqdM6zXdjKmu8FV+JW+OzZbta52gJnXZNDsdGfiIHL3EU+4lbD6ZVmiHfSXzXPoTTEkLNljHW6ospsmb/p2G24YEiaec02PZGfrelxh2sCvV44Tf8IW7GpJLjFK3NJ9ejPb8CqLqTBs49Zy4A/1eVI7N/BMGwYUADR1s0do5UG5rvTd17S2Ea6Zjv04tyyTJOY8qljBHt2YG++NFM8r59WA2NtC/3dSy7sBRiJzyi5fFvHFpKeCRStRRrLJsBaOZyuT9mJAvLjW02WuJ+mb4XrdI4256p9S6V5qgc4cYYhyb9zJ1/wuR7QMgJkfZQC2pItyb9P2K9CHo1WbF+PKbSNRRc7K9RIKX9I6dHz3HdMZ2ECpATyOCI8URyiPpIs5Ldbo4FSPMRXZtp2juhIYH6We1ws+c2aheczdoqEl4E61VDvdYmkNJEtwS+8Q9hygO2K6VBW5aBJla7CZDmx58pgfepM1itcHrrhytyseiXO9gge88ARtaq+zNmrk9qwngdDIZm8JQ4FdseTMUzi0tvrOVUivjEEep9HTrS80Av16LQb+K8ALbHWqJmghb2JsFgGJxnMLFgb8BLoXmaFf9dkzcSMiHsQ5ow+9Dij1nOEHo27tcKmDylFuDuBVR05Ey33Fiudk+JYbMFPQ52R6bY/oDDSLQk5laDJ7bMiyKGBvE/yYX7vyfd7ZR5wuswngK1PhyrZI373AuSXzzHrqEreZhjDKQUgA1Ja1GbGttyZFYq5IZ2TS67aHzyTw9tv2IX6MFG02bxp8Ug1i5bt/iVi9JDEfECyhyo1y+jQvmUR6vVOSRSjzDaQX+w8IcoTQ/FZ+qml8Rd0z+ZBL3dHs9R9gN2oM23elqa/wuPqAbMNq0cuDFvgEiN91Yk7Yxy5TSCbOuLGfkFJm8YWMFBYuyhd13aIvc44BN0soZFXAyfEq/IM9pjRsPmtNE54nfYF5L9RAhSyp8GpSDZbTWzv2ktjyZcEbGHOqCCT6Nr9TCBS8OKa+yOX0zB6WTK/hp5Qfe7R6H1dVHgG/EIKbpSAZnhJhSp0il19IE+kRBQnNAFwmPi0ACTuiePZzbOjCCovleyPYAKvTIVriy5pSLa6lgXd4wgMexgC8XYlv1+QNN0Z/folGXanohV+QdxfjCCla3xSz3Efaj5O3FNDbBg7w4tGlXOIe6rRdXfZsflO7fcliI9X9+SHzsCbxldx9ttjb5pYqHZGqfhyusF+5NYLciH57IcNnKqxPYutIkp/RfTJT3zkDT+f06hPbddJ/CqVBV5nfLLD3qiUpzW7DsPg6S0BcspsF5DIxGNqc/iY0TB/yxYjkbohNlkSwhuV5npTHHkVYELw+nWaHwvFJqCCDhn0QBlqzMmB/HMM3axzx9fFaZH8XCatw278tlHJLPX7Z6T5Dj4s13FlxzlqPNAf4f6mNzFH0F2JZRXn2z5dQ6pSbARcbwWn3RChi2PASbCUrUbOgOIZaj8Ok4Evo5Bh1sYgMdLits9+9Brwrlj1pzlLV6Q0K8q3oPmoRvsY9srwflpL+9XBH4h6AdQGUlsMwlz69hpMk/CCTPTfzZTtSGERuC3J3jJrUWbWXvvlP+oyIpXEv2Z8BfNdWLHrpwH6NY6kw+n1ZbrMb2l2rE83xNAriaApDx8XY6zJRFM/HRhnwLtZFIcN1yHE2ghhQhWznTxtkjIAL2fSPXngt0/FbpMea+M/m4Ld/XWNehwvSiaYXsa41Jv3R8NOGaYvzKHy1/GID7OtNzAoQdOzEb4ULfcN5YUv/dZlK5xzwxQqfAn+jTXmSxogUJTr4KXGYyhDTH8adItojLkQrn/KlvXdxdShL0ITp8W6yX9Yi7D7X0gWMyPhCNifcaKGnie5giylQ3sdVry4ZEEuMk+qGkFceS8rQNEqesHFdlXMcKLRmPDbZ7TG7knRaluVOUSz9imJE5279/Fm1Q7+Kto8h3OOaQqE0GIq2rVOHsdi0qbKkXzZZoSWx1usYC6SpQBb4Xr3U30ZjH3femYzPV1wPdaus8+fTbYP4756CMS1LM+Jli6rXiRxwBXESSxDF84B5EWhgG1/MNkeQNDoHSI7sN/nAbi1rUYnd5jiUjU4K996nGe3y6qixMr1r1hVd9GNND8H0c1YVE+z5LyNVgboixOsiFrVh+f58KYpyjJCZZfD45p8SPDpf+ALMS3dJT6y2RBvOvUcwlXgh5qM3f2F8B5U511jA57uhpKCeypAj2H5A6AjksxszztRP7ctkyh4rA72hfL7Ew717AmbF/WmxZcxf8Kze/de6kRXQWTOWUp8gK7Q7VqCJlxzJCCQVAf8XpIJZZUYZqHw3DJhNPrjdByWy2phdXzH+JYEfzlybAztqCFOsAZAyZH8xykVRVJIqt//cIlVpQ1iKq7MHKlY90FymPVdfq2Z5zYTi29dge762g4XgSiZBXtKE6XDB6MOUfo9CGpMuA4sEDmfPmn30eaEYzO90TarXtH1c2FQ/ihErx4B0aTfe4TigDHHmCI1TKj5g1NbrnCBv1rW+a+rX5OmjBX58kOUMFtWpcvbkRzGb51ijFgzLVI2fRppcxlo38OICpT2hn/LsMeYxV34UTNOX4T5msJ+occ1IFPkCXrdj+4l+VuQQzVlVbm93Fglf2eKMSSqVCxJ16+Ba3kSBbFhfFGBJ1itXg7haSuBsQcTLZlC0LwNt1teyw+3zSWtNQ4WqzOffDI9lANK9o3We4t13rrsB11AJm76p1hEXL7DGfbMKQhkCoc3Y3MSJmAjKpTcJhKz4SlWRP9TMd+qCyJuRr5XRBIa6tf6rRpIL/kAhjJI4pj3/g9w40eq9dRXORJbMZyh9egwQJPFn33XkPP/DfmvzMOKqxQazGGCfU8zpIDNeq+US7kcDrvLdKkEnegYQZXsnKB0PAD5MBvIbJ68Jqt0wk9/o7Md7iVCEe0IoO8SP2US8cii2aWSaDZiikYVmMis5t7JQvdaqvjh1Hv3JGmLNbtGUCzWecLK2EQwD7K+IFXFOiqTTEVWchmLm46E2nFewObb/qoO7bvnf7hdo1GMu6UXMV+95dBI/2OyuF+vSVi5C+41xZ+U8hEL2q0AKbfvC3XH26LwO2jABmpVAzqN6uORF0QNHLflIccgdZOIHAMZ4NFsQM11UyvukWW9lmGCs34osSXuyQIZdE66b+PXsac8w/hP59lgnXXaBqhy7RNbIIg5mv8T6/mp1ULe/miUTrPqLtaHOgLVCjmOSyRF9nvLUgB0WCLFEi6b+4YJkHjjBZLbOuVwN6Q+H++ef9AEZxYqZE7Ktwv95M4W6rRrwh8KfbQhSMvPGK3CNJepuVmyHfitIHwcsKEQZvEeDFl/8p2NF8Fd53KcRSgIlCMggevJUMMzRmlBV8d4Acb25C4RZffUKXC/VFF9NyvOxzDNpryvVxvQJqv2fQufq3wUV0fiQ641RIrs2mYMFfrdW1K3hNo1/7AVilJt2TLQjikA8Si8y998Iwd5YABYL8trPp9kjBGIpHsh2uojfxvEsjmJ25GalqcR8o41bzzkBHRBFGDz7EQfQfHNRkA0kyWZPfYsh3rAt2sCnOJF0jbQuplxBX1dOJfJ9Wj7XFWwyKJd0CckMk2g1TAJZZZsii3mzikuT5aoMP6UD964R+dtTJZCGFLu/x1Y+LxzmWke4RaGojtLB3bNoaSu6kN9oHbqBPQ5H8aELQrPg5L/gXjMvdtTNJ6la1jChkt2F86T+4tjfq3oDKR1Jh/nqs5xR+NpgnevVABcL/yVNBtjBTOaLJIciQ9e/VcIOfLbBbVarLPEoCoK//iSHmx5Zm+RAJ+HegKyV7ca7wHRVOC7pNEIlLvQjnHiw+eP4QeM/1RoKrKWbtP6wCvSvGKvifdXGO83Jsgc5RWF7ks7whc3Mdw9Y42iKZzmjbRkjGzD6YC9T3b7HEpeS+Z2W+ikSdDe/TBmyb4aFN/6qlpO1GiAvrNrpwH90Oq6RFiIsbjBO2rWBlQ6JHGpDfYCDD2zSh1XE4maEbEXIG7SZDdGHa+aKEtcIq3C14rzR16VOARbLg25oCzi9cdzTb5azKGWEUP5bPLADl7SHT9touasYmc8x7Bphh346MLlFThprf/k9Y7mYP63PCwlwozaPIkQNR52wk5+1M9ZivJngIc0T5zIFxqJDBmwxWC0ltJA7tjE1Wfbc0lAriG9n1D7ncnrQiO3usZ1UKcUCCl48Lae+4zR43te2TokeBVD89PZMNc9KBJt59Ydum5N/ZuL58Y5JXFDrLamkCqFTaypY4y2riBOA6/hgWKqxBdkSaHX6vLWf8rQ64zHfFu12Ag53wKF1DTYvwt0SXzSth6sEQNKkwAhHNUBrlcd72YLsRn/cyc8CSUem9Glr5qAsX90PCAktqkweX4g0nGEvlSBqs7iGVAp8Uz4LUYM+KYJFUamr5qPSFkGjGn3SqPPonTRxFWrOQcVe4LXvJYca5C6HhmNeO19cqbDW9Q6HzPpGrfk/YpcAGP1p6Dp9IQjC68zFAKWRR1RYDRtqIIYidY7iSAx9mLtUlqQbEpT37uoAXdpC3xrineYCFB/Mga868CuBY2YHow6sgiBv/JRxk3+mt9lNedhY++7FYvh56DRHiZTuq+DftSmnbiYbfglrFVQBaqRgL+MxOUd2O61jbkaMdxokclr9I9kxOKNm8kd8iHwuchUFtxykSs2gNNElPRDfkezXRYBcGt+GgJqU/a9AgxZbvdxLAMoh7ubpX/wCywPY7dnYLoNx1KgLrRGCtkWJPvjHtoPfLeWcEnfjqL6IFjRRZp86pFed0klfzpe7DTpik3DtImdjYW0Uq1nx1WAZao6zEQUdCR7cgxXT+eFnM+sxm495WDqfd7COBf9rnPM+PKX7UooGEAVnG0hgXlU/1+XKFyAFCynGmOGkGmeU2+DXSXwn3+FpdBpRHNTdyJCsXWRuPPPfAOxDPvhdkUJe9aHkgG4j2y2fKM4GgjuDwulfJvMR2IRSFXy26gPWeag5PW94dtK3NcJMA0/HaP58AhElW5y2HAlObcBrpZKt/ENH8vx6m6OdCBCl4ZrGNKf6ZpngbpdPtRJ3yQMv7OA7Ri8EkPV+oEoe+uQtSc7gHUQdpehTSlEGmtD12l4hhyQhudv+Vplh5Qhjjmek4Uym0mte+wF4vXSfTKRMBPe6zziAl2JKNx/Y5hzGy8KKM3k/99HTtVyZ+4MYPoZSOKO9K3T1+y3TXVDcQuBZb2WeN1C0jAZN4qeGMclwHPte8MVzX6zIUSPq5HeN4WuESMGrrJkOmElA7AX7QY7sJjVJ3LOOXR8q+UWBBIdCCJrWIy8Zeyw2p3V0QeonKeDYhBGewLXJhNAOpphZLdVAnJEqCGCD3eDST0jNv5Lznkqf9KK32tZiQ/uNP8NMWX63z2TOJljP6Dm3POBEuPfSHSZrWR2736n4wUK2CnGrY5LGzAJxjSXEmyOC2BrlTsYAPBgRVYBjx73lLARn4FZtNZ3KM7y7s15hTtuWcTxM+jczyY+DJxzsMb7qN26YjzSIwbgviPBnF9xlSS1/1uMhEp30zUXuqpRGQnlA7bIMKs5QJzVSSnoZkpXwygJEew8p2GvR6dDIoS927Mrj0qUWQTmLHWQ2f6H0XyeDznW8p7U+kzaLN+NuS2VzOOynqk+zzOLexOFdmu4oUcqcKKCJMb2AHI/UfFdaUE9FyDB9J0tlieyX7DigBL0FrsEDlx+WBAonVYJU+VzUce38BKK+YPiG4IL7dlNZNsJ1C3mOJIrYIq8BLbnxcu456Ha/cbXpMk79xYG8vzs6b83RldzRRmtc+UuGqC9HpkvgtBl6XG1U01r4FKkA87fcGhgyS9LuuKIFIK5a/TJzlYznQxuQH1Yoak/3fn1W8LKmZMeqXeBjim+kQvXgSH/qsS8OFGVHvNDkXCHzOfUdqI6wKN/kVrWXnHjbwapZZFx2cdjr9rnCXkLtEFXmfJRzqsvDFfx5+4DuFOfPg2t1DofqAqPRPpsnKVWe+rFpj5DeSZVR3ULfKWImTJbI8pdAlXss/8haUJvEFuvYXftiLPYhPg75GDEsQ87Aaz3e4g2TK9dk7aNl721CKdPEp6cSvFdkK0BVtzTH6rMlMTYK6Y+BkDZq2XHJBOD/osA/GUUPiDajah2TH7vNSMoH1F0TiCpOIlSPE0eeVkpc6Ow0WvnhK/6x+Hqd4ncB35yaYMa1RCb8d/XM8GyYW1VV3aGeQAP6hZy2xFFIpbAT3beO+M7LXWD+i9Lq9yKuASOYG8M2L/LbZ1CPDCUuu3Zk4vFsMqmjqGUKqLH/JLZvyoIGuOd5fchUwpm36UrOIix4+iWwYh9l4A/Wyk2A19PZ3nzvRW0R0L4/TPOhoKdLM2/33mwaWT0ntEFTRNupS0CHEoCjejUGiOxVWiLfVCl1MIP21M3nUusN2b58le7TKFTKyZE+26P7MhYNNq2XvDiNequmEzE8IdWT1vBKoi0t68aMbMg2/hFYKnEo21PAsn7RaPHsrpY/TGp4T6kVYUQl36LXo7JPxcmjL4TeFc/JtgtUv4oGyKDo8k1WB5MPSAnh1JjFWtlAHW6XAGH8aqRX/CNoAEQbZSSOQMN8rmja8C3OsK12fPRymvfL6Hay0Ucs8j4dKp/i7Zu3NPphpQL9OogbM95WsirMkEUkc8fQIvRtPvoDDI/jSr2D7lNhK5wgiRcNYVefA+iOZ2spNZt5h3j70VbOVyS5dtWbOFeKbaZOxTKobCCVgqxWPTDKP14U4ePVuEAJAhr8ocwN9VH/IUML+uIM+UtKQR+h0xgmgo2HLrutAmvnz1DU7uBC+KQ9B14UWgTvlfcjXcjau/RA/FCItKp/dSoF0slGigdFGXo1oB9GwY2j597ExuzDhc7p1R0zMLPOcY1OGCRfnNwg7+QKp/OryLrwXAJZwV5Xuzif1+omaIdUSyNqm6ItonZo/FI5LSDS/mHoXzWLACZh1AJBLjtdqYxANpXI0JPZ/pF0jcfONbqXZhypJF1PyXdtFYw2AuSSHvgc8X6Zd6YHSv+gpnJ5dG/lC1DW2oLTfckG+l6oQYqlQw9Um+HvdPyTKgb7jL9BjFnToygOq7TwvyuioC+dJrkrQoidxBseMDlFbwFDqLgADZ74/HJ2GCpho2UZ5jexDixXZab84TgynYZiJLpGLeK1cddRffBJXltEbAjMwlN6M9/wSvlTNeuzmG0uKzNbpqq77WbEv4XWp6+wvfrkXoZdYbKVHzeQzfqZoGd+0RUfyCQVmkrTS9Hy7QbVMWwY8Mi2/loLhm7ZFE/B5pQZmOJ98Mkc0Q095LoYbqgTRy+lSwRsI6jNMtGcNby4LB2AfMTfMggDxVmxjFOABZzaPbL3/NYA0jTbN0T7Ys8zOpXnivN5fsef8Iieaq9imSHl0F7Bb1qmz9hgHneguNTCTxGYlUx2mgJm9bQGK5Sp7yr3mbUIfZNJ7iQavaU6XTZnKg59kSR7nE6pnadA/SaxE93r5CtnoIyZUVZJw7GN+2BUW7ZCMCrC5KyiGxK+NUpowhcSsZ6ltMJH/GH/lufj39rTKW4fqEdVMSh/uBlrc3xv5jy6g4dderMexqkrLIEYomgXDNOJHvDL40p1sbQ+0CVofkDPK1ivhSBNRLLe5Pv+NSHbJcQ9iZ6XJI7wt00JV4ML9Rnz0VYbijJMoHYTDWnGj1DiN6xFcYYty4i2Mj2k2lGml7Ls7fd0aF6aB3pxd4AMql37YyrT3LKH3SNakP8cmX94hWDJgr/3CwOJTGPa/sWUts8AWFmOWjBEf7szuASSUD3qHuvI0SXtxTDfdWhiaNOZkSXfkwHWjuWJ2NZ+Ws2GvGYEsdPtFJL/G4H99n0Py+dseQzz+AwdcRfMQgDFtBLq80gtmpAY69bpd7QxObBzIpr05m4FS0QhuTLOxOv4/pGftyxOh67hnMBWDbtUrYf+VuGZwWJon5c85l2rN/dqOYCVckaKMnnk/9pzCPXfKhHsD/zOmpYQesOJlWFgjzJWHOkfZMPxIugZVBh+UGpzTzlz/A47oPQ9WkjiBTMol4F7tnQB6/+9NRyhV0w/hGwFoTzAVmKOcewQJ/855j7siO/jXRcqFFIbDyY6Qvt3uTaupJg62RgHT6NtoU5T0KlyhDpewFhrV8B70631Ukzwmz1x/7Vj3ZqVpLo163I2ypU3vexJRP4VbnLJeC/BRfiDd2LcihGvEKyGsuksqD4tK1BywWPWfPpY0Qchye2kSu8xCXuGcvjkCC7K8F90YWUPyIWJbvJG41Retd0Ey6jW7lW0vcBrBdvRLeIjpjfLErPMlf2aoMmf/IrojEZ/AEqSWExu5w5HzRmVVvyJnw3Aa8nXP1S4HWZAQoPRUtOFnTGEF4JzwY+0sq84ioDU5mkG7nGzPBEnW9VG344LGkef40vpiuhsepATjEeBzovyGCMaZUtCaO7hmnlkN+jQ7HmuJeBfZUIGCM2JRaR9JBr/tG4AyGyzzYL6DlCrzWVGkbTnTK3Gifw+w/Ebn5MW2nAdFye1z5S4hXyHIdY/A8q/SJFLJDDTJvlyRq4X8OmolZGL7pmA6uZAIoffZGJQB7J9SeLYvnu3/+NlCwYJ8o7Nq3NyuiIuBu/c9Kr4W1zuq9ZD76V812E92niAXK9EqSG2hS9UbCkTXAmug52Y+cWEQJ4ZUdpgRTQcDxGzzUdL1EgsoK0lwSi0cLbBN1MBBpgrLEfEnaLrbRJWd4pFgLMv+uoHF87bRQqibvUqPGHv/WFSirY+uFaZ3qUZC/52ThlgXbFzxhnRvXxJO7ZfJNp405XfgHyY4bXAreLg+rJo0gd1bFI+X4Z3g8hgPMQSVvvO51MZ44TPetO86B/E1uujrOSqe4hgnKpd8yXOasgw7kllXdxRGTbMN2iUjGl9n1X5ryg91AKpRK+xOSejPYXkIBsx6C6rsoAusZnyEJOIQA1DIQc1mwAmUmbe4Jt86gechOrEZjWNmcT7Jeaem2RqhsG1PD+dGA6Jyw0h1UKfEVjdcq/RPJeTTS8z7fKsJakinwezmQItZAVou+NWLoP2z2OZV/teJAkbwRh6h3EPu93bGhCkmoDbUWSfZzo5OBUaocagulIlMGgG0d1I1QZSBMyInf62rJ/3Epg9wSsgXRuGDd7Ft09+asOPXJM/BxngY1diu7Wh6Nq9AI6kbGI+Iucp40ukmLGcZhWJQDI7LoYPoTZpM9f+EwVJ9pNV2VU/wVxUyF1jycpixKuaGAxJlEhdZV7qNMD7k/xIr4y36kQoAA8BzJCXjbEPpt5kQQMM6pwCkDs3XnbfMkmhyxDudhrtMro/9lMO2EzxV6Jqr1TW4bmPg5YNenAVncZytPeNgkjHBRXZa0T2k8rsHVW98Bf9pZto381BJIgv4PcUf0fh/bg1Y2oXQWyzeg44kovG6E7JhLeChSjKbOMZxUuzjjyi6K0rMr6V2tRS8G00MZQAvQOr4Vn8dgA+Rh7H0hwQpj+z8D9VHUme9YxLBf58GTeStkV+tvNfNLq3gL1Itbb5mvF8OVRiAJi3DzHoWd/GvxqQPfqx6XfdsbRDz2pzHwROJ3YGx6tifhfQ441kgVNeGHyrZCENIvt5Gcxia5fwTYVSin0+zHoz9UkaZzXrIHTaIlaozrbsQD/GXfWRfAOYqeEfo7CzJpsP7J3y2Wz9mCG1v11jd/XSVUfApKrnPqyWxBt5BShhvAAhhKtR18V/q5L5VHoxXJjKztzpr/DZVbILvZfKX1mkLZZYnzO8UPPOR2BbdMaO/WQC9viTVH1y30XgExH95QXZLmJoBw6apQnM6I3iCCMBGfuxvjgM0Tp4x35GbGs3MKrM45BdRhjQpuGGL5qrraUmwBXiK3aZ7CGE39RoET8cQubbujF5YwwfCnQSoMlIn76MGc8FQ/8l86x6yH1D3lIIP3Te1T3f8kSdV87D1YxEQkjXvZMK19DJAlnQYqU6lrWaEMel8/eauZWsls5J4FczaxSgiDHeLRtO1Q2nGXD86aMEW/y7QZcgC3MxyoYdcTzVzyOaX6Z0NadBr1w7o5d/K5FNcolek4wI76g8gm+KyUwG3YvZgsBaLKgmVIitwC6GSS/IAe0VbxTRAv7WdHe+ohDXYYSbPXMd8+DLMnXSCyQjqjXGuMDHrYpW20kFQkhz9g4YlZnvN8qSX/lePLUHuGD7g17z/CLJgaQgTlzg7cn/6sMuofEJFdwYYVcKWS+WvF3QTio85kT9+/XR09lsFrA0/Pf3DNTQDtV9NLNQrWHVlMkIEkFflvoH77d670WCfGjizAYDvbt2c8nrhk8CyhsPVBmVi4RwnMLtVEiTaj6EgW7Qek+3aEMNkHJt+AwY0vdRLSv3noIrGEVAa9F2/TfLVlhjUOnx6wlveobxpfAeVmqinuiKmUPOtmnuQlYJv6M6zYkMlY8UwWiUVQt/07xthVCURlF3LED8p8jfFFyAFYIPRAY+jEemnP6S7NgZ4ik/ie3DL7W0+sNx262C9rkTvPgBinRCm8DiSLBqtTcEkNgluzzAThKPZ0Tg2TgBjaoL1y4ZgK1HOh9cRu4BLqu8k0jih2uonUo++IWfNKqPgqXAUwa1Wr30hgMVqzKIZg8htN6adImBBDyN0jwQfodVLF6aL6xziHGZq8QPGVOaXdecNmFCNegDMAm6xuzz5kHJZCjRZ47Qdn/o9N2R5yC7c7Av+PzfSrao9cOLMljsrdsw2pXkutwCLegAC+fvppVK2c208vtRziX4fCyfE/dd7NjAfXcmWX6F27iTT4ZXXtsAvJJEDtovVPrQ48qJkBsaBpPH2s8R5Fxm57SreM3hy/gfxlmFwuzhdunlkj2IQS4yH5iCvRWhDtJQydq1JEpGw4TK/Dx6s+1vt75mMu/VxLlz8VUriUcaiG9OArB9NZ6APZMhJzAIC9JghFysBwj9TEs+phAvvBONJjF7r6gSOWfY1W6o9n35FctJTuUhyrLAakddmQLk8cmkKSd8M/tPEYrMwf9U06DuKkfxY3iXr0NmfiJaKA48xd6VE6aQ7OKnFgRaSzI3f4UTt13QjWv0NVhBk6vEMKsmysAKLwekud3/4vA4XG0DC4K8H6aZjQFJ//zMVpmPUWKf6DH9W2FY43t4GY6Ulqle0Ln2CuTCjsebBYCNdRdt2OxDDhU3D4rQdk2RRbqhZk14RVIC/hdABhliHpQIqiNWQ/rwyLQ8dVJsNy89Q2uwF4QLLqx42mQNgyhn2tGu8Nyntx7qRfLt3oqEJTHZeK4/5dEJM4GX35wxK69yZZ2S2qWNVJGpNqFJlNfrInz1CszEakZ/TRWLJGUOJly0qQvoUUs+In+9GsdisD4Pl2OBYpicLeBYZjD5kojQVymQroQ/k8YcO3CEeK9MOdDma4bqMyuHElTL7tc92kPbz0Xx5unQSNf3g1ntYbYIRFlPIFflwd+jfZnhs6+9QZeirXolDB8C0Y4FjqbTzKMLtT3IjR5A6bfI7lX6qDXVSzqs0vc5KyTaVmJa4M/47XFOk6aEeqwFbOR7EoAss0DvCKSP4OgRzYx/l0vVShe1xyriH7LozvQzAWcMVnfpPbOWgCU8nfQC+bAEXhGS2VAvFOmwfHmHIMtuf+PUX0IMCcceYXqFrreWHOije0z78nNdW+YhMjXuCoeQrSoIngRya2oWHEJJm+Uhej6Wf1YbDkbHyD0/a6M0mYiypcE7QH/NKMQvV8DDrblSF8TRRCnYsaN+2VUG8cf9por/GobnxdUBwwbI+y/XCv+D3eggtV+tpLsSeh0epaA7wYUkCZ6irFrAnw0EsshBFZxpq6y3SnCcprAUGrjS7F9tg0htEAaePZg5NlGslfqTIIZSTqLDq2Med6F2P4FE53kxHtI6G5N5dXSOKcA93wltW1i0+bZPCGrMbeSLuFpz5mrUvBeFoO9Rc8qzG9KHhtU0H+E3bEWw4sTp4k1zeY5wbcXvc7fyylznLtiPxRsx3ofgTdriGR2mmB/3FcEKspboTIG4+z3GbCBn1eQ6EQkcE7u5VK9z7RmUQFso7O+b5TnRTlJ1L7iyHWsCOYz9dN9Wsa0FNxGLvgHukyeE4aYjH0RqbCNwmiP1DnFcgBOIUqXaDkiQh+J68UlG8IaapEdQalqwspzorEHquHZcgWAU//RM2wHPEpvzn8Wz/h+RUv1oxV8l6gfUYx3fsiz1a2JtVvpRSPUXbmow3HtTQfm2T2RCS6NsZSmbh7Dzh2jeWcYOoHhjPSmVNGJ5vvZoqu5MSZfN5xEfYJXJ9o6bJFqxp4LMCW/Gohg87cj3YE1DMSSgGRsekvjM074FMGhPk7xFDOsT5Z4RD3eWA6S79dUIHLXjsZZdK1aiH0wNUzahGH72UZe0e4rJYJGa+I7Cf+ceu5K/tURhWEp5YndRu6mOMGotP1AcAvTcnd9CO1pJXZIafYoXOYw/gCSH/vRsx6P0oijN9sH4pZbaE2aUUWB4Y9ZgyM7SI9b71XzrEJXJT9vVhhMpuo7LsojgXAgOHHa7RG5XwRq+BbMY7kK6TWHiyu63/LDkJ+zkj349NSXjjqG1DCXbgp0p8N7k1nE+lzhaEK2Tto/xVhsHMQl3Yq/KWV2gP3M05//3gerIc4j8hTbRkss8NT4HktHKA1jMsQgSNihqJnzBqRYLlwvln6AN1EyfiNhKQC80Go7cVmPrBX9Lg71ZgK5UHG2wglzEG0Me6ac00dN5WzidkfV9QAnd1Iwxl5LPCnVS1KmOl2kaUgY7kG02zozg5KWX8W/rN3KxKfWuE+aK+MFvOqNA/yaIAnV6lI8TBbc9+55jyQTW2L7WqJ9Q/QgwTEZIBb0k6vC9aHebsQyZw1CHCgJsLcP7oJOLSaJnRX+thE4cAimuI9xjL5QKQlf/vMK2T1BaQhy+RVgcFLQbgjnSyNDEd8/BqV3gmRwWDVgrIYeLdRh/JgLtT7Aanc6pI6a/arVoi1balnVeQdq0mRPsfqjjN2EKucNncba4cZwwvQpBbsOATQJkaBb+4BUyHgXJ0e0VjehBbDZaDxLle6S3gvZdi9XzDnEciJO7DZNKRGD2eu+0Jtk+YmUq+LBf6AsuaVH3P0qI2g/itfmfcMasvziT0vyQRP9r5B4s9gntw9WgbINkTUWU3OtxN5wFftcrsI5baA2KV0Ch6WeDbGECSQrt+Engd2IwTpQ6WFKU2xGSuTUhpGxS2if8wUTm1D6PNpKVX7weO1aVzFG+GX1H2lWJ3xq2LuTuFlP930r712TaQPjmUXMkCK9pN0Pu8JRdo6ziRumA2KJPuRpRhdjB3Nf8U+1perbpvZNgvOZbboi2r/BHvDrsxD1AC2I4T2MQRe4iKvUvLKFSi9VX8XNXodwLA03zwUX58yflnfONK3n7z3fQ0vhwZN6aj7oMRf9CpQGI5Y9SjrapO9c0yXaRJYRjpy3WfFuFyCPIwBSMuF3aLSgrzHUHrcF+Y/+gbqcdgpmKjrjzh6IeJk128f4lUiuaxSlym52VqT/yQBg/ZL5AY7nlrGbYtMmGE1k6bCSfpsK0bjehE1rw2eUeBzoh+V106+eaU8DdR19KsIbzbqlX6MzfKmVoG9a8p9sxJhv1ly8SYSK/aq4Rl/KNcUerUBF9dcCCI79uQvSeomx+43E46FpOZRy4dXY0TN/2SjV8tCoHWyS8yIHgOojEOYa6nN/j8AsWObCC6/sjGOPyXd8R44/eGjaNWZYfs/DtWBAy8kZ8PfN3jtlfOACujIkmtNuoa/DUCUFrZ00Lx5VfZNoLfqlFZFthEkSJ1Pt4UMqS6aZ1Qweu81Vuwl4DYcsebZXIsLH9WpgsZr0HMf7eFe+BPN7XKs3wCETgdwjLpoDDNzfvq+MHHb6lcC+jEYeTvGigQhSMMnjaDKo/Bam8kglU8VQZvwWhYsPorYr5WiVK595J25W/u1RDgZxClI9YPO4samYQPNhKWTvmpG1AYp2T8sz2gVTX/ma/erCms+rTpj7ShGkjT+tQ1M3l89wP1tW/V1kwmi1i1Xz4V46dsToQa/etmwa3lQHfAqoxuOfg2pGrI68Xodsg4zt12PIlX9jE6WFOYiyuCMwIPzd+JS55hJ0t9VxpBh5JcETKPEdtYyH1douTYJY0CaAV22E8I0uIcEI2atL/+A08E795wKaLTxqJj5TKDsrSTNMdePJj9q7qI16nQRUUGuZRTkLYg8xnMAKsGH1RN9+3FLrl6l3IJMFL2Fztsk8IsbpndR2mAb6NRCeF9VN7NnResKHv7QGHj5XUamCb1dkusntUXwu6ySUTHfrwbv2hiZhTWUazuYwtQgkJotTHzFAVnSjgkpbBD8GZljyCKKdSnf9HJQAOViL7VU6Kv7bOMrn3D9gDvNoYTPcfV+RLykWbbUsYYsrkHwbgR2QRDQN4WvD96wX+hFVB69J58N6MgDSaAbwPeLexWlx96LYbkeRshUOSOZBbXvYOAvTJNq7zxlkuISWdqdvSP4ORyj8Y949mQW7sOKNXyjAsW0VxiqJX4HVTZ2OwZnUYgr0WdK4QPWnX5x0mUTr0CL6WT3MdLeQ/jO75WySOvFs3TbB7AnVr4uyqhQK9v/a0Ycf57CjHScIF/FJaHWbw4vm4FcwpN/NosIQCG3hgrMqNxyEz8MUbhMkIAX/k9/40L6E+s8HPxgtuj1d+RUmzjzKbrQN/vkbKsFcbwxCrAipFaUt3vKdd8RTYDVlBvBS30UVF2Uer4s9uZF1JllzYPaYhhQ1QkqpGibWikNYe1w2LGj8GkBpRpbxzdf8nM+7zHJqTfjjUrtvBaLxvqwNI4DRIIw2sRAhJ57DYjdE8EEbYjzIHJfrkHMMLRCbH/TIOL9JbYS7FDSm3X91ZAV68KbP2ZGzLFlTRlp4l6kB+7EDiPzcCjIekZqBbwp4HxuO+m53ileJNkM9slAE3axkT5lmbpA5wn33U7tiTgHt1AuHYOs+BOROny6mUrV8iHgfv2EFEtop4cerdBaaJmpzP+XdwNUmuVur1UpgMA0TVcCzzjFoNa9O5YOMqMc6EkYW9hqRMqmNdDqAv0bqWzNu2Mp43WTDCJXyXT2RXax9I2BDbUt7IsMgV9C159cjvYPiaZULuxHsvtfKrnezDUIQabiGvpMxGwuosEUMOYHnDPZxBfzcIvhfpEEgxdhfNcpb7iZZHojqxb3kHGFZUB26q57Ir9dNBJD2plA7EzBklDGNlSJ3r1X4tNInc+6JsgcPGtLlgOqzmXA8qOucBD3oesg0wUSN4NmIBBV9E6s/59HkPbRuXToHlItFMwmVHcHaKuR9sqe50Wy6nwIMYFaAdbkEFEpoji0eY1J/oK75pk34C1iSCp0icA7lcbeFnO3iDC/ZH37hwnFrGefMNgdQb9ZcaPvG6QA+10kqDfllyKob/Efpss9XuF17wCSXMiB/AQV0YS0Ws8y2mqCSM3sX1I/sQVGGW7XEURWujkVc58xqnw7+UrefZENnrwReasHx3jOi+qG+Lsl6cht3edQidvLY8InCWsXxjzwVPxkQiv3Fp/gUCyyU5gyIIyktyYK8E8cr+qbUq7ihHIf0Yu4l9lcJmbTCmKjgNX7Dl9G92eXQ4Bcj3hB8yxctQQp54EQavM9t3SCOcUEnnB9Pa7KF6nBNeMR1CO7lkrukUZYO7+PqQ6+kh7v4Ee9WeuZIIVXjgfPa7b6AoCoGNShrMziIHkw5Uz+Q6+OKWjZDLQz7tFy/yhXPYxQx2g0egt0YTH5owFSn8cVX8wRUTjN4Ut8AUWfsuuZFaveIOk9/tsVtonVb7hkhzJ87Jf1iBpxqiq94l4dLtR7YfZLkLRlT6BfJUM48s8L2CdutkUngMRS8xWLdciAVKc6DZ7MfygC1JrwD5J9H6z5U6cC27P9CJ5pOtNN+BTovzHZckXA4jfKeFHmvyvgR5h4PcGUomY+47KHmDIEvG9BhK8F9BxWc/iJCaVusVgFgh3wX1guStETYCTgqWSkkhn9JIsu6Je7GUfBMT+H0ehryNcMGbnrcY19+AzOR+1Wtt1e0JtohF0qrdthIP8QQJ0lpov5ew03y7ZDxWstH4wObkh3uA+pQtOPbO2htmfA9ThEvZdl4qAoUJQah/vbvlHspDLzPAbF/B4Ey3UVSoOxdmFR2iGEwgHy2TKtWXafNQDEIFnN6nhVgZ0t53sz4AAa7dARQbBbR6VfegjREo/0guSWgasmjdg2T7dYptWOWJWrMvk8CH5l5x9OxN4VzDdGjaTZrCgSxfdiboewHvLZi+FpIo2YvBGuyoEEc2TvgeF1wANemNFLBirivP5OlFXDAZ/HeEjg+1GjXO2eIDORCvLOSTPua4acVdQ0A3a95RVEYugQ04ZAGTKJRNa6plqyPWyCuN07qyHtR4OdWyQygbVW8m0tWp/x0L9qEv9vS5gWIvoRegm1X5HFpw7vaqD8qDjNl7oC3HgqCOUvqiTsvd6grllN5MoW+28ots8/xwyQGXUyiyRqr5Fgm31WhgA6Yswwj79pmi55EGXfh34tXdpOtPlkyu1Mw/QOQ9PGefaKSW7xJjqJ2UToNZxTA8GT40QSoxibOxyBF96wuzIWz5wS6AimGfdOqlq/9hix1mcmgW1S5ELaqFNwi1r7bV5FI7LVZ5PXx34BzWIpjUj6PLrwhcMFecw099AtPR+Z5qZ7ToI+vFs2nG0WlHjqUB18B600/LBPJZMJnXXtA43CDfF0yf4uD7Ii9OXZPp/KlOigItlIcPOJvuM5s9pGZ9EssDcCjV/thkKuVjMIwBFUc9FemRTHWw99HmGuyIAVUeNbnRvUo79lDL6dg2ZwstwuAmjuOCeq659AbSwZ+aKPPLn43VITedBM+ifSqe1D/z6Kp0x+0ncBwf6Hlt5KaM4IiXNrPZop5Y5uGk52NR/Jd7rks1L2aB1M0FgHrHgxv/QeRi2x76gDQNqHot8TX46kJhYGh7ct34GoK/FBvOoQd5jWwgnIcVovtcQB85XSCfRXlWLaP5xblHDlFH6RUzakZVf4fE7omPsXV2hGgE/CazTmpiQOzPoJOMXVI64AYM/hC4whRIUPe6bkyyPqqbNBdcgui+lPvBljUoxn45z9JD+4qTPf0bllQjKecjoP2x2X+bJpRXeN17Kk9Uway4ZsTex3mw1Sjx7yrguKwP1cMn8TVtaZOCDwQzAQt3Y928EWf8lf8SrbyFmY0GEmfKSb6wCqwfQHqF2C4DdcsCkGqfc0CLalb0l1BX73PeEHTsxk3zt7KmXOkMYC+5jAinBcliXiTz3/GrLpLEevhG++GYUjTHAY3VHqIWJ/n0vx5EXRhqJqEr6UOcUTkVft0zb4k865oP+CvEurb9s/JQ3KFbVY83vYgeCgZaraBB5DsVYL5Y5CBKMnDjvCEs1qqpFnG51GCTYmVXIf8Ll1l8ElpXUyH+nDZ4548Is1o/cv6UDbMe230KsA+kCIM1L7iGbJ81txqxVG9ttW0ByAbwGHW8Z8lGHljlvLk0sKzmMOLNcH2yqEyjafqQeWX7FJ2bzzIa8LP2sdojDfvnnn06Kue5ZNuu1Z1ShxPLj8KpRVoBFpK/1Uiep7tBhGnhM8SW85GrFBzotQPIClAFZjkgy1hPrRdDGU/nBjJ/nfYK8YjzsMrdr7JZqwEybCyS2qTdpFBlOnE8hHq4FOjRtKhyinUoBXMATIYlrxc9x/QNV99G6vHIjrIrwP4MYvmdTudjb537tqlDW15kOfNf4aaRHCJ8k63Wc/j1nnCb9rVgXMbiCNEbD0gcAHaIcOkeWiOelZlJ1JuO95NbVxPempObbiSNR4IkUZ0nUj0L1dSnG3A3gW93UAz6UphJ4e/Q+SfBXEWJfdZFKS4UvzqyvemPlgrNkqjWFVFPlf10uNZ1r1qiwB/8g87qkLMXkDU8MbJtQ/Uq/oIbvK6AiVLsraJr9Q54Omdg+4bozquZRlgjvIinwJtjikaolHrVnjsgNBm182nkoy1iidPlzNFP2xGPGh7W/PTPMyDXQ3yG4ahnHyHctvCeWIfPwkrEUf02tMaA014oIRxHrbmx/upUvqq9NpsY33wWkXyN9jdd4zpbfGWZwfXZIoVpD/u0QQfosqB0MSuVkerjmmBVCgiecBkyiI/Ea6qMriAmDNZiXPvVTbe9BRLtlhTfSQMMsPfldF6dGwBdl0OxiELpg59aNc+5Y19IqgAMWWd7PpcLjy12w4FHljMU/46blM1m58FAY+nxy+POqB4hQkXAdASx8thZ1S8scjr4JsoQyt5rXH4XGFYksPb1W4RP7PnXyqwf3Kthylf5jgGz9b8SdXHDtSueuvJM32PiporoUv7GUSkwloP+dIXRHTj8eAR3OSqYwrA9+aj7LWi6AZ3DbIHXTOR96NxQL7dTW1A9wT9c8z/lfSezhRCV74xAVN8o1co1b2gjVvL8usZ/hOm8NkCE2+EWEmyOdquSBYfm66meQBqSLSFLGZKOaHkiAz4qR05K3tnIe3FoQy7KUm1hBGKTjtfkNd7r5QRQpYvHCDJTCURiA5d/xGxw5B0Yj7Y6+F2WezxAuTfOAX1Z/qPg2n2Fi5gdsKVatt3HVLmDMY50/Glz7/cCNYhbkxYP2v0WbwFflp0qMu5JOpAbvuVc2geR4JXxvbqDnzbZV7BI5JHYl2PwLAW44j9V8frox8DL4x9LqPM3fpCLMR4cErUro1ssqWKUzqcTgYatEvPWUk4EBW3syvSJdT0mRBIdR4+OJQX+egtA/WoYPI/pfksfZ2mmmEAiphwYgt/Jqn7JIJcg6BFs1t/H5Ev1cSStgDTZEPz/dGfaL1F8xPbhhdt0HOKtqMNz4kkgfrOSideYjHIF20ObziEMk6sQXmhTuvi2X1qUnqsOBNc7WHvmbmQC2qcOcWI3VWbJBbwKEf8DDFGlO9MGkAXNAepXUZ7gy24PpFiqTO8DSfJONDfNVZAtqilQt6w++cx/Rjb49Jx/tMiOMcodeJdwcqaT3cxJwyj7A8bO0/k2J8vemgMeJiO8F8LWf5D7o0sb+N0JVZdxbR6g6EHd3CB57SG17KCLObFwWPUcs7qVPjG1vqAG0kvEd/VbiOTy2vO2eMSu9+Kljp87uyckXwC3mF+y1FrOb6ZqmdJ/LOePXfKK5AFtmJba81hAufIZZp20rJtnQ42IoFMOQVXqUaVYQP/qa9dJwL1WZIyN/+iL05rCYUnXscWMZOv2vaSciYPnzTTuYh+i7CUxVhL0EI1RiSZvXE3o891IX1C5IyAeW4oAholDhcpeOQmeqAdK5db+iHB1FboQemZUKbc/lpil0bL6/FdwXMQxr4vyPPTvMywUmx7C3+vCjofSCwwE8i8M311g+J3mcmcaM9AaeY4iSfOX4Pc2gWzFIN384ulah0P4RTROtOsu+5UobdexJXkAPHz5hDkrLyi0iqPRKD4Qm8Gm+qlSl4CtMPmGX9LrDYZPYfueTVKmJ2t1r911dmxjr3YwHMOZ6EW/QtvR7FPHfoTGtZN4EzAeicIoCZNu8jj50u1f8YweNAn0mq506JCaQWq4j4HMJt0jAQw0UFpny35L2CSFVrIdwWXpIMbPHKMnO8BZlCooWo9F7scdVqGU9aHjaiz6+Qerv6gtq6fJ0/+yjQ6lbJCk07lBfAs4jf8w6N6HMJZ/E8A25HMyZZGuViTd1+El/yuXTcrFAqPchDoH2z+U4osjLQq+qHDsKUzq6hazqVreI1HoMC+ZZWDNpgMiTTxBXklWKhIbZo9TmBFQe/InoYzWpHnHDnImil9cIIbpdHiFrZEEOQTeGkMF6KQu60+FQswqPUPLmB0XETrYtivu0vcv0qy+94A7xz/tRQ4DOOaJYQ/lkcDeEsRYc595MaqgCbgsRTGq5j3RMflat3wwDL50p3s+2QXcCX11LNdzrgVLxhCnzWNp1KO8EuZhY8XYh03CeLQKxL/LQe5ioPt0b21DyvkyX5go7vpOmD2PqoIgu6NGUGyGozfQZfbaFZppAtF+y/ctpPAs5uUgcnt4RN9KHN84DWIhPwvZLS3HwjDXltpFw/E7Msq3dAyp5G5cdhlFUa6KeHmq5XSOsEsvPiw0X/CI9p5Zhh+xWxj20NPzAFc5xKOXbcLcYlOHE/UWOVzTbeJ8L0DTLbWh7gYpr5vN+yQtJkA1tO/X+cw40TuYYgs35ZhctDh7+hNfBRzxh+i8MU9bbqyA6kGORc1O4zCvWoS5sVdLQfcAS5iip5IUqoKFuYIDeJk7BotUEflnVpVtMB8+ElpEnpznxeprXhbmP/MYGpdOBEzy35fxCn2iWZxT9uWznJ9pdPE/c5CfFTygLVvVkR9yVUANMY4q6KyCx8/hJR8h3ipxCZckIs1z6EoB9D0r415HECN1luH+5X5ZdAoNR1lHw6/TLe7Lz5ZKzK940EaNgcR/+Hsn0HQpTBDcwkiwa0SWLSBVeLk3szELZJV67wgZWoLNxfzfqndhlhVarpW73wIo+myxxfDNJ1Jd8Vnz4PWuvGopAiMtkmnNvvOWzeKhCuT3U9s07Im+xrgcde+nfQTgZEFe5Oq0S8dDCBFEZ3yW6E5vYolvA8K024kB4vwIkhcJ1+5GTHggH5y66/pJv8GtRhNQC4cowRpu9A150L52O9PMWOC1ixHkyNC/JBM9ouDbqg3hi/WNvKCFVvrdI4rP0IeDD2bInpXSnlaJJes0qReEB/RmP+NiF/ZfcnlIFWJVm01Ryi2zS/fJ5QBx+M7Gf5queO1nCFtZpN5AZiGN/NmvJGvTsPdP8YrNfjyHO4A1EjzAcfqAvuMcKQObP0TIcSH15yn8tEhNAkZHkTPdEptV+iNZpK2muvE3PYvkRxqcXgkFLwtAdZkUPClvxNgpPwEHbA+WY7xlcr+oogoADpaoAmzy+UbeT0LwK5JmzZWTfgSZJ/0BaM4QWrZFzKPC9ODPu/A2Ubw51Vhu2lDebDGKZi8gEoQp/yetAut4LwmLCmO1yG4KcpPtgYSLA0ZYvrCi/UUuawbVuTDkndFnfT8miduTR4+M6wj11zzohBzKt7vZ63dhioJDPonP9QkTPHShjs0xJWCXMv/bvgA3EbUypvHTyJ+tlMvHZCwWAQH4a+BXCTYkuc7WkToyNf8rO/iOrXSWO0CezLHK4C2KV83TZXquO1Jb6C2zRH6ZifMvxAXQXGlS9cfWiZMWv1VSQ//X8rnj4czToBv4hS0QlOjw/CqO8W0J8o/IZIuIrozI4M6896UPxoj55c2CF/dssa5n5jOU6D31QG49gWZSmzX6lpE8QGjd2xTvcQpfBBs+ChdLnW9wy8IpY1n3gLSZhQvCfecaJgLRXoaz3IcDRdLEcgMnxYkavHcUG60OzFG/nSizYfrO9Cg8YnqIkY/5ut7ADMqShmRxPuWYGtK257AELmV/i+RtYDd7ZDvgXagWlU9okW53jOmypi+AdS26EzfppzCYZrmPsi5VFfziiTDcm3YaG6Pf4Cv9UeQ6dlw+sPzi3EORu3j1qif+urR956OuRMDNxVReCDebGK4SRLt2Ldq1vp0WMLMtUPdBw3bakijTN9rhtpjTANnzv7dpspiXAhUYChPe7Kmjr5ldPzVhS//JMu0ZrvUrbaWxDLEz7zmAvX97oYhUtrwgGHWSmg5tBQdO29BmHJGPVMg2bsU7mfNkljAm6w3S2zZj/MuYQJZqYZKFrkeTOccyevkcImyK0DGSrjnX7tu1T1rlrh7Ql4abTh9hDLlVJauQQ9b7ugM3qj9ktcuWFGDaExixuCNkYOijsXd0u+fulyzpd8+0Tbi9FlN6oB/mfaJL/Pp2XC/9JPv6lu7SkNoyXWF+IMInBXDsBuzyY8jbV6QvkDUpbaIYQu3WCPtTP6iaxQZl7osPcvluZMsXXUCpds4BYsj1uyCfRTAcYc2l84BofAlHxOzUKGB++RFsb2MqBMvptu5jhzns+UQWfMm0nptB+6KqgVnB+3VoFmIl1HhfFZHu+sSLsX4mo49LBTeWz5OtgAw37wdN2oK+KT6b0Cqmo+zhB7Vv0iiMAUlisLptJR8UnkYijERwu1QqQSLdZ+3QyHxZ8tYXqlTOBd9sUnFoyfhj1X1Wv2NtFx8k93yFX3InFG3pgF0e0xCYV0zpp7Zx0RrgeVgRSRXQSarYgcOpa17Ci680C1btidWOoiQuReyNHz60uhu8hn3SnV+mtFp1uiFGdTixE7HbNEjAKq/zmXdSKJOBj+IFGLPxFfwArOMH/TSpnhyHn7qihmwVrWKbwwol/YVeFzNOuyeeWcNeD/AMTpGzCDX1Dmkt23E3JSkdtjBMi0mH0Jps0jTK51Got5PW26+K8DoTkMeEXwhgnjefenPWsj9LZaavYDkPFUYrOnJZBVGc8tavbUHaQ8rhosD0PtE4xFMRjXoIE6xR+WSQ19NsRx3pnKi04omPlqTMOejlTav4TKj04/cLkO287uwOTzEIJI8GIOuX3EWdPofmPUcrAB6V/93x2t6jBchSBEV9amO7wiWLIv5GUEMpDLJvscOaR4CyeWxwhRvvd4ogSKKV+N/gGcPuqPF6O270EJV92YT2W4SKJYgkNpjyixa1GbzG0dq3/IdFT9RG5evZU1uecj889v7Syz1eIU0TTj+rQu00vgaTWl2QycI6YTyGh6hw+rNxaNd/wanHM+hr4aCUKTefYJ6xxNus47c4b5rQgw1JTkXwWqNEnECPBgfk2l7hNhO7+SKYZafeMgNuJPxkhxo1FAutvOZiWHyqrdV9WJ5LugErLfasTzAKpdKdeQYf8eifJrf5dZt/hDD28mdx7LNFp70C9GD5nVjPFkE6c7wgKtyBIv6wugOeQrm/03bLAC9YtV/qV0N0l4nLXKDNyYfCvWRyClTXmNr1wFxqhJl3UoTBrpwiKz6AY+HYDrJVI/5ptj/LbZYxrQfLmF6Avx3Lutbwp/Y8xTuf0rbq+gZ/d0CFiSQMAAa/fbTRhW1T5eRNODkz7aFIfVa+BbwEQQtcWIpzLpziuXQyIyk8IffIihCOMuqPg0ixhVSPGRhdQhNRfcchJ/O3XIraP0XZosrzf7IMNqTeadf0Qed8WaOyGxhj7EVTfVnia27L4drxDIfgGNLH6sltdm7JX/XkiOywone/MIk/tnSKoCjlzaaTCoTMQ6RHAPtBOMO9Yo3vBhuYjdTc0qgCDHfVIz/po/6Br802jpX/pWp7oMrYMDqBdz7BlvQKlgve4TcMy7gSPXYIN5CLQdiC3SL2pQvjdXoUPQVLbkkBLXit+iDEsYsqFFkhPA2Z7MSOHtoyD2zoAr/as1ep8A+TJFJVn2lWJz8s02qlcxUfR6AMNblGXdbpoGEtTwIkxVmLF6bMYe3EEGuiZr5pMXJYNyOhG3QBVH5rphRmiHs27J0zam4psukVZv4hH+Y8hgnEL8iJ7xKIrIeZYxp8Ac5QfxGVEC7YbJ9608iKY4tYzXwE5rzgWxpF8e+ILezFkwlWbCryM7vg9P05kC3UXzCiHpqiR94FTpK9lXDTkY/589d1z3eUluXip1HMR4VqEvy5hXMbUOTII8CHGhSnO5jE3oC4Sgw9ml44pIuijUbxOASBfux3X9qMW2+dHlrhHUHse2Lt8ZjQUzrfxd7pTisWUDqGicYCCQE5tliSdC8WWARqVyOf5W7MZ7aRU8BlHrkfe4ht1DNs0/7S5Re5lZA4vsJ9EHZG8hQguXtc+DQSPVMxpQKPYL4YBiGrwLxc4lspxcTZWqtb6c2POPLKfCcGB20cGOpbtUcNnCpvc24XX8EMHy2n438U5TZBx2WdoOsOGCWxLHc5TqOQCTfRtGtWMyhhxIE9AAiCXeuuc2/5RGATrnLUUIriwihU7obZ6HqEDmcqxlL4+jcwlJg6Afie8kqZ59bPVP1f6qyhNb1iRUAsyRxXrr4Sn502utDF3KU3i+7tYaz4eiYndDtO4KuvbYWin6EFadYcs5Q7vtKmusB01olTheuA4d5C+WjCtFaYKgSq4hyTWqF5N8EpvXO+UX/CmyCULfa0rBBPdipN8ZwjEIl2J9SgS041b1w3SKo802emDKmY74VZ7QIk/Kc6536s7d9InT/ZmFJF9CBE64koMf2nHvMiO3emiBOeubCzxdjjMMwTceacwxp9hnJ+9U7Ju8PhmsgNQS8twLji9W/7kaaaZxUX/rRg23/OEWbdREBqhb/QvHQVs7oR7AZuKEoSax7hTXslsZkYd5PJa1Eb8titt1aSmlsYfGcvaoA0PZezlOiy7gosTRTAavnyFj+n1POZ6861HgAU0nRNe+U8wO+lnKnAU4Zvdw5zVY3ZAlr9HxMwOLGnb7021dkzUbc5m64nUh8ZQmQ2DTdIbubwFgpReC5GVHvi+oghmz5fOKZSoMqEBvz7MSmR8Kt0rBzuJUDrZu99dbmxHnuXUMWj7YSYD1h1LfVvCly/MoNw==", we = () => {
	let e = atob(Ce), t = new Uint8Array(e.length);
	for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
	return t;
}, Te = Object.freeze({
	mode: "sorted",
	historyWeight: .7,
	convergence: !0,
	convergenceFrames: 16,
	animate: !0
});
function Ee(e) {
	if (!e || e.mode !== "sorted" && e.mode !== "steady" || !Number.isFinite(e.historyWeight) || e.historyWeight < 0 || e.historyWeight > .95 || typeof e.convergence != "boolean" || typeof e.animate != "boolean" || !Number.isInteger(e.convergenceFrames) || e.convergenceFrames < 1 || e.convergenceFrames > 1024) throw RangeError("Invalid Gaussian rendering settings.");
	return Object.freeze({
		mode: e.mode,
		historyWeight: e.historyWeight,
		convergence: e.convergence,
		convergenceFrames: e.convergenceFrames,
		animate: e.animate
	});
}
//#endregion
//#region src/renderer/steadyState.ts
function De(e) {
	return e.length === 16 && Array.from(e).every(Number.isFinite) && e[0] !== 0 && e[5] !== 0 && e[1] === 0 && e[4] === 0 && e[2] === 0 && e[6] === 0 && e[3] === 0 && e[7] === 0 && e[11] === -1 && e[15] === 0;
}
function Oe(e, t) {
	let n = /* @__PURE__ */ new Float32Array(16);
	for (let r = 0; r < 4; r++) for (let i = 0; i < 4; i++) for (let a = 0; a < 4; a++) n[r * 4 + i] += e[a * 4 + i] * t[r * 4 + a];
	return n;
}
function ke(e) {
	let t = Array.from({ length: 4 }, (t, n) => Array.from({ length: 8 }, (t, r) => r < 4 ? e[r * 4 + n] : Number(r - 4 === n)));
	for (let e = 0; e < 4; e++) {
		let n = e;
		for (let r = e + 1; r < 4; r++) Math.abs(t[r][e]) > Math.abs(t[n][e]) && (n = r);
		if (Math.abs(t[n][e]) < 1e-20) throw RangeError("The render camera matrix is singular.");
		[t[e], t[n]] = [t[n], t[e]];
		let r = t[e][e];
		for (let n = 0; n < 8; n++) t[e][n] /= r;
		for (let n = 0; n < 4; n++) if (n !== e) {
			let r = t[n][e];
			for (let i = 0; i < 8; i++) t[n][i] -= r * t[e][i];
		}
	}
	return Float32Array.from({ length: 16 }, (e, n) => t[n % 4][4 + Math.floor(n / 4)]);
}
var Ae = class {
	previous;
	frame = 0;
	restFrames = 0;
	valid = !1;
	reset() {
		this.previous = void 0, this.frame = 0, this.restFrames = 0, this.valid = !1;
	}
	observe(e, t) {
		let n = this.previous;
		(!n || n.scene !== e.scene || n.revision !== e.revision || n.shade !== e.shade || e.uniform.some((e, t) => !(t < 16 || t >= 32 && t < 35) && e !== n.uniform[t])) && (this.valid = !1, this.restFrames = 0);
		let r = this.valid && !!n && e.uniform.subarray(0, 16).every((e, t) => e === n.uniform[t]), i = t.animate && t.convergence && t.historyWeight > 0, a = !r || !i || this.restFrames < t.convergenceFrames;
		a && (this.restFrames = r && i ? this.restFrames + 1 : 0);
		let o = {
			reconstruct: a,
			valid: this.valid,
			still: r,
			restFrames: this.restFrames,
			sampleFrame: t.animate ? this.frame : 0,
			needsMore: i && this.restFrames < t.convergenceFrames
		};
		return this.previous = {
			...e,
			uniform: e.uniform.slice()
		}, a && (this.valid = !0, this.frame++), o;
	}
}, je = 65536;
function Me(e, t, n) {
	if (![e, t].every((e) => Number.isSafeInteger(e) && e > 0 && e <= n.maxTextureDimension2D) || Math.ceil(e / 8) > n.maxComputeWorkgroupsPerDimension || Math.ceil(t / 8) > n.maxComputeWorkgroupsPerDimension) throw RangeError("The SteadySplats viewport exceeds the graphics device limits.");
	let r = Math.min(t, Math.floor(Math.min(n.maxBufferSize, n.maxStorageBufferBindingSize) / (e * 68)));
	if (r < 1) throw RangeError("The SteadySplats history exceeds the graphics device buffer limit.");
	let i = Array.from({ length: Math.ceil(t / r) }, (e, n) => ({
		start: n * r,
		rows: Math.min(r, t - n * r)
	})), a = e * t * 136 + je + i.length * 240;
	if (!Number.isSafeInteger(a)) throw RangeError("The SteadySplats allocation is too large.");
	return {
		width: e,
		height: t,
		stripes: i,
		bytes: a
	};
}
//#endregion
//#region src/renderer/webgpu/steady.ts
var Ne = class {
	device;
	format;
	frame;
	callbacks;
	settings = Te;
	disposed = !1;
	generation = 0;
	desired;
	failed = !1;
	preparation;
	retiring = /* @__PURE__ */ new Set();
	pipelines;
	resources;
	state = new Ae();
	previousViewProjection;
	writeIndex = 0;
	status = "sorted";
	reason = null;
	allocatedBytes = 0;
	constructor(e, t, n, r) {
		this.device = e, this.format = t, this.frame = n, this.callbacks = r;
	}
	get snapshot() {
		return {
			status: this.status,
			reason: this.reason,
			allocationBytes: this.allocatedBytes,
			frame: this.state.frame,
			restFrames: this.state.restFrames,
			valid: this.state.valid
		};
	}
	configure(e) {
		let t = Ee(e);
		Object.keys(t).every((e) => t[e] === this.settings[e]) || (this.settings = t, this.failed = !1, this.resetHistory(), t.mode === "sorted" ? this.suspend() : (this.generation++, this.report(this.resources ? "steady" : "preparing")));
	}
	resetHistory() {
		this.state.reset(), this.previousViewProjection = void 0, this.writeIndex = 0;
	}
	report(e, t = null) {
		this.reason = t, e !== this.status && (this.status = e, this.disposed || this.callbacks.status(e));
	}
	suspend(e) {
		if ((this.desired || this.resources) && (this.generation++, this.desired = void 0, this.failed = !1, this.resetHistory(), this.resources)) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
		this.report(e && this.settings.mode === "steady" ? "unavailable" : "sorted", e ?? null);
	}
	ready(e, t) {
		if (this.disposed || this.settings.mode !== "steady") return !1;
		if (this.resources?.width === e && this.resources.height === t) return !0;
		if ((this.desired?.width !== e || this.desired.height !== t) && (this.desired = {
			width: e,
			height: t
		}, this.generation++, this.failed = !1, this.resetHistory(), this.resources)) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
		return this.prepare(), !1;
	}
	prepare() {
		if (this.preparation || this.disposed || this.failed || !this.desired || this.settings.mode !== "steady") return;
		let e = this.generation, { width: t, height: n } = this.desired;
		this.report("preparing");
		let r = this.createResources(t, n).then(async (t) => {
			this.disposed || e !== this.generation || this.settings.mode !== "steady" ? await this.retire(t) : (this.resources = t, this.resetHistory(), this.report("steady"));
		}).catch((t) => {
			!this.disposed && e === this.generation && (this.failed = !0, this.report("unavailable", t instanceof Error ? t.message : String(t)));
		}).finally(() => {
			this.preparation === r && (this.preparation = void 0), this.disposed || this.callbacks.invalidate();
		});
		this.preparation = r;
	}
	async createResources(e, t) {
		let n = Me(e, t, this.device.limits), r = this.callbacks.admit(n.bytes);
		this.allocatedBytes += n.bytes;
		let i = !1, a = () => {
			i || (i = !0, this.allocatedBytes -= n.bytes, r?.());
		}, o = this.device, s = [], c = [], l, u;
		o.pushErrorScope("out-of-memory"), o.pushErrorScope("validation"), o.pushErrorScope("internal");
		try {
			if (!this.pipelines) {
				let e = o.createShaderModule({
					label: "SplatView SteadySplats",
					code: p + k + Se
				}), t = (t) => o.createComputePipeline({
					label: t,
					layout: "auto",
					compute: {
						module: e,
						entryPoint: t
					}
				});
				this.pipelines = {
					sample: o.createRenderPipeline({
						label: "SteadySplats stochastic visibility",
						layout: "auto",
						vertex: {
							module: e,
							entryPoint: "steadyVertex"
						},
						primitive: { topology: "triangle-list" },
						depthStencil: {
							format: "depth32float",
							depthWriteEnabled: !0,
							depthCompare: "less-equal"
						},
						fragment: {
							module: e,
							entryPoint: "steadyFragment",
							targets: [{ format: "rgba16float" }, { format: "rg32uint" }]
						}
					}),
					history: t("steadyHistoryPass"),
					resolve: t("steadyResolvePass"),
					composite: o.createRenderPipeline({
						label: "SteadySplats display",
						layout: "auto",
						vertex: {
							module: e,
							entryPoint: "steadyCompositeVertex"
						},
						primitive: { topology: "triangle-list" },
						fragment: {
							module: e,
							entryPoint: "steadyCompositeFragment",
							targets: [{ format: this.format }]
						}
					})
				};
			}
			let r = (n, r, i) => {
				let a = o.createTexture({
					label: n,
					size: [e, t],
					format: r,
					usage: i
				});
				return s.push(a), a;
			}, i = (e, t, n) => {
				let r = o.createBuffer({
					label: e,
					size: t,
					usage: n
				});
				return c.push(r), r;
			}, u = GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING, d = GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING, f = o.createTexture({
				label: "SteadySplats 32x32x64 STBN",
				size: [
					32,
					32,
					64
				],
				dimension: "3d",
				format: "r8unorm",
				usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
			});
			s.push(f), o.queue.writeTexture({ texture: f }, we(), {
				bytesPerRow: 32,
				rowsPerImage: 32
			}, [
				32,
				32,
				64
			]), l = {
				width: e,
				height: t,
				noise: f,
				raw: r("SteadySplats visibility color", "rgba16float", u),
				samples: r("SteadySplats source ID and linear depth", "rg32uint", u),
				depth: r("SteadySplats visibility depth", "depth32float", GPUTextureUsage.RENDER_ATTACHMENT),
				weights: r("SteadySplats outward PDF ratios", "rgba32float", d),
				colors: [r("SteadySplats reconstruction A", "rgba16float", d), r("SteadySplats reconstruction B", "rgba16float", d)],
				stripes: n.stripes.map((t) => ({
					...t,
					params: i("SteadySplats frame parameters", 240, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST),
					history: i("SteadySplats four occluder FIFO", e * t.rows * 68, GPUBufferUsage.STORAGE),
					rest: i("SteadySplats stationary FP32 average", e * t.rows * 16, GPUBufferUsage.STORAGE)
				})),
				textures: s,
				buffers: c,
				release: a
			};
		} catch (e) {
			u = e;
		}
		let d = [
			o.popErrorScope(),
			o.popErrorScope(),
			o.popErrorScope()
		];
		try {
			u ??= (await Promise.all(d)).find((e) => e !== null);
		} catch (e) {
			u ??= e;
		}
		if (u || !l) {
			this.pipelines = void 0;
			try {
				await o.queue.onSubmittedWorkDone();
			} catch {} finally {
				for (let e of s) e.destroy();
				for (let e of c) e.destroy();
				a();
			}
			throw u ?? /* @__PURE__ */ Error("SteadySplats initialization failed.");
		}
		return l;
	}
	retire(e) {
		if (e.retirement) return e.retirement;
		let t = (async () => {
			try {
				await this.device.queue.onSubmittedWorkDone();
			} catch {} finally {
				for (let t of e.textures) t.destroy();
				for (let t of e.buffers) t.destroy();
				e.release();
			}
		})().finally(() => {
			this.retiring.delete(t);
		});
		return e.retirement = t, this.retiring.add(t), t;
	}
	async finish() {
		await this.preparation, await Promise.allSettled([...this.retiring]);
	}
	group(e, t, n) {
		return this.device.createBindGroup({
			layout: e.getBindGroupLayout(t),
			entries: n.map(([e, t]) => ({
				binding: e,
				resource: t
			}))
		});
	}
	encode(e, t, n, r, i) {
		let a = this.resources, o = this.pipelines, s = this.state.observe({
			scene: t,
			revision: t.revision,
			uniform: n,
			shade: r
		}, this.settings), c = new Float32Array(n.buffer, n.byteOffset, n.length), l = c.subarray(0, 16), u = c.subarray(16, 32), d = Oe(u, l);
		if (s.reconstruct) {
			let n = ke(u), i = ke(l);
			for (let e of a.stripes) {
				let t = /* @__PURE__ */ new Float32Array(60), o = new Uint32Array(t.buffer);
				t.set(n), t.set(i, 16), t.set(this.previousViewProjection ?? d, 32), o.set([
					s.sampleFrame,
					Number(s.valid),
					Number(s.still),
					s.restFrames
				], 48), t.set([
					a.width,
					a.height,
					this.settings.historyWeight,
					r
				], 52), o.set([
					e.start,
					e.rows,
					Math.imul(Math.floor(s.sampleFrame / 64), 2654435769) >>> 0,
					0
				], 56), this.device.queue.writeBuffer(e.params, 0, t);
			}
			let c = e.beginRenderPass({
				label: "SteadySplats unsorted visibility",
				colorAttachments: [a.raw, a.samples].map((e) => ({
					view: e.createView(),
					clearValue: [
						0,
						0,
						0,
						0
					],
					loadOp: "clear",
					storeOp: "store"
				})),
				depthStencilAttachment: {
					view: a.depth.createView(),
					depthClearValue: 1,
					depthLoadOp: "clear",
					depthStoreOp: "store"
				}
			});
			c.setPipeline(o.sample), c.setBindGroup(0, this.group(o.sample, 0, [
				[0, { buffer: this.frame }],
				[2, { buffer: t.buffers.states }],
				[7, { buffer: t.buffers.projected }]
			])), c.setBindGroup(1, this.group(o.sample, 1, [[0, { buffer: a.stripes[0].params }], [1, a.noise.createView()]])), c.draw(6, t.count), c.end();
			let f = e.beginComputePass({ label: "SteadySplats occluder history" });
			f.setPipeline(o.history), f.setBindGroup(0, this.group(o.history, 0, [[7, { buffer: t.buffers.projected }]]));
			for (let e of a.stripes) f.setBindGroup(1, this.group(o.history, 1, [
				[0, { buffer: e.params }],
				[3, a.samples.createView()],
				[5, a.weights.createView()],
				[8, { buffer: e.history }]
			])), f.dispatchWorkgroups(Math.ceil(a.width / 8), Math.ceil(e.rows / 8));
			f.end();
			let p = e.beginComputePass({ label: "SteadySplats spatial and temporal reconstruction" });
			p.setPipeline(o.resolve), p.setBindGroup(0, this.group(o.resolve, 0, []));
			for (let e of a.stripes) p.setBindGroup(1, this.group(o.resolve, 1, [
				[0, { buffer: e.params }],
				[2, a.raw.createView()],
				[3, a.samples.createView()],
				[4, a.weights.createView()],
				[6, a.colors[1 - this.writeIndex].createView()],
				[7, a.colors[this.writeIndex].createView()],
				[9, { buffer: e.rest }]
			])), p.dispatchWorkgroups(Math.ceil(a.width / 8), Math.ceil(e.rows / 8));
			p.end(), this.previousViewProjection = d, this.writeIndex = 1 - this.writeIndex;
		}
		let f = e.beginRenderPass({
			label: "SteadySplats reconstructed display",
			colorAttachments: [{
				view: i,
				clearValue: [
					r,
					r,
					r,
					1
				],
				loadOp: "clear",
				storeOp: "store"
			}]
		});
		return f.setPipeline(o.composite), f.setBindGroup(0, this.group(o.composite, 0, [])), f.setBindGroup(1, this.group(o.composite, 1, [[0, { buffer: a.stripes[0].params }], [6, a.colors[1 - this.writeIndex].createView()]])), f.draw(3), f.end(), s.needsMore;
	}
	dispose() {
		this.disposed || (this.disposed = !0, this.suspend(), this.generation++);
	}
}, q = class extends Error {}, Pe = "// Exact front-to-back pick candidates. Radius affects winner eligibility only.\n@group(0) @binding(0) var<uniform> frame: Frame;\n@group(0) @binding(1) var<storage, read> projected: array<Projected>;\n@group(0) @binding(2) var<storage, read> order: array<vec2<u32>>;\n@group(0) @binding(3) var<uniform> query: vec4<f32>;\n@group(0) @binding(4) var<storage, read_write> queryOutput: array<u32>;\n@group(0) @binding(5) var<storage, read_write> ranks: array<u32>;\n@group(0) @binding(6) var<storage, read_write> counts: array<u32>;\n@group(0) @binding(7) var<storage, read_write> candidates: array<u32>;\nvar<workgroup> prefix: array<u32,256>;\n\n@compute @workgroup_size(256)\nfn countCandidates(@builtin(global_invocation_id) thread:vec3<u32>, @builtin(local_invocation_index) lane:u32,\n  @builtin(workgroup_id) group:vec3<u32>) {\n  let i=thread.x; var accepted=false;\n  if(i<frame.flags.x) {\n    let g=projected[order[frame.flags.x-1u-i].y&0xffffffu];\n    if(g.center.w!=0.0) {\n      let center=vec2((g.center.x+1.0)*.5*frame.viewport.x,(1.0-g.center.y)*.5*frame.viewport.y);\n      let extent=abs(g.axes.xy)+abs(g.axes.zw);\n      let padding=(abs(center.x)+abs(center.y)+extent.x+extent.y+1.0)*.000004+.001;\n      // Invalid/extreme bounds conservatively retain the baseline candidate.\n      accepted=!all(abs(center)<vec2(1e30)) || !all(abs(extent)<vec2(1e30)) || all(abs(query.xy-center)<=extent+vec2(padding));\n    }\n  }\n  prefix[lane]=select(0u,1u,accepted); workgroupBarrier();\n  for(var step=1u;step<256u;step*=2u) {\n    let value=prefix[lane]; var previous=0u;\n    if(lane>=step) { previous=prefix[lane-step]; }\n    workgroupBarrier(); prefix[lane]=value+previous; workgroupBarrier();\n  }\n  if(i<frame.flags.x) { ranks[i]=select(0xffffffffu,prefix[lane]-1u,accepted); }\n  if(lane==255u) { counts[group.x+1u]=prefix[255]; }\n}\n@compute @workgroup_size(1)\nfn candidateOffsets() {\n  var total=0u;\n  for(var group=1u;group<=((frame.flags.x+255u)/256u);group++) {\n    let count=counts[group]; counts[group]=total; total+=count;\n  }\n  counts[0]=total;\n}\n@compute @workgroup_size(256)\nfn scatterCandidates(@builtin(global_invocation_id) thread:vec3<u32>) {\n  let i=thread.x; if(i>=frame.flags.x || ranks[i]==0xffffffffu) { return; }\n  candidates[counts[i/256u+1u]+ranks[i]]=order[frame.flags.x-1u-i].y;\n}\n// These frozen support thresholds and contribution operations match pick() in\n// splats.wgsl; the baseline remains an independent runtime comparison oracle.\nfn opacitySupport(opacity:f32)->f32 {\n  if(opacity>=.2141082512) { return 9.0; }\n  if(opacity>=.0289764008) {\n    if(opacity>=.0787660238) { return select(7.0,8.0,opacity>=.1298632188); }\n    return select(5.0,6.0,opacity>=.0477740084);\n  }\n  if(opacity>=.0106598221) { return select(3.0,4.0,opacity>=.0175750755); }\n  return select(1.0,2.0,opacity>=.0064655090);\n}\n@compute @workgroup_size(1)\nfn pickCandidates() {\n  var transmission=1.0; var strongest=0.0; var winner=0u; var depth=0.0; var opacity=0.0;\n  let minimum=select(0.0,1.0/255.0,query.z>0.0);\n  for(var i=0u;i<counts[0];i++) {\n    let entry=candidates[i]; let gaussian=projected[entry&0xffffffu];\n    let center=vec2((gaussian.center.x+1.0)*.5*frame.viewport.x,(1.0-gaussian.center.y)*.5*frame.viewport.y);\n    let delta=vec2(query.x-center.x,center.y-query.y);\n    let local=3.0*vec2(dot(delta,gaussian.axes.xy)/dot(gaussian.axes.xy,gaussian.axes.xy),dot(delta,gaussian.axes.zw)/dot(gaussian.axes.zw,gaussian.axes.zw));\n    let r=dot(local,local); if(r>min(9.0,opacitySupport(gaussian.color.a)+.001)) { continue; }\n    let alpha=min(.99,gaussian.color.a*exp(-.5*r)); if(alpha<1.0/255.0) { continue; }\n    let weight=transmission*alpha;\n    let eligible=query.z<=0.0 || dot(query.xy-center,query.xy-center)<=query.z*query.z;\n    if(eligible && weight>=minimum && weight>strongest) { strongest=weight; winner=(entry&0xffffffu)+1u; }\n    depth+=weight*gaussian.center.z; opacity+=weight; transmission*=1.0-alpha;\n    if(transmission<1e-5) { break; }\n  }\n  queryOutput[0]=winner; queryOutput[1]=bitcast<u32>(depth/max(opacity,1e-20));\n  queryOutput[2]=bitcast<u32>(opacity); queryOutput[3]=bitcast<u32>(strongest);\n}\n", Fe = [
	"countCandidates",
	"candidateOffsets",
	"scatterCandidates",
	"pickCandidates"
], Ie = /* @__PURE__ */ new WeakMap();
async function Le(e) {
	let t = Ie.get(e);
	t || (t = e.checkedAllocation(() => {
		let t = e.device.createShaderModule({
			label: "Exact compact pick",
			code: p + Pe
		}), n = Promise.all(Fe.map(async (n) => [n, await e.device.createComputePipelineAsync({
			label: `Pick ${n}`,
			layout: "auto",
			compute: {
				module: t,
				entryPoint: n
			}
		})]));
		return n.catch(() => void 0), { task: n };
	}, async (e) => {
		await e.task.catch(() => void 0);
	}).then(async (e) => Object.fromEntries(await e.task)), Ie.set(e, t));
	try {
		let n = await t;
		return e.requireScene(), n;
	} catch (n) {
		throw Ie.get(e) === t && Ie.delete(e), n;
	}
}
async function Re(e, t) {
	if (t.count < 2048 || !e.admitWork) return;
	let n, r = Math.ceil(t.count / 256), i = [];
	try {
		n = e.admitWork(t.count * 8 + (r + 1) * 4);
		let a = await Le(e), o = await e.checkedAllocation(() => {
			for (let n of [
				t.count * 4,
				(r + 1) * 4,
				t.count * 4
			]) i.push(e.device.createBuffer({
				size: n,
				usage: GPUBufferUsage.STORAGE
			}));
			let [n, o, s] = i, c = {
				countCandidates: [
					[0, e.frame],
					[1, t.buffers.projected],
					[2, t.ordered],
					[3, e.query],
					[5, n],
					[6, o]
				],
				candidateOffsets: [[0, e.frame], [6, o]],
				scatterCandidates: [
					[0, e.frame],
					[2, t.ordered],
					[5, n],
					[6, o],
					[7, s]
				],
				pickCandidates: [
					[0, e.frame],
					[1, t.buffers.projected],
					[3, e.query],
					[4, e.queryOutput],
					[6, o],
					[7, s]
				]
			};
			return Fe.map((t) => ({
				name: t,
				pipeline: a[t],
				group: e.bind(a[t], c[t])
			}));
		}, () => {
			for (let e of i) e.destroy();
		}), s = !1;
		return {
			encode(e) {
				for (let t of o) {
					let n = e.beginComputePass({ label: `Pick ${t.name}` });
					n.setPipeline(t.pipeline), n.setBindGroup(0, t.group), n.dispatchWorkgroups(t.name === "candidateOffsets" || t.name === "pickCandidates" ? 1 : r), n.end();
				}
			},
			dispose() {
				if (!s) {
					s = !0;
					for (let e of i) e.destroy();
					n?.();
				}
			}
		};
	} catch {
		for (let e of i) e.destroy();
		n?.();
		return;
	}
}
var ze = 262144, Be = Object.freeze({
	colors: 1,
	visible: 2,
	downsampled: 4,
	region: 8
}), Ve = class extends g {
	required;
	capacity;
	constructor(e, t) {
		super(`A surface tile needs ${e} candidates, exceeding the explicit query limit of ${t}.`), this.required = e, this.capacity = t;
	}
};
function He(e, t) {
	if (!Number.isSafeInteger(e) || !Number.isSafeInteger(t) || e < 1 || t < 1) throw new g("Invalid surface viewport dimensions.");
	let n = y(e, t), r = Math.min(1, Math.sqrt(ze / n));
	return {
		width: Math.max(1, Math.floor(e * r)),
		height: Math.max(1, Math.floor(t * r)),
		scale: r
	};
}
function Ue(e, t, n) {
	let r = e.colors || e.visible ? void 0 : e.region;
	if (!r) return;
	let { x: i, y: a, width: o, height: s } = r;
	if (![
		i,
		a,
		o,
		s
	].every(Number.isSafeInteger) || Math.min(i, a, o, s) < 0 || i + o > t || a + s > n) throw new g("Invalid surface query coverage.");
	if (!(t > 65535 || n > 65535 || i === 0 && a === 0 && o === t && s === n)) return Object.freeze({
		x: i,
		y: a,
		width: o,
		height: s
	});
}
function We(e, t) {
	return (e.colors ? Be.colors : 0) | (e.visible ? Be.visible : 0) | (t ? Be.downsampled : 0);
}
var J = {
	fullWidth: 0,
	fullHeight: 1,
	width: 2,
	height: 3,
	tilesX: 4,
	tilesY: 5,
	coverageMinPacked: 6,
	sourceCount: 7,
	channels: 8,
	dispatchWidth: 9,
	scale: 10,
	coverageMaxPacked: 11
};
function Ge(e) {
	let t = new Uint32Array(48 / Uint32Array.BYTES_PER_ELEMENT);
	if (t[J.fullWidth] = e.fullWidth, t[J.fullHeight] = e.fullHeight, t[J.width] = e.width, t[J.height] = e.height, t[J.tilesX] = Math.ceil(e.width / 16), t[J.tilesY] = Math.ceil(e.height / 16), t[J.sourceCount] = e.sourceCount, t[J.channels] = e.channelFlags | (e.region ? Be.region : 0), t[J.dispatchWidth] = e.dispatchWidth, new Float32Array(t.buffer)[J.scale] = e.scale, e.region) {
		let { x: n, y: r, width: i, height: a } = e.region;
		t[J.coverageMinPacked] = (n | r << 16) >>> 0, t[J.coverageMaxPacked] = (n + i | r + a << 16) >>> 0;
	}
	return t;
}
//#endregion
//#region src/renderer/webgpu/surfaceBuffers.ts
function Ke(e) {
	let { width: t, height: n, sourceCount: r, downsampled: i, colors: a, visible: o, region: s } = e;
	if (!Number.isSafeInteger(t) || !Number.isSafeInteger(n) || t < 1 || n < 1) throw new g("Invalid surface viewport dimensions.");
	y(r, 1);
	let c = y(t, n), l = Math.ceil(t / 16), u = Math.ceil(n / 16), d = y(l, u), f = y(d, 4), p = y(d, 8), m = y(c, 8), h = s ? Math.max(4, y(y(s.width, s.height), 8)) : m, _ = a || o ? y(r, 16) : 16, v = i ? y(r, 48) : a || o ? 48 : 0, b = a ? y(c, 16) : 16, x = o ? y(Math.ceil(r / 32), 4) : 0, S = y(y(c, a ? 20 : 8) + x, 1);
	return {
		pixels: c,
		tilesX: l,
		tilesY: u,
		tileCount: d,
		countBytes: f,
		layoutBytes: p,
		outputBytes: m,
		readbackBytes: h,
		auxiliaryBytes: _,
		projectionBytes: v,
		colorBytes: b,
		visibilityBytes: x,
		hostScratchBytes: y(f + y(p, 2) + y(48, 2), 1),
		physicalScratchBytes: y(y(f, 2) + p + m + h + _ + v + y(b, a ? 2 : 1) + y(x, 2) + 48, 1),
		retainedCpuBytes: S
	};
}
//#endregion
//#region src/renderer/webgpu/surfaceLayout.ts
function qe(e, t, n) {
	if (y(t, 1), !Number.isSafeInteger(e.length) || e.length < 0 || e.length > 4294967295) throw new g("Invalid surface tile count.");
	if (n !== void 0 && (!Number.isSafeInteger(n) || n < 1)) throw new g("Invalid surface tile ceiling.");
	let r = y(e.length, 8), i = 0, a = 0, o = 0, s = 0, c = (e) => {
		if (!Number.isSafeInteger(e) || e < 0 || e > 4294967295) throw new g("Invalid surface tile candidate count.");
		if (n !== void 0 && e > n) throw new g("The surface tile exceeds its explicit candidate ceiling.");
		return e ? 2 ** Math.ceil(Math.log2(e)) : 0;
	};
	for (let n = 0; n < e.length; n++) {
		let r = c(e[n]);
		if (i += r, i > 4294967295) throw new g("The compact surface candidate indices exceed the graphics address limit.");
		if (Math.max(4, y(i, 4)) > t) throw new g("The compact surface candidates exceed the graphics device buffer limit.");
		a = Math.max(a, r), r && o++;
		let l = r > 1 ? Math.log2(r) : 0;
		s += r / 2 * l * (l + 1) / 2;
	}
	let l = Math.max(4, y(i, 4));
	if (l > t) throw new g("The compact surface candidates exceed the graphics device buffer limit.");
	let u = new Uint32Array(r / 4), d = 0;
	for (let t = 0; t < e.length; t++) {
		let n = c(e[t]);
		u[t * 2] = d, u[t * 2 + 1] = n, d += n;
	}
	return {
		spans: u,
		candidateEntries: i,
		candidateBytes: l,
		tileCapacity: a,
		tileCount: e.length,
		occupiedTiles: o,
		sortComparisons: s
	};
}
//#endregion
//#region src/renderer/webgpu/surface.ts
function Je(e) {
	if (!Number.isInteger(e) || e < 1 || e > 65536 || e & e - 1) throw new g("Surface tile capacity must be a power of two between 1 and 65536.");
	return e;
}
async function Ye(e, t, n) {
	let r = performance.now(), i = {
		pipelineMs: 0,
		countMs: 0,
		planMs: 0,
		allocationMs: 0,
		compositeReadbackMs: 0,
		copyMs: 0,
		retireMs: 0,
		totalMs: 0,
		readbackBytes: 0,
		reusedBuffers: 0,
		createdBuffers: 0
	}, a = e.surfaceSnapshot(t), o = () => {
		n.signal?.throwIfAborted(), a();
	}, s = e.canvas.width, c = e.canvas.height;
	if (s > e.device.limits.maxTextureDimension2D || c > e.device.limits.maxTextureDimension2D) throw new g("The surface viewport exceeds the graphics device texture limit.");
	let { width: l, height: u, scale: d } = He(s, c), f = Ue(n, l, u), p = l !== s || u !== c, m = We(n, p), { pixels: h, tilesX: _, tilesY: v, countBytes: b, layoutBytes: x, outputBytes: S, readbackBytes: C, auxiliaryBytes: w, projectionBytes: T, colorBytes: E, visibilityBytes: D, hostScratchBytes: O, physicalScratchBytes: k, retainedCpuBytes: A } = Ke({
		width: l,
		height: u,
		sourceCount: t.count,
		downsampled: p,
		colors: n.colors,
		visible: n.visible,
		region: f
	});
	i.readbackBytes = C;
	let j = Math.min(t.count, e.device.limits.maxComputeWorkgroupsPerDimension), ee = Math.ceil(t.count / j);
	if (ee > e.device.limits.maxComputeWorkgroupsPerDimension || y(s, c) > 4294967295) throw new g("The full-resolution visibility query exceeds the graphics device dispatch limit.");
	let te = n.initialTileCapacity === void 0 ? void 0 : Je(n.initialTileCapacity), M = n.maxTileCapacity === void 0 ? void 0 : Je(n.maxTileCapacity);
	if (te !== void 0 && M !== void 0 && te > M) throw new g("Initial surface tile capacity exceeds its explicit query limit.");
	let ne = Math.min(e.device.limits.maxBufferSize, e.device.limits.maxStorageBufferBindingSize);
	for (let e of [
		b,
		x,
		S,
		w,
		T,
		E,
		D
	]) if (e > ne) throw new g("The surface map exceeds the graphics device buffer limit.");
	let N = n.reuseBuffers === !0, re = N ? O : y(O + k, 1), P;
	try {
		P = n.admit(y(A + re, 1));
	} catch (t) {
		if (!N || !(t instanceof g)) throw t;
		e.trimSurfaceResources(), P = n.admit(y(A + re, 1));
	}
	let F = [], I = /* @__PURE__ */ new Map(), L = /* @__PURE__ */ new Set(), R = (r, a, o) => {
		if (N) {
			let s = e.surfaceScratch.acquire(n.poolOwner ?? t, r, a, o | (o & GPUBufferUsage.STORAGE ? GPUBufferUsage.COPY_DST : 0), n.admit);
			return F.push(s.buffer), I.set(s.buffer, s), s.reused ? (L.add(s.buffer), i.reusedBuffers++) : i.createdBuffers++, s.buffer;
		}
		let s = e.device.createBuffer({
			label: r,
			size: a,
			usage: o
		});
		return F.push(s), s;
	}, z = !1, ie = !1, B = !1, V = async () => {
		if (z) try {
			await e.device.queue.onSubmittedWorkDone();
		} catch {}
		z = !1;
		for (let e of F) {
			let t = I.get(e);
			t ? t.release(B) : e.destroy();
		}
		F.length = 0, I.clear();
	};
	try {
		o();
		let a = performance.now(), g = await ye(e, { visible: n.visible });
		o(), i.pipelineMs = performance.now() - a, a = performance.now();
		let O = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC, k = await e.checkedAllocation(() => {
			let n = R("Surface dimensions and capacity", 48, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST), r = R("Surface tile counts", b, O | GPUBufferUsage.COPY_DST), i = R("Surface capacity readback", b, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ), a = R("Surface raw color and covariance margin", w, O), o = T ? R("Surface native bounded-map projection", T, O) : void 0, h = p ? o : t.buffers.projected;
			z = !0;
			let _ = Ge({
				fullWidth: s,
				fullHeight: c,
				width: l,
				height: u,
				sourceCount: t.count,
				channelFlags: m,
				dispatchWidth: j,
				scale: d,
				region: f
			});
			return e.device.queue.writeBuffer(n, 0, _), {
				params: n,
				counts: r,
				statRead: i,
				auxiliary: a,
				projected: h,
				bin: e.bind(g.bin, [
					[0, n],
					[1, h],
					[2, t.ordered],
					[3, r]
				]),
				prepare: m ? e.bind(g.prepareAuxiliary, [
					[0, n],
					[7, e.frame],
					[8, t.buffers.splats],
					[9, t.buffers.states],
					[10, a],
					[13, o],
					[14, t.previewMask("transformBase")],
					[15, t.previewMask("opacityBase")]
				]) : void 0
			};
		}, V);
		o(), await e.checkedAllocation(() => {
			let n = e.device.createCommandEncoder({ label: "Surface compact candidate counting" });
			L.has(k.counts) && n.clearBuffer(k.counts);
			let r = n.beginComputePass();
			k.prepare && (r.setPipeline(g.prepareAuxiliary), r.setBindGroup(0, k.prepare), r.dispatchWorkgroups(Math.ceil(t.count / 256))), r.setPipeline(g.bin), r.setBindGroup(0, k.bin), r.dispatchWorkgroups(Math.ceil(t.count / 256)), r.end(), n.copyBufferToBuffer(k.counts, 0, k.statRead, 0, b), e.device.queue.submit([n.finish()]), z = !0;
		}, () => void 0), o(), await k.statRead.mapAsync(GPUMapMode.READ), o(), i.countMs = performance.now() - a, a = performance.now();
		let te = new Uint32Array(k.statRead.getMappedRange());
		if (M !== void 0) {
			let e = 0;
			for (let t of te) e = Math.max(e, t);
			if (e > M) throw new Ve(e, M);
		}
		let F = qe(te, ne);
		k.statRead.unmap(), await e.device.queue.onSubmittedWorkDone(), z = !1, o(), i.planMs = performance.now() - a, a = performance.now(), N || P.resize(y(A + re + F.candidateBytes, 1));
		let I = await e.checkedAllocation(() => {
			let r = R("Surface tile global ranks", F.candidateBytes, O), i = R("Surface compact tile spans", x, O | GPUBufferUsage.COPY_DST), a = R("Surface FP32 depth and opacity", S, O), o = R("Surface depth and opacity readback", C, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ), s = R("Surface raw RGB", E, O), c = n.colors ? R("Surface raw RGB readback", E, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ) : void 0, l = n.visible ? R("Surface full-frame visibility bits", D, O) : void 0, u = n.visible ? R("Surface visibility readback", D, GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ) : void 0;
			return z = !0, e.device.queue.writeBuffer(i, 0, F.spans), {
				output: a,
				mapRead: o,
				colorOutput: s,
				colorRead: c,
				bits: l,
				bitRead: u,
				candidates: r,
				scatter: e.bind(g.scatter, [
					[0, k.params],
					[1, k.projected],
					[2, t.ordered],
					[3, k.counts],
					[4, r],
					[5, i]
				]),
				sort: e.bind(g.sortTile, [
					[0, k.params],
					[4, r],
					[5, i]
				]),
				composite: e.bind(g.composite, [
					[0, k.params],
					[1, k.projected],
					[2, t.ordered],
					[3, k.counts],
					[4, r],
					[5, i],
					[6, a],
					[10, k.auxiliary],
					[12, s]
				]),
				visibility: l ? e.bind(g.markVisible, [
					[0, k.params],
					[1, t.buffers.projected],
					[6, a],
					[10, k.auxiliary],
					[11, l]
				]) : void 0
			};
		}, V);
		o(), i.allocationMs = performance.now() - a, a = performance.now(), await e.checkedAllocation(() => {
			let n = e.device.createCommandEncoder({ label: "FP32 native compact composited surface" });
			n.clearBuffer(k.counts), L.has(I.candidates) && n.clearBuffer(I.candidates), f && L.has(I.output) && n.clearBuffer(I.output), I.bits && L.has(I.bits) && n.clearBuffer(I.bits);
			let r = n.beginComputePass();
			r.setPipeline(g.scatter), r.setBindGroup(0, I.scatter), r.dispatchWorkgroups(Math.ceil(t.count / 256)), r.end();
			let i = n.beginComputePass();
			i.setPipeline(g.sortTile), i.setBindGroup(0, I.sort), i.dispatchWorkgroups(_, v), i.end();
			let a = n.beginComputePass();
			if (a.setPipeline(g.composite), a.setBindGroup(0, I.composite), a.dispatchWorkgroups(_, v), a.end(), I.visibility) {
				let e = n.beginComputePass({ label: "Full framebuffer contributing-layer visibility" });
				e.setPipeline(g.markVisible), e.setBindGroup(0, I.visibility), e.dispatchWorkgroups(j, ee), e.end();
			}
			if (!f) n.copyBufferToBuffer(I.output, 0, I.mapRead, 0, S);
			else if (f.width && f.height) {
				if (f.width === l) n.copyBufferToBuffer(I.output, f.y * l * 8, I.mapRead, 0, C);
				else for (let e = 0; e < f.height; e++) n.copyBufferToBuffer(I.output, ((f.y + e) * l + f.x) * 8, I.mapRead, e * f.width * 8, f.width * 8);
			}
			I.colorRead && n.copyBufferToBuffer(I.colorOutput, 0, I.colorRead, 0, E), I.bitRead && n.copyBufferToBuffer(I.bits, 0, I.bitRead, 0, D), e.device.queue.submit([n.finish()]), z = !0;
		}, () => void 0), o(), await Promise.all([
			I.mapRead,
			I.colorRead,
			I.bitRead
		].filter((e) => !!e).map((e) => e.mapAsync(GPUMapMode.READ))), o(), i.compositeReadbackMs = performance.now() - a, a = performance.now();
		let H = new Float32Array(I.mapRead.getMappedRange()), ae = new Float32Array(h), oe = new Float32Array(h);
		if (f) for (let e = 0; e < f.height; e++) for (let t = 0; t < f.width; t++) {
			let n = (e * f.width + t) * 2, r = (f.y + e) * l + f.x + t;
			ae[r] = H[n], oe[r] = H[n + 1];
		}
		else for (let e = 0; e < h; e++) ae[e] = H[e * 2], oe[e] = H[e * 2 + 1];
		I.mapRead.unmap();
		let U, se;
		if (I.colorRead) {
			let e = new Float32Array(I.colorRead.getMappedRange());
			U = new Float32Array(h * 3);
			for (let t = 0; t < h; t++) U[t * 3] = e[t * 4], U[t * 3 + 1] = e[t * 4 + 1], U[t * 3 + 2] = e[t * 4 + 2];
			I.colorRead.unmap();
		}
		I.bitRead && (se = new Uint32Array(I.bitRead.getMappedRange()).slice(), I.bitRead.unmap()), i.copyMs = performance.now() - a, a = performance.now(), B = !0, await V(), o(), i.retireMs = performance.now() - a, i.totalMs = performance.now() - r, P.resize(A);
		let ce = !1;
		return ie = !0, {
			width: l,
			height: u,
			fullWidth: s,
			fullHeight: c,
			depths: ae,
			opacities: oe,
			colors: U,
			visible: se,
			region: f,
			profile: i,
			deviceEpoch: e.deviceEpoch,
			attempts: 1,
			tileCapacity: F.tileCapacity,
			allocationBytes: A,
			candidateBytes: F.candidateBytes,
			candidateEntries: F.candidateEntries,
			tileCount: F.tileCount,
			occupiedTiles: F.occupiedTiles,
			sortComparisons: F.sortComparisons,
			assertCurrent: () => {
				if (ce) throw Error("The surface map was released.");
				o();
			},
			dispose: () => {
				ce || (ce = !0, P());
			}
		};
	} finally {
		(z || F.length) && await V(), ie || (N && e.trimSurfaceResources(n.poolOwner ?? t), P());
	}
}
function Xe(e, t, n, r, i, a, o, s, c = a, l = 1, u = !1) {
	if (!Number.isFinite(l) || l < 0 || l > 5) throw RangeError("Opacity scale must be between 0 and 5.");
	l = Math.fround(l), u = l !== 1 && u;
	let d = /* @__PURE__ */ new Float32Array(80), f = new Uint32Array(d.buffer), p = i.some((e, t) => e !== R[t]), m = p && c;
	return d.set(t.view), d.set(t.projection, 16), d.set(t.eye, 32), d[35] = e.degree, d.set([
		o,
		s,
		o * t.projection[0] * .5,
		s * t.projection[5] * .5
	], 36), f.set([
		e.count,
		e.stride / 4,
		Number(n.some((e, t) => e !== L[t])),
		Number(a)
	], 40), d.set(n, 44), d[59] = l, d.set(i, 60), f.set([
		Number(p),
		Number(m),
		r ? e.duplicateSelectionGuarded ? 2 : 1 : 0,
		l === 1 ? 0 : 1 | (u ? 2 : 0)
	], 76), {
		values: d,
		words: f,
		geometryKey: i.join(",") + ":" + m
	};
}
//#endregion
//#region src/input/background.ts
function Ze(e) {
	return e === "white" ? 1 : e === "gray" ? .5 : 0;
}
//#endregion
//#region src/renderer/webgpu/renderer.ts
var Qe = [
	"colorBase",
	"transformBase",
	"opacityBase"
], Y = class extends q {}, $e = /* @__PURE__ */ new WeakMap(), et = class {
	renderer;
	count;
	degree;
	kind = "gaussian";
	stride;
	buffers;
	params = [];
	sortStages = [];
	projectGroup;
	drawGroup;
	pickGroup;
	ordered;
	lastCameraRevision = -1;
	residentOrder;
	residentSortPrecision = 32;
	residentCompactOrder;
	fastOrder;
	residentProjection;
	sortDirty = !0;
	lastGeometry = "";
	uploadBytes = 0;
	retired = !1;
	revision = 0;
	sourceRevision = 0;
	selectedRevision = 0;
	stateBytes;
	duplicateRange = null;
	duplicateSelected = !1;
	get duplicateSelectionGuarded() {
		return this.duplicateSelected;
	}
	setDuplicateRange(e) {
		let t = he(e, this.count);
		ge(this.duplicateRange, t) || (this.duplicateRange = t, this.duplicateSelected = this.exactDuplicateSelection(this.stateBytes));
	}
	exactDuplicateSelection(e) {
		let t = this.duplicateRange;
		if (!t) return !1;
		let n = 0, r = 0;
		for (let i = 0; i < e.length; i++) e[i] === 1 && (n++, i >= t.first && r++);
		return n === t.count && r === t.count;
	}
	previewBuffers = {};
	previewRevisions = {
		colorBase: 0,
		transformBase: 0,
		opacityBase: 0
	};
	maskBindingRevision = 0;
	get deviceEpoch() {
		return this.renderer.deviceEpoch;
	}
	constructor(e, t, n) {
		this.renderer = e, this.count = t, this.degree = n, this.stride = b(n);
		let r = y(t, this.stride);
		if (!t || t > 3e6) throw Error("This scene exceeds the current loaded-splat limit.");
		if (r > e.device.limits.maxStorageBufferBindingSize || r > e.device.limits.maxBufferSize) throw Error("This scene exceeds the graphics device limit. Load fewer splats.");
		let i = e.device, a = [];
		this.stateBytes = new Uint8Array(t);
		let o = (e, t) => {
			let n = i.createBuffer({
				label: e,
				size: Math.max(4, t),
				usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
			});
			return a.push(n), n;
		}, s = Math.ceil(t / 256), c = Math.ceil(s / 256);
		try {
			this.buffers = {
				splats: o("Packed native covariance and SH", r),
				states: o("Source ID states", t * 4),
				projected: o("Projected Gaussians", t * 48),
				pairsA: o("Radix A", t * 8),
				pairsB: o("Radix B", t * 8),
				ranks: o("Local radix rank", t * 4),
				counts: o("Radix group counts", s * 16 * 4),
				groupOffsets: o("Group offsets", s * 16 * 4),
				groupSums: o("Group sums", c * 16 * 4),
				blockOffsets: o("Block offsets", c * 16 * 4),
				binTotals: o("Bin totals", 64),
				binOffsets: o("Bin offsets", 64)
			};
			let n = this.buffers, a = e.pipelines;
			for (let e = 0; e < 32; e += 4) {
				let n = i.createBuffer({
					label: `Radix ${e}`,
					size: 16,
					usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
				});
				i.queue.writeBuffer(n, 0, new Uint32Array([
					t,
					s,
					c,
					e
				])), this.params.push(n);
			}
			let l = (t, n) => e.bind(t, n);
			this.sortStages.push({
				pipeline: a.generate,
				group: l(a.generate, [
					[0, this.params[0]],
					[3, n.pairsA],
					[8, n.splats],
					[9, n.states],
					[10, e.frame],
					[11, n.states]
				]),
				x: s
			});
			let u = n.pairsA, d = n.pairsB;
			for (let e of this.params) this.sortStages.push({
				pipeline: a.rank,
				group: l(a.rank, [
					[0, e],
					[1, u],
					[2, n.ranks],
					[4, n.counts]
				]),
				x: s
			}, {
				pipeline: a.local,
				group: l(a.local, [
					[0, e],
					[1, n.counts],
					[2, n.groupOffsets],
					[3, n.groupSums]
				]),
				x: c,
				y: 16
			}, {
				pipeline: a.blocks,
				group: l(a.blocks, [
					[0, e],
					[1, n.groupSums],
					[2, n.blockOffsets],
					[3, n.binTotals]
				]),
				x: 16
			}, {
				pipeline: a.bins,
				group: l(a.bins, [[1, n.binTotals], [2, n.binOffsets]]),
				x: 1
			}, {
				pipeline: a.scatter,
				group: l(a.scatter, [
					[0, e],
					[1, u],
					[2, n.ranks],
					[3, d],
					[5, n.groupOffsets],
					[6, n.blockOffsets],
					[7, n.binOffsets]
				]),
				x: s
			}), [u, d] = [d, u];
			this.ordered = u, this.projectGroup = l(a.project, [
				[0, e.frame],
				[1, n.splats],
				[2, n.states],
				[3, n.projected],
				[8, n.states],
				[9, n.states],
				[10, n.states]
			]), this.drawGroup = l(e.raster, [
				[0, e.frame],
				[4, u],
				[7, n.projected]
			]), this.pickGroup = l(a.pick, [
				[0, e.frame],
				[4, u],
				[5, e.query],
				[6, e.queryOutput],
				[7, n.projected]
			]);
		} catch (e) {
			for (let e of a) e.destroy();
			for (let e of this.params) e.destroy();
			throw e;
		}
	}
	get allocationBytes() {
		return this.stateBytes.byteLength + [
			...Object.values(this.buffers),
			...this.params,
			...Object.values(this.previewBuffers)
		].reduce((e, t) => e + t.size, 0);
	}
	previewMask(e) {
		return this.previewBuffers[e] ?? this.buffers.states;
	}
	hasPreviewMask(e) {
		return this.previewBuffers[e] !== void 0;
	}
	previewMaskRevision(e) {
		return this.previewRevisions[e];
	}
	async upload(e, t, n) {
		if (n.byteLength !== t * this.stride || e + t > this.count) throw Error("Invalid scene upload.");
		this.revision++, this.sourceRevision++, this.sortDirty = !0, this.renderer.device.queue.writeBuffer(this.buffers.splats, e * this.stride, n), this.uploadBytes += n.byteLength, this.uploadBytes >= 16777216 && (await this.renderer.device.queue.onSubmittedWorkDone(), this.uploadBytes = 0), this.sortDirty = !0;
	}
	masks(e) {
		let t = this.maskBytes(e), n = Uint32Array.from(t);
		this.publishStateRevision(t), this.maskBindingRevision++, this.revision++, this.renderer.device.queue.writeBuffer(this.buffers.states, 0, n), this.sortDirty = !0;
	}
	maskBytes(e, t = !0) {
		if (e.byteLength !== this.count) throw Error("Invalid scene state mask.");
		let n = new Uint8Array(e);
		if (n.some((e) => e > 3)) throw Error("Invalid scene state mask.");
		return t ? n.slice() : n;
	}
	publishStateRevision(e) {
		let t = !1, n = !1, r = 0, i = 0;
		for (let a = 0; a < e.length; a++) {
			let o = e[a] ^ this.stateBytes[a];
			t ||= !!(o & 2), n ||= !!(o & 1), this.duplicateRange && e[a] === 1 && (r++, a >= this.duplicateRange.first && i++);
		}
		t && this.sourceRevision++, n && this.selectedRevision++, this.stateBytes = e, this.duplicateSelected = !!this.duplicateRange && r === this.duplicateRange.count && i === this.duplicateRange.count;
	}
	async stageMasks(e, t = {}) {
		return this.stageStateBindings(e, t);
	}
	async stagePreviewMasks(e, t) {
		if (!Qe.includes(t)) throw Error("Invalid preview mask channel.");
		return this.stageStateBindings(void 0, { [t]: e });
	}
	async stageStateBindings(e, t) {
		if (this.retired) throw new Y("The scene was retired before staging its masks.");
		let n = e === void 0 ? void 0 : this.maskBytes(e), r = Object.keys(t);
		if (r.some((e) => !Qe.includes(e) || t[e] === void 0)) throw Error("Invalid preview mask channel.");
		for (let e of r) t[e] !== null && this.maskBytes(t[e], !1);
		let i = this.maskBindingRevision, a = this.renderer.device, o = [], s = !1, c = !1, l = !1, u, d = () => {
			if (!s) return c = !0, u ??= (async () => {
				if (l) try {
					await a.queue.onSubmittedWorkDone();
				} catch {}
				for (let e of o) e.destroy();
			})();
		};
		try {
			return await this.renderer.checkedAllocation(() => {
				let e = this.buffers, u = this.renderer.pipelines, f = (e, t) => {
					let n = a.createBuffer({
						label: e,
						size: this.count * 4,
						usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
					});
					return o.push(n), l = !0, a.queue.writeBuffer(n, 0, Uint32Array.from(t)), n;
				}, p = n ? f("Candidate source states", n) : e.states, m = { ...this.previewBuffers }, h = n ? [e.states] : [];
				for (let e of r) {
					let n = m[e];
					n && h.push(n);
					let r = t[e];
					r === null ? delete m[e] : m[e] = f(`Candidate ${e} targets`, this.maskBytes(r, !1));
				}
				let g = (e) => m[e] ?? p, _ = this.renderer.bind(u.project, [
					[0, this.renderer.frame],
					[1, e.splats],
					[2, p],
					[3, e.projected],
					[8, g("colorBase")],
					[9, g("transformBase")],
					[10, g("opacityBase")]
				]), v = this.renderer.bind(u.generate, [
					[0, this.params[0]],
					[3, e.pairsA],
					[8, e.splats],
					[9, p],
					[10, this.renderer.frame],
					[11, g("transformBase")]
				]), y = {
					...this.sortStages[0],
					group: v
				};
				return {
					allocationBytes: o.reduce((e, t) => e + t.size, n?.byteLength ?? 0),
					retirementBytes: h.reduce((e, t) => e + t.size, n ? this.stateBytes.byteLength : 0),
					retirementBuffers: h,
					publish: () => {
						if (s || c || this.retired || i !== this.maskBindingRevision) throw new Y("The scene masks changed before the candidate was published.");
						e.states = p, this.projectGroup = _, this.sortStages[0] = y, n && this.publishStateRevision(n);
						for (let e of r) this.previewRevisions[e]++, m[e] ? this.previewBuffers[e] = m[e] : delete this.previewBuffers[e];
						return this.maskBindingRevision++, this.revision++, (n || r.includes("transformBase")) && (this.sortDirty = !0), s = !0, h[0];
					},
					dispose: d
				};
			}, (e) => e.dispose());
		} catch (e) {
			throw await d(), e;
		}
	}
	async dispose() {
		if (!this.retired) {
			this.retired = !0, this.renderer.trimSurfaceResources?.();
			try {
				await this.renderer.finish();
			} catch {}
			this.fastOrder?.dispose(), this.fastOrder = void 0;
			for (let e of Object.values(this.buffers)) e.destroy();
			for (let e of Object.values(this.previewBuffers)) e.destroy();
			for (let e of Qe) delete this.previewBuffers[e];
			for (let e of this.params) e.destroy();
			this.stateBytes = /* @__PURE__ */ new Uint8Array();
		}
	}
}, tt = class e {
	canvas;
	device;
	format;
	pipelines;
	raster;
	geometryPoints;
	geometryMesh;
	negotiation;
	backend = "webgpu";
	admitSortScratch;
	admitWork;
	deviceEpoch = n();
	surfaceScratch;
	frame;
	query;
	queryOutput;
	quadIndices;
	displayCheckpoint;
	context;
	queryQueue = Promise.resolve();
	scenePreparations = /* @__PURE__ */ new Set();
	disposed = !1;
	frameRevision = 0;
	opacityScale = 1;
	opacitySelectedOnly = !1;
	opacityRevision = 0;
	preparedOpacityRevision = 0;
	preparedScene;
	preparedSceneRevision = -1;
	preparedWidth = 0;
	preparedHeight = 0;
	preparedUniform;
	preparedCameraRevision = -1;
	geometryDepth;
	geometryDepthAllocations = /* @__PURE__ */ new Set();
	retiringGeometryDepth = /* @__PURE__ */ new Set();
	geometryScenes = /* @__PURE__ */ new Set();
	geometryTargetGeneration = 0;
	geometryTargetPreparation;
	geometryTargetTasks = /* @__PURE__ */ new Set();
	geometryTargetFailure;
	histogram;
	steady;
	histogramDisplay;
	admitGeometryDepth;
	admitHistogram;
	admitSteady;
	onRenderStatus;
	onHistogram;
	onHistogramUnavailable;
	onFrameNeeded;
	frames = 0;
	submittedDisplayFrames = 0;
	get frameSubmissionSequence() {
		return this.submittedDisplayFrames;
	}
	get negotiationSnapshot() {
		return this.negotiation.snapshot;
	}
	lost = !1;
	onLost;
	onDeviceLost;
	constructor(e, t, n, r, a, o, s, c) {
		if (this.canvas = e, this.device = t, this.format = n, this.pipelines = r, this.raster = a, this.geometryPoints = o, this.geometryMesh = s, this.negotiation = c, this.context = e.getContext("webgpu"), !this.context) throw Error("The WebGPU presentation context is unavailable.");
		i(e, "webgpu"), this.context.configure({
			device: t,
			format: n,
			alphaMode: "opaque",
			usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING
		}), this.surfaceScratch = new xe(t), this.histogram = new I(t, this.deviceEpoch, {
			admit: (e) => this.admitHistogram?.(e),
			invalidate: () => this.onFrameNeeded?.(),
			publish: (e, t) => this.onHistogram?.(e, t),
			unavailable: () => this.onHistogramUnavailable?.()
		}), $e.set(e, this), this.frame = t.createBuffer({
			size: 320,
			usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
		}), this.query = t.createBuffer({
			size: 16,
			usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
		}), this.queryOutput = t.createBuffer({
			size: 16,
			usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
		}), this.quadIndices = t.createBuffer({
			size: 12,
			usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST
		}), t.queue.writeBuffer(this.quadIndices, 0, new Uint16Array([
			0,
			1,
			2,
			2,
			1,
			3
		])), this.steady = new Ne(t, n, this.frame, {
			admit: (e) => this.admitSteady?.(e),
			invalidate: () => this.onFrameNeeded?.(),
			status: (e) => this.onRenderStatus?.(e)
		}), t.lost.then((e) => {
			this.lost = !0, this.steady.dispose(), this.histogram.dispose(), be(this), this.surfaceScratch.dispose(), this.disposed || (this.onDeviceLost ?? this.onLost)?.(e.message || "The graphics device was lost. Your edits are retained.");
		}), t.addEventListener("uncapturederror", (e) => {
			!this.disposed && !this.lost && this.onLost?.(e.error.message);
		});
	}
	static async create(t, n) {
		let r = new pe(n);
		try {
			if (!navigator.gpu) throw Error("WebGPU is required for editing. Use Safari on macOS Tahoe 26 or later, or a compatible current Chrome.");
			r.advance("adapter-request");
			let n = await navigator.gpu.requestAdapter({ powerPreference: "high-performance" });
			if (!n) throw Error("No compatible graphics device is available.");
			r.observeAdapter(n);
			let i = Math.min(n.limits.maxBufferSize, 512 * h), a = { requiredLimits: {
				maxBufferSize: i,
				maxStorageBufferBindingSize: Math.min(n.limits.maxStorageBufferBindingSize, i)
			} };
			r.observeRequest(a);
			let o = await n.requestDevice(a);
			r.observeDevice(o), o.pushErrorScope("out-of-memory"), o.pushErrorScope("validation"), o.pushErrorScope("internal");
			let s = !1, c;
			try {
				r.advance("shader-compilation");
				let n = navigator.gpu.getPreferredCanvasFormat(), i = {
					splat: o.createShaderModule({
						label: "SplatView native projection and shading",
						code: p + k
					}),
					sort: o.createShaderModule({
						label: "SplatView stable radix",
						code: p + A
					}),
					scan: o.createShaderModule({
						label: "SplatView radix prefix scans",
						code: j
					}),
					geometry: o.createShaderModule({
						label: "SplatView readonly PLY geometry",
						code: ee
					})
				};
				for (let e of Object.values(i)) {
					let t = (await e.getCompilationInfo()).messages.filter((e) => e.type === "error");
					if (t.length) throw Error(t.map((e) => `Shader ${e.lineNum}: ${e.message}`).join("\n"));
				}
				r.advance("pipeline-creation");
				let a = [
					["project", i.splat],
					["generate", i.sort],
					["rank", i.sort],
					["scatter", i.sort],
					["local", i.scan],
					["blocks", i.scan],
					["bins", i.scan],
					["pick", i.splat]
				], l = await Promise.all(a.map(async ([e, t]) => [e, await o.createComputePipelineAsync({
					label: e,
					layout: "auto",
					compute: {
						module: t,
						entryPoint: e
					}
				})])), u = await o.createRenderPipelineAsync({
					label: "Native Gaussian composition",
					layout: "auto",
					vertex: {
						module: i.splat,
						entryPoint: "vertex"
					},
					primitive: { topology: "triangle-list" },
					fragment: {
						module: i.splat,
						entryPoint: "fragment",
						targets: [{
							format: n,
							blend: {
								color: {
									srcFactor: "one",
									dstFactor: "one-minus-src-alpha"
								},
								alpha: {
									srcFactor: "one",
									dstFactor: "one-minus-src-alpha"
								}
							}
						}]
					}
				}), d = (e) => o.createRenderPipelineAsync({
					label: e ? "Native readonly PLY mesh" : "Native readonly PLY points",
					layout: "auto",
					vertex: {
						module: i.geometry,
						entryPoint: e ? "meshVertex" : "pointVertex",
						buffers: [{
							arrayStride: 16,
							stepMode: e ? "vertex" : "instance",
							attributes: [{
								shaderLocation: 0,
								offset: 0,
								format: "float32x3"
							}, {
								shaderLocation: 1,
								offset: 12,
								format: "unorm8x4"
							}]
						}]
					},
					primitive: {
						topology: "triangle-list",
						cullMode: "none"
					},
					depthStencil: {
						format: "depth32float",
						depthWriteEnabled: !0,
						depthCompare: "less"
					},
					fragment: {
						module: i.geometry,
						entryPoint: e ? "meshFragment" : "pointFragment",
						targets: [{ format: n }]
					}
				}), [f, m] = await Promise.all([d(!1), d(!0)]);
				r.advance("renderer-creation"), c = new e(t, o, n, Object.fromEntries(l), u, f, m, r), r.advance("validation");
				let h = [
					o.popErrorScope(),
					o.popErrorScope(),
					o.popErrorScope()
				];
				s = !0;
				let g = (await Promise.all(h)).find((e) => e !== null);
				if (g) throw Error(g.message);
				if (c.lost) throw Error("The graphics device was lost during initialization.");
				return r.advance("ready"), c;
			} catch (e) {
				throw r.fail(e), s || await Promise.allSettled([
					o.popErrorScope(),
					o.popErrorScope(),
					o.popErrorScope()
				]), c?.dispose(), o.destroy(), e;
			}
		} catch (e) {
			throw r.fail(e), e;
		}
	}
	bind(e, t) {
		return this.device.createBindGroup({
			layout: e.getBindGroupLayout(0),
			entries: t.map(([e, t]) => ({
				binding: e,
				resource: { buffer: t }
			}))
		});
	}
	setHistogramEnabled(e) {
		this.histogram.setEnabled(e);
	}
	displayCompletion() {
		return this.displayCheckpoint;
	}
	async finish() {
		await this.queryQueue, await this.device.queue.onSubmittedWorkDone();
	}
	surface(e, t) {
		if (this.requireScene(e), this.surfaceSnapshot(e), e.sortDirty || e.residentSortPrecision < 32 || !s(e.residentOrder, this.preparedUniform, e.sourceRevision)) {
			let t = this.device.createCommandEncoder();
			try {
				this.sort(t, e, this.preparedCameraRevision), this.device.queue.submit([t.finish()]);
			} catch (t) {
				throw e.residentOrder = void 0, e.sortDirty = !0, t;
			}
		}
		return Ye(this, e, t);
	}
	prepareSurfaceResources() {
		return Promise.all([ye(this), Le(this).catch(() => void 0)]).then(() => void 0);
	}
	setRenderSettings(e) {
		this.steady.configure(e);
	}
	resetRenderHistory() {
		this.steady.resetHistory(), this.onFrameNeeded?.();
	}
	get steadySnapshot() {
		return this.steady.snapshot;
	}
	resetHistogram() {
		this.histogramDisplay = void 0, this.histogram.reset();
	}
	trimSurfaceResources(e) {
		this.surfaceScratch.trim(e);
	}
	scene(e, t) {
		return new et(this, e, Math.min(t, 3));
	}
	requireScene(e) {
		if (this.disposed || this.lost) throw new Y("The graphics device is unavailable. Your edits are retained.");
		if (e && (e.renderer !== this || e.deviceEpoch !== this.deviceEpoch || e.retired)) throw new Y("The scene belongs to an obsolete graphics device or allocation.");
	}
	async allocateScene(e, t) {
		let n = (async () => {
			let n = await this.checkedAllocation(() => this.scene(e, t), (e) => e.dispose());
			try {
				return n.fastOrder = await O(this, n), this.requireScene(n), n;
			} catch (e) {
				throw await n.dispose(), e;
			}
		})();
		this.scenePreparations.add(n);
		try {
			return await n;
		} finally {
			this.scenePreparations.delete(n);
		}
	}
	async allocateGeometry(e) {
		let t = await this.checkedAllocation(() => new N(this, e), (e) => e.dispose());
		this.geometryScenes.add(t);
		try {
			return await this.prepareGeometryTarget(), t;
		} catch (e) {
			throw await t.dispose(), e;
		}
	}
	get geometryDepthAllocationBytes() {
		return [...this.geometryDepthAllocations].reduce((e, t) => e + t.bytes, 0);
	}
	createGeometryDepth(e, t) {
		if (!Number.isSafeInteger(e) || !Number.isSafeInteger(t) || e <= 0 || t <= 0 || e > this.device.limits.maxTextureDimension2D || t > this.device.limits.maxTextureDimension2D) throw Error("The PLY preview target exceeds the graphics device limit.");
		let n = y(y(e, t), 4), r = this.admitGeometryDepth?.(n);
		try {
			let i = {
				texture: this.device.createTexture({
					label: "Readonly PLY viewport depth",
					size: [e, t],
					format: "depth32float",
					usage: GPUTextureUsage.RENDER_ATTACHMENT
				}),
				width: e,
				height: t,
				bytes: n,
				release: r
			};
			return this.geometryDepthAllocations.add(i), i;
		} catch (e) {
			throw r?.(), e;
		}
	}
	retireGeometryDepth(e) {
		return e.retirement ||= (this.retiringGeometryDepth.add(e), (async () => {
			try {
				await this.device.queue.onSubmittedWorkDone();
			} catch {} finally {
				e.texture.destroy(), e.release?.(), this.retiringGeometryDepth.delete(e), this.geometryDepthAllocations.delete(e);
			}
		})()), e.retirement;
	}
	publishGeometryDepth(e) {
		let t = this.geometryDepth;
		this.geometryDepth = e, t && this.retireGeometryDepth(t);
	}
	retainGeometryTarget(e, t) {
		this.geometryTargetPreparation && (this.geometryTargetPreparation.width !== e || this.geometryTargetPreparation.height !== t) && (this.geometryTargetGeneration++, this.geometryTargetPreparation = void 0), this.geometryTargetFailure && (this.geometryTargetFailure.width !== e || this.geometryTargetFailure.height !== t) && (this.geometryTargetFailure = void 0);
	}
	async prepareGeometryTarget(e = this.canvas.width, t = this.canvas.height) {
		if (this.requireScene(), this.geometryDepth?.width === e && this.geometryDepth.height === t) {
			this.retainGeometryTarget(e, t);
			return;
		}
		if (this.geometryTargetPreparation?.width === e && this.geometryTargetPreparation.height === t) return this.geometryTargetPreparation.task;
		let n = ++this.geometryTargetGeneration;
		this.geometryTargetFailure = void 0;
		let r = this.checkedAllocation(() => this.createGeometryDepth(e, t), (e) => this.retireGeometryDepth(e)).then(async (r) => {
			n !== this.geometryTargetGeneration || this.lost || this.disposed || !this.geometryScenes.size ? (await this.retireGeometryDepth(r), this.requireScene()) : this.geometryDepth?.width === e && this.geometryDepth.height === t ? await this.retireGeometryDepth(r) : this.publishGeometryDepth(r);
		}).finally(() => {
			this.geometryTargetTasks.delete(r), this.geometryTargetPreparation?.task === r && (this.geometryTargetPreparation = void 0);
		});
		return this.geometryTargetTasks.add(r), this.geometryTargetPreparation = {
			width: e,
			height: t,
			task: r
		}, r;
	}
	requestGeometryTarget(e, t) {
		this.geometryTargetFailure?.width === e && this.geometryTargetFailure.height === t || this.geometryTargetPreparation?.width === e && this.geometryTargetPreparation.height === t || this.prepareGeometryTarget(e, t).then(() => {
			!this.disposed && !this.lost && this.canvas.width === e && this.canvas.height === t && this.geometryDepth?.width === e && this.geometryDepth.height === t && this.onFrameNeeded?.();
		}).catch((n) => {
			!this.disposed && !this.lost && this.geometryScenes.size && this.canvas.width === e && this.canvas.height === t && (this.geometryTargetFailure = {
				width: e,
				height: t
			}, this.onLost?.(n instanceof Error ? n.message : String(n)));
		});
	}
	async releaseGeometryScene(e) {
		this.geometryScenes.delete(e);
		let t = this.geometryScenes.size ? [] : [...this.geometryTargetTasks];
		if (this.geometryScenes.size || (this.geometryTargetGeneration++, this.geometryTargetFailure = void 0), !this.geometryScenes.size && this.geometryDepth) {
			let e = this.geometryDepth;
			this.geometryDepth = void 0, await this.retireGeometryDepth(e);
		}
		await Promise.allSettled(t), this.geometryScenes.size || await Promise.all([...this.retiringGeometryDepth].map((e) => e.retirement));
	}
	async checkedAllocation(e, t) {
		this.requireScene(), this.device.pushErrorScope("out-of-memory"), this.device.pushErrorScope("validation"), this.device.pushErrorScope("internal");
		let n, r = !1, i;
		try {
			n = e(), r = !0;
		} catch (e) {
			i = e;
		}
		let a = [
			this.device.popErrorScope(),
			this.device.popErrorScope(),
			this.device.popErrorScope()
		];
		try {
			let e = await Promise.all(a);
			i ??= e.find((e) => e !== null), this.lost && (i ??= /* @__PURE__ */ Error("The graphics device was lost while preparing the edit."));
		} catch (e) {
			i ??= e;
		}
		if (i) throw r && await t(n), Error(i && typeof i == "object" && "message" in i ? String(i.message) : String(i));
		return n;
	}
	setOpacityPreview(e, t) {
		if (!Number.isFinite(e) || e < 0 || e > 5) throw RangeError("Opacity scale must be between 0 and 5.");
		e = Math.fround(e), t = e !== 1 && t, (e !== (this.opacityScale ?? 1) || t !== (this.opacitySelectedOnly ?? !1)) && (this.opacityScale = e, this.opacitySelectedOnly = t, this.opacityRevision = (this.opacityRevision ?? 0) + 1, this.frameRevision++);
	}
	uniform(e, t, n, r, i, a, o = this.canvas.width, s = this.canvas.height, c = a, l = 1, u = !1, d = !0) {
		if (this.requireScene(e), !Number.isFinite(l) || l < 0 || l > 5) throw RangeError("Opacity scale must be between 0 and 5.");
		l = Math.fround(l), u = l !== 1 && u, d && this.setOpacityPreview(l, u);
		let { values: f, words: p, geometryKey: m } = Xe(e, t, n, r, i, a, o, s, c, l, u);
		m !== e.lastGeometry && (e.sortDirty = !0, e.lastGeometry = m), (this.preparedScene !== e || this.preparedSceneRevision !== e.revision || !this.preparedUniform || p.some((e, t) => e !== this.preparedUniform[t])) && this.frameRevision++, this.preparedScene = e, this.preparedSceneRevision = e.revision, this.preparedWidth = o, this.preparedHeight = s, this.preparedCameraRevision = t.revision, this.preparedUniform = p, this.preparedOpacityRevision = l === (this.opacityScale ?? 1) && u === (this.opacitySelectedOnly ?? !1) ? this.opacityRevision ?? 0 : -1, this.device.queue.writeBuffer(this.frame, 0, f);
	}
	sortPrecision = 32;
	get displaySortPrecision() {
		return this.sortPrecision ?? 32;
	}
	set displaySortPrecision(e) {
		let t = f(e);
		this.displaySortPrecision !== t && (this.sortPrecision = t, this.onFrameNeeded?.());
	}
	prepare(e, t, n, r = !0, i = 32) {
		let a = this.preparedUniform, o = t.residentProjection;
		if (!o || o.revision !== t.revision || a.some((e, t) => e !== o.words[t])) {
			let n = e.beginComputePass({ label: "Project Gaussians" });
			n.setPipeline(this.pipelines.project), n.setBindGroup(0, t.projectGroup), n.dispatchWorkgroups(Math.ceil(t.count / 256)), n.end(), t.residentProjection = {
				revision: t.revision,
				words: a.slice()
			};
		}
		r && (this.sort(e, t, n.revision, i), t.fastOrder && (d(t.residentCompactOrder, a, t.revision, i) || (t.fastOrder.encode(e), t.residentCompactOrder = u(a, t.revision, i))));
	}
	sort(e, t, n, r = 32) {
		if (t.count < 2048 && (r = 32), t.sortDirty || (t.residentSortPrecision ?? 32) < r || !s(t.residentOrder, this.preparedUniform, t.sourceRevision)) {
			let i = e.beginComputePass({ label: "Stable depth sort" }), a = 1 + (32 - r) / 4 * 5;
			for (let e = 0; e < t.sortStages.length; e++) {
				if (e > 0 && e < a) continue;
				let n = t.sortStages[e];
				i.setPipeline(n.pipeline), i.setBindGroup(0, n.group), i.dispatchWorkgroups(n.x, n.y ?? 1);
			}
			i.end(), t.sortDirty = !1, t.lastCameraRevision = n, t.residentSortPrecision = r, t.residentOrder = c(this.preparedUniform, t.sourceRevision);
		}
	}
	draw(e, t, n, r) {
		let i = e.beginRenderPass({ colorAttachments: [{
			view: n,
			clearValue: [
				r,
				r,
				r,
				1
			],
			loadOp: "clear",
			storeOp: "store"
		}] });
		i.setPipeline(this.raster), i.setBindGroup(0, t.fastOrder && t.residentCompactOrder ? t.fastOrder.drawGroup : t.drawGroup), i.setIndexBuffer(this.quadIndices, "uint16"), t.fastOrder && t.residentCompactOrder ? i.drawIndexedIndirect(t.fastOrder.indirect, 0) : i.drawIndexed(6, t.count), i.end();
	}
	geometryUniform(e, t, n, r) {
		this.requireScene(e), this.frameRevision++, this.preparedScene = void 0, this.preparedUniform = void 0;
		let i = /* @__PURE__ */ new Float32Array(40);
		i.set(t.view), i.set(t.projection, 16), i.set([
			n,
			r,
			Math.max(1.3, Math.min(3, Math.min(n, r) / 160)),
			+(e.descriptor.kind === 2)
		], 36), this.device.queue.writeBuffer(this.frame, 0, i);
	}
	drawGeometry(e, t, n, r, i) {
		let a = e.beginRenderPass({
			label: "Native readonly PLY composition",
			colorAttachments: [{
				view: n,
				clearValue: [
					i,
					i,
					i,
					1
				],
				loadOp: "clear",
				storeOp: "store"
			}],
			depthStencilAttachment: {
				view: r,
				depthClearValue: 1,
				depthLoadOp: "clear",
				depthStoreOp: "store"
			}
		});
		a.setPipeline(t.descriptor.kind === 2 ? this.geometryMesh : this.geometryPoints), a.setBindGroup(0, t.drawGroup), a.setVertexBuffer(0, t.vertices), t.descriptor.kind === 2 ? (a.setIndexBuffer(t.indices, "uint32"), a.drawIndexed(t.descriptor.triangleCount * 3)) : a.draw(6, t.count), a.end();
	}
	render(e, t, n = L, r = !0, i = R, a = !1, o = a, s = 1, c = !1) {
		this.requireScene(e);
		try {
			let l = this.device.createCommandEncoder(), u, d = Ze(t.background);
			if (e?.kind === "geometry") {
				this.steady.suspend("SteadySplats requires a Gaussian scene.");
				let n = this.canvas.width, r = this.canvas.height;
				if (this.geometryDepth?.width !== n || this.geometryDepth.height !== r) {
					this.requestGeometryTarget(n, r);
					return;
				}
				this.retainGeometryTarget(n, r), this.geometryUniform(e, t, n, r), u = this.context.getCurrentTexture(), this.drawGeometry(l, e, u.createView(), this.geometryDepth.texture.createView(), d);
			} else if (e) {
				let f = De(t.projection);
				f || this.steady.suspend("SteadySplats requires a supported perspective projection.");
				let p = f && this.steady.ready(this.canvas.width, this.canvas.height);
				this.uniform(e, t, n, r, i, a, this.canvas.width, this.canvas.height, o, s, c), this.prepare(l, e, t, !p, this.displaySortPrecision), u = this.context.getCurrentTexture(), p ? this.steady.encode(l, e, this.preparedUniform, d, u.createView()) && this.onFrameNeeded?.() : this.draw(l, e, u.createView(), d);
			} else this.steady.suspend("SteadySplats requires a Gaussian scene."), u = this.context.getCurrentTexture(), l.beginRenderPass({ colorAttachments: [{
				view: u.createView(),
				clearValue: [
					d,
					d,
					d,
					1
				],
				loadOp: "clear",
				storeOp: "store"
			}] }).end();
			this.device.queue.submit([l.finish()]), this.submittedDisplayFrames++;
			let f = this.device.queue.onSubmittedWorkDone();
			if (f.catch(() => void 0), this.displayCheckpoint = {
				deviceEpoch: this.deviceEpoch,
				submissionSequence: this.submittedDisplayFrames,
				done: f
			}, this.canvas.dataset.frames = String(++this.frames), e?.kind === "gaussian") {
				let n = this.canvas.width, r = this.canvas.height, i = this.preparedUniform, a = this.steady.snapshot.status === "steady" ? this.steady.snapshot.frame : void 0, o = this.histogramDisplay;
				(!o || o.scene !== e || o.revision !== e.revision || o.cameraRevision !== t.revision || o.width !== n || o.height !== r || o.shade !== d || o.steadyFrame !== a || i.some((e, t) => e !== o.uniform[t])) && (this.histogramDisplay = {
					scene: e,
					revision: e.revision,
					cameraRevision: t.revision,
					width: n,
					height: r,
					uniform: i,
					shade: d,
					steadyFrame: a,
					identity: {}
				}), this.histogram.observe(u, {
					identity: this.histogramDisplay.identity,
					scene: e,
					width: n,
					height: r,
					frame: this.frames
				});
			} else this.histogramDisplay && this.resetHistogram();
		} catch (t) {
			throw e?.kind === "gaussian" && (e.residentOrder = void 0, e.residentCompactOrder = void 0, e.residentProjection = void 0, e.sortDirty = !0), this.preparedScene = void 0, this.preparedUniform = void 0, this.frameRevision++, t;
		}
	}
	async pick(e, t, n, r = 0) {
		if (this.requireScene(e), this.requireGaussian(e), !Number.isFinite(t) || !Number.isFinite(n) || !Number.isFinite(r) || r < 0 || t < 0 || n < 0 || t >= this.canvas.width || n >= this.canvas.height) return Promise.resolve({
			index: null,
			depth: 0,
			opacity: 0,
			contribution: 0,
			deviceEpoch: this.deviceEpoch
		});
		let i = new Float32Array([
			Math.floor(t) + .5,
			Math.floor(n) + .5,
			r,
			0
		]), a = this.querySnapshot(e), o = async () => {
			a();
			let t = this.device.createBuffer({
				size: 16,
				usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
			}), n, r, o = !1;
			try {
				n = await Re(this, e), a(), this.device.queue.writeBuffer(this.query, 0, i);
				let s = this.device.createCommandEncoder();
				if (this.sort(s, e, this.preparedCameraRevision), n) n.encode(s);
				else {
					let t = s.beginComputePass();
					t.setPipeline(this.pipelines.pick), t.setBindGroup(0, e.pickGroup), t.dispatchWorkgroups(1), t.end();
				}
				s.copyBufferToBuffer(this.queryOutput, 0, t, 0, 16), this.device.queue.submit([s.finish()]), o = !0, n && (r = this.device.queue.onSubmittedWorkDone()), await t.mapAsync(GPUMapMode.READ), a();
				let c = t.getMappedRange().slice(0), l = new Uint32Array(c), u = new Float32Array(c);
				return t.unmap(), {
					index: l[0] ? l[0] - 1 : null,
					depth: u[1],
					opacity: u[2],
					contribution: u[3],
					deviceEpoch: this.deviceEpoch
				};
			} finally {
				o || (e.residentOrder = void 0, e.sortDirty = !0), r && await r.catch(() => void 0), n?.dispose(), t.destroy();
			}
		}, s = this.queryQueue.then(o, o);
		return this.queryQueue = s.catch(() => void 0), s;
	}
	querySnapshot(e) {
		this.requireScene(e), this.requireGaussian(e);
		let t = this.frameRevision, n = () => {
			if (this.requireScene(e), t !== this.frameRevision || this.preparedScene !== e || e.revision !== this.preparedSceneRevision || this.preparedOpacityRevision !== (this.opacityRevision ?? 0) || this.canvas.width !== this.preparedWidth || this.canvas.height !== this.preparedHeight) throw new Y("The rendered view, viewport or scene changed before the query completed.");
		};
		return n(), n;
	}
	surfaceSnapshot(e) {
		if (this.requireScene(e), this.requireGaussian(e), this.requireScene(e), this.preparedScene !== e || !this.preparedUniform || e.revision !== this.preparedSceneRevision || this.preparedOpacityRevision !== (this.opacityRevision ?? 0)) throw new Y("Prepare the current scene before querying its surface.");
		let t = e.sourceRevision, n = e.selectedRevision, r = this.preparedWidth, i = this.preparedHeight, a = this.preparedUniform, o = this.opacityRevision ?? 0, s = (e) => [
			...e.subarray(0, 42),
			e[59],
			...e.subarray(60, 77),
			e[76] ? e[77] : 0,
			e[79]
		], c = s(a), l = a[76] !== 0 && a[77] !== 0, u = (a[79] & 3) == 3, d = l || u, f = e.previewMaskRevision("transformBase"), p = e.previewMaskRevision("opacityBase"), m = () => {
			this.requireScene(e);
			let a = this.preparedUniform, m = a ? s(a) : [];
			if (this.preparedScene !== e || !a || e.sourceRevision !== t || o !== (this.opacityRevision ?? 0) || this.preparedOpacityRevision !== o || d && e.selectedRevision !== n || l && e.previewMaskRevision("transformBase") !== f || u && e.previewMaskRevision("opacityBase") !== p || this.canvas.width !== r || this.canvas.height !== i || c.some((e, t) => e !== m[t])) throw new Y("The surface geometry, view, viewport or source membership changed.");
		};
		return m(), m;
	}
	requireGaussian(e) {
		if (this.requireScene(e), e.kind !== "gaussian") throw Error("Surface queries are available for Gaussian splats only.");
	}
	async captureRgba(e, t, n, r = L, i = R, a = !1, o = a, s = 1, c = !1) {
		if (this.requireScene(e), !Number.isFinite(s) || s < 0 || s > 5) throw RangeError("Opacity scale must be between 0 and 5.");
		let l = Math.fround(s), u = l !== 1 && c, d = this.canvas.width, f = this.canvas.height, p = Math.ceil(d * 4 / 256) * 256;
		if (!Number.isSafeInteger(d) || !Number.isSafeInteger(f) || d < 1 || f < 1 || d > this.device.limits.maxTextureDimension2D || f > this.device.limits.maxTextureDimension2D) throw RangeError("The capture dimensions exceed the graphics device limit.");
		let m = {
			view: new Float32Array(t.view),
			projection: new Float32Array(t.projection),
			eye: new Float32Array(t.eye),
			revision: t.revision,
			background: t.background
		}, h = [...r], g = [...i], _ = e.revision, v = V(d, f), b = y(p, f), x = y(b + v * (e.kind === "geometry" ? 2 : 1), 1), S = () => {
			if (n.signal?.throwIfAborted(), n.current?.(), this.requireScene(e), e.revision !== _) throw new Y("The scene changed before its captured image completed.");
		};
		S();
		let C = n.admit(v), w, T, E, D, O, k = !1, A = !1, j = !1;
		try {
			w = n.admit(x), S();
			try {
				let t = await this.checkedAllocation(() => {
					let t, n, r;
					try {
						return t = this.device.createTexture({
							size: [d, f],
							format: this.format,
							usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC
						}), n = this.device.createBuffer({
							label: "Image capture readback",
							size: b,
							usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST
						}), e.kind === "geometry" && (r = this.device.createTexture({
							label: "Readonly PLY capture depth",
							size: [d, f],
							format: "depth32float",
							usage: GPUTextureUsage.RENDER_ATTACHMENT
						})), {
							texture: t,
							readback: n,
							depth: r
						};
					} catch (e) {
						throw n?.destroy(), t?.destroy(), r?.destroy(), e;
					}
				}, (e) => {
					e.readback.destroy(), e.texture.destroy(), e.depth?.destroy();
				});
				({texture: T, readback: E, depth: D} = t), S();
				let n = this.device.createCommandEncoder();
				e.kind === "geometry" ? (this.geometryUniform(e, m, d, f), this.drawGeometry(n, e, T.createView(), D.createView(), Ze(m.background))) : (j = !0, this.uniform(e, m, h, !1, g, a, d, f, o, l, u, !1), this.prepare(n, e, m), this.draw(n, e, T.createView(), Ze(m.background))), n.copyTextureToBuffer({ texture: T }, {
					buffer: E,
					bytesPerRow: p
				}, [d, f]), this.device.queue.submit([n.finish()]), A = !0, await E.mapAsync(GPUMapMode.READ), k = !0, S();
				let r = new Uint8Array(E.getMappedRange());
				O = new Uint8ClampedArray(v);
				for (let e = 0; e < f; e++) O.set(r.subarray(e * p, e * p + d * 4), e * d * 4);
				if (this.format.startsWith("bgra")) for (let e = 0; e < O.length; e += 4) [O[e], O[e + 2]] = [O[e + 2], O[e]];
			} finally {
				if (j && !A && e.kind === "gaussian" && (e.residentProjection = void 0, e.residentOrder = void 0, e.residentCompactOrder = void 0, e.sortDirty = !0, this.preparedScene = void 0, this.preparedUniform = void 0, this.frameRevision++), A) try {
					await this.device.queue.onSubmittedWorkDone();
				} catch {}
				try {
					k && E?.unmap();
				} finally {
					E?.destroy(), T?.destroy(), D?.destroy(), w?.(), w = void 0;
				}
			}
			S();
			let t = ae(d, f, O, C);
			return C = void 0, t;
		} finally {
			if (w?.(), C) try {
				O?.byteLength && structuredClone(O.buffer, { transfer: [O.buffer] });
			} finally {
				C();
			}
		}
	}
	async capture(e, t, n = "image/png", r = L, i = R, a = !1, o = a, s = 1, c = !1) {
		if (n !== "image/png" && n !== "image/jpeg") throw Error("Unsupported capture image type.");
		let l = { admit: () => () => void 0 }, u = await this.captureRgba(e, t, l, r, i, a, o, s, c);
		try {
			let e = await U(u, n, l);
			try {
				return e.blob;
			} finally {
				e.dispose();
			}
		} finally {
			u.dispose();
		}
	}
	async close() {
		this.dispose(), await Promise.allSettled([
			this.queryQueue,
			this.steady.finish(),
			this.histogram.finish(),
			...this.scenePreparations,
			...[...this.retiringGeometryDepth].map((e) => e.retirement)
		]);
	}
	dispose() {
		if (!this.disposed) {
			if (this.disposed = !0, this.histogram.dispose(), this.steady.dispose(), this.geometryTargetGeneration++, this.geometryDepth) {
				let e = this.geometryDepth;
				this.geometryDepth = void 0, this.retireGeometryDepth(e);
			}
			this.frame.destroy(), this.query.destroy(), this.queryOutput.destroy(), this.quadIndices.destroy(), $e.get(this.canvas) === this && (this.context.unconfigure(), $e.delete(this.canvas)), this.device.destroy(), be(this), this.surfaceScratch.dispose();
		}
	}
}, nt = "// Direct GLSL port of SplatView frame.wgsl and splats.wgsl. Canonical matrices\n// and coverage are shared; only final raster depth is converted to GL clip space.\nprecision highp float;\nprecision highp int;\nprecision highp usampler2D;\nlayout(std140) uniform GaussianFrame {\n  mat4 view; mat4 projection; vec4 eyeDegree; vec4 viewport; uvec4 flags;\n  vec4 gradeA; vec4 gradeB; vec4 gradeC; vec4 gradeD; mat4 geometry; uvec4 geometryFlags;\n};\nuniform usampler2D wordsTexture;\nuniform usampler2D statesTexture;\nuniform usampler2D orderTexture;\nuniform bool useOrder;\n\nivec2 address2d(uint index, ivec2 size) { return ivec2(int(index % uint(size.x)),int(index / uint(size.x))); }\nuint sourceWord(uint address) { return texelFetch(wordsTexture,address2d(address,textureSize(wordsTexture,0)),0).r; }\nfloat sourceFloat(uint address) { return uintBitsToFloat(sourceWord(address)); }\nfloat coefficient(uint address,uint i) { vec2 v=unpackHalf2x16(sourceWord(address+10u+i/2u)); return v[int(i%2u)]; }\nvec3 coefficients(uint address,uint i) { return vec3(coefficient(address,3u*i),coefficient(address,3u*i+1u),coefficient(address,3u*i+2u)); }\nfloat opacitySupport(float a) {\n  if(a>=.2141082512) return 9.;\n  if(a>=.0289764008) {\n    if(a>=.0787660238) return a>=.1298632188 ? 8.:7.;\n    return a>=.0477740084 ? 6.:5.;\n  }\n  if(a>=.0106598221) return a>=.0175750755 ? 4.:3.;\n  return a>=.0064655090 ? 2.:1.;\n}\nfloat previewOpacity(float a,uint state) {\n  if((geometryFlags.w&1u)==0u || ((geometryFlags.w&2u)!=0u && (state&1u)==0u)) return a;\n  return gradeD.w<=1. ? clamp(a*gradeD.w,0.,1.):clamp(a+(1.-a)*(gradeD.w-1.)/2.,0.,1.);\n}\nfloat luma(vec3 v) { return dot(v,vec3(.299,.587,.114)); }\nvec3 rotateColor(vec3 value) {\n  vec3 v=vec3(luma(value))+(value-vec3(luma(value)))*gradeA.w;\n  if(gradeD.z==0.) return v;\n  float cs=cos(radians(gradeD.z)), sn=sin(radians(gradeD.z));\n  return vec3(dot(vec3(.299+.701*cs+.168*sn,.587-.587*cs+.330*sn,.114-.114*cs-.497*sn),v),\n    dot(vec3(.299-.299*cs-.328*sn,.587+.413*cs+.035*sn,.114-.114*cs+.292*sn),v),\n    dot(vec3(.299-.300*cs+1.250*sn,.587-.588*cs-1.050*sn,.114+.886*cs-.203*sn),v));\n}\nvec3 halfColor(vec3 value) {\n  vec3 v=clamp(value,vec3(-65504.),vec3(65504.));\n  return vec3(unpackHalf2x16(packHalf2x16(v.xy)),unpackHalf2x16(packHalf2x16(vec2(v.z,0.))).x);\n}\nvec2 gammaChannel(float value,float radius) {\n  float low=max(0.,value-radius), high=max(0.,value+radius);\n  if(high<=0.) return vec2(value,1.);\n  if(high-low>high*.001) {\n    float lowPower=pow(low,gradeA.z), highPower=pow(high,gradeA.z);\n    float gain=(highPower-lowPower)/(high-low); return vec2(lowPower+(value-low)*gain,gain);\n  }\n  float after=pow(value,gradeA.z); return vec2(after,gradeA.z*after/value);\n}\nvec3 gaussianColor(uint address,vec3 position,uint state) {\n  vec3 direction=position-eyeDegree.xyz, d=direction/max(length(direction),1e-20);\n  float x=d.x,y=d.y,z=d.z,xx=x*x,yy=y*y,zz=z*z;\n  float b[16]; b[0]=.2820947918;\n  b[1]=-.4886025119*y; b[2]=.4886025119*z; b[3]=-.4886025119*x;\n  b[4]=1.0925484306*x*y; b[5]=-1.0925484306*y*z;\n  b[6]=.3153915653*(2.*zz-xx-yy); b[7]=-1.0925484306*x*z; b[8]=.5462742153*(xx-yy);\n  b[9]=-.5900435899*y*(3.*xx-yy); b[10]=2.8906114426*x*y*z;\n  b[11]=-.4570457995*y*(4.*zz-xx-yy); b[12]=.3731763326*z*(2.*zz-3.*xx-3.*yy);\n  b[13]=-.4570457995*x*(4.*zz-xx-yy); b[14]=1.4453057213*z*(xx-yy); b[15]=-.5900435899*x*(xx-3.*yy);\n  uint bands=uint(eyeDegree.w)+1u, count=bands*bands;\n  vec3 result=vec3(.5);\n  if(flags.z==0u || (flags.w!=0u && (state&1u)==0u)) {\n    for(uint j=0u;j<count;j++) result+=b[j]*coefficients(address,j);\n    return max(result,vec3(0.));\n  }\n  vec3 temperature=vec3(1.+.3*gradeB.y,1.,1.-.3*gradeB.y);\n  vec3 dc=coefficients(address,0u)*temperature+vec3(.05,-.1,.05)*gradeB.z;\n  dc=(dc*gradeA.x+vec3((gradeA.x-1.)*.5/b[0]))*gradeA.y;\n  vec3 gain=vec3(1.);\n  if(gradeA.z!=1.) {\n    vec3 energy=vec3(0.);\n    for(uint j=1u;j<count;j++) { vec3 v=(coefficients(address,j)*temperature*gradeA.x)*gradeA.y; energy+=v*v; }\n    vec3 radius=sqrt(energy*(float(count-1u)*.07957747154594767)), before=dc*b[0]+vec3(.5);\n    vec2 r=gammaChannel(before.x,radius.x), g=gammaChannel(before.y,radius.y), bl=gammaChannel(before.z,radius.z);\n    gain=vec3(r.y,g.y,bl.y); dc=(vec3(r.x,g.x,bl.x)-vec3(.5))/b[0];\n  }\n  dc=rotateColor(dc); vec3 rgb=dc*b[0]+vec3(.5);\n  if(gradeB.x!=1.) {\n    float sat=max(rgb.x,max(rgb.y,rgb.z))-min(rgb.x,min(rgb.y,rgb.z));\n    rgb=clamp(vec3(luma(rgb))+(rgb-vec3(luma(rgb)))*(1.+(1.-sat)*(gradeB.x-1.)),vec3(0.),vec3(1.));\n    dc=(rgb-vec3(.5))/b[0];\n  }\n  float shadow=1.-smoothstep(0.,.5,luma(rgb)), highlight=smoothstep(.5,1.,luma(rgb));\n  dc*=1.+gradeB.w*shadow+gradeC.x*highlight;\n  dc+=vec3(gradeC.y*(1.-gradeC.y)/b[0]);\n  vec3 phase=vec3(0.,2.094395102393195,4.18879020478639);\n  dc+=.5*cos(vec3(radians(gradeC.z))-phase)*gradeC.w*shadow/b[0];\n  dc+=.5*cos(vec3(radians(gradeD.x))-phase)*gradeD.y*highlight/b[0];\n  result+=b[0]*halfColor(dc);\n  for(uint k=1u;k<count;k++) {\n    vec3 v=((coefficients(address,k)*temperature*gradeA.x)*gradeA.y)*gain;\n    result+=b[k]*halfColor(rotateColor(v));\n  }\n  return max(result,vec3(0.));\n}\nstruct Projected { vec4 center; vec4 axes; vec4 color; };\nProjected projectGaussian(uint id,uvec4 targets) {\n  Projected empty=Projected(vec4(0.),vec4(0.),vec4(0.));\n  if((targets.x&2u)!=0u) return empty;\n  uint address=id*flags.y;\n  vec4 position=vec4(sourceFloat(address),sourceFloat(address+1u),sourceFloat(address+2u),1.);\n  float opacity=previewOpacity(sourceFloat(address+3u),targets.w);\n  bool transforming=geometryFlags.x!=0u && (geometryFlags.y==0u || (targets.z&1u)!=0u);\n  if(transforming) position=geometry*position;\n  vec4 p=view*position;\n  if(p.z>=-.001 || opacity<.0039) return empty;\n  vec4 c0=vec4(sourceFloat(address+4u),sourceFloat(address+5u),sourceFloat(address+6u),sourceFloat(address+7u));\n  vec2 c1=vec2(sourceFloat(address+8u),sourceFloat(address+9u));\n  mat3 covariance=mat3(vec3(c0.x,c0.y,c0.z),vec3(c0.y,c0.w,c1.x),vec3(c0.z,c1.x,c1.y));\n  if(transforming) { mat3 a=mat3(geometry); covariance=a*covariance*transpose(a); }\n  float depth=-p.z;\n  vec3 right=vec3(view[0].x,view[1].x,view[2].x), up=vec3(view[0].y,view[1].y,view[2].y), forward=vec3(view[0].z,view[1].z,view[2].z);\n  vec3 jx=viewport.z/depth*(right+p.x/depth*forward), jy=viewport.w/depth*(up+p.y/depth*forward);\n  float a=dot(jx,covariance*jx)+.3, b=dot(jx,covariance*jy), c=dot(jy,covariance*jy)+.3;\n  float middle=(a+c)*.5, delta=sqrt(max(0.,(a-c)*(a-c)*.25+b*b));\n  float l1=max(.01,middle+delta), l2=max(.01,middle-delta);\n  vec2 axis=a>=c ? vec2(1.,0.):vec2(0.,1.);\n  if(abs(b)>.00001) axis=normalize(vec2(b,l1-a));\n  vec2 axis1=axis*min(1536.,3.*sqrt(l1)), axis2=vec2(-axis.y,axis.x)*min(1536.,3.*sqrt(l2));\n  vec4 clip=projection*p;\n  if(clip.z<0. || clip.z>clip.w) return empty;\n  vec2 extent=(abs(axis1)+abs(axis2)+vec2(1.))*2./viewport.xy*clip.w;\n  if(any(greaterThan(abs(clip.xy),vec2(clip.w)+extent))) return empty;\n  return Projected(vec4(clip.xy/clip.w,depth,1.),vec4(axis1,axis2),vec4(gaussianColor(address,position.xyz,targets.y),opacity));\n}\n", rt = "// gaussian.glsl precedes this source after the GLSL version declaration.\nout vec2 local;\nflat out vec4 gaussianCenter;\nflat out vec4 gaussianAxes;\nflat out vec4 gaussianColorOpacity;\nflat out uint sourceId;\nuniform bool stochasticDepth;\nvoid main() {\n  uint index=uint(gl_InstanceID);\n  uint id=useOrder ? texelFetch(orderTexture,address2d(index,textureSize(orderTexture,0)),0).r:index;\n  uvec4 targets=texelFetch(statesTexture,address2d(id,textureSize(statesTexture,0)),0);\n  Projected g=projectGaussian(id,targets);\n  vec2 corners[4]=vec2[4](vec2(-1.,-1.),vec2(1.,-1.),vec2(-1.,1.),vec2(1.,1.));\n  vec2 corner=corners[gl_VertexID], offset=g.axes.xy*corner.x+g.axes.zw*corner.y;\n  float z=-1.;\n  if(stochasticDepth) { vec4 clip=projection*vec4(0.,0.,-g.center.z,1.); z=2.*clip.z/max(clip.w,1e-20)-1.; }\n  gl_Position=vec4(g.center.xy+2.*offset/viewport.xy,z,1.);\n  if(g.center.w==0.) gl_Position=vec4(2.,2.,2.,1.);\n  vec4 color=g.color;\n  if(geometryFlags.z!=0u && (targets.x&1u)!=0u) {\n    vec3 tint=geometryFlags.z==2u ? vec3(.49,.824,.573):vec3(1.,.72,.12);\n    color.rgb=mix(color.rgb,tint,.72);\n  }\n  local=corner*3.; gaussianCenter=g.center; gaussianAxes=g.axes; gaussianColorOpacity=color; sourceId=id+1u;\n}\n", it = "precision highp float;\nin vec2 local;\nflat in vec4 gaussianColorOpacity;\nlayout(location=0) out vec4 color;\nfloat support(float a) {\n  if(a>=.2141082512) return 9.;\n  if(a>=.0289764008) { if(a>=.0787660238) return a>=.1298632188 ? 8.:7.; return a>=.0477740084 ? 6.:5.; }\n  if(a>=.0106598221) return a>=.0175750755 ? 4.:3.;\n  return a>=.0064655090 ? 2.:1.;\n}\nvoid main() {\n  float r=dot(local,local);\n  if(r>min(9.,support(gaussianColorOpacity.a)+.001)) discard;\n  float alpha=min(.99,gaussianColorOpacity.a*exp(-.5*r)); if(alpha<1./255.) discard;\n  color=vec4(gaussianColorOpacity.rgb*alpha,alpha);\n}\n", at = "precision highp float;\nlayout(location=0) in vec3 position;\nlayout(location=1) in vec4 color;\nuniform mat4 geometryView;\nuniform mat4 geometryProjection;\nuniform vec3 geometryViewport;\nuniform bool mesh;\nout vec3 world;\nout vec2 corner;\nout vec3 rgb;\nvoid main() {\n  vec2 corners[6]=vec2[6](vec2(-1.,-1.),vec2(1.,-1.),vec2(-1.,1.),vec2(-1.,1.),vec2(1.,-1.),vec2(1.,1.));\n  corner=mesh?vec2(0.):corners[gl_VertexID];\n  vec4 clip=geometryProjection*(geometryView*vec4(position,1.));\n  clip.xy+=corner*geometryViewport.z*2./geometryViewport.xy*clip.w;\n  clip.z=2.*clip.z-clip.w;\n  gl_Position=clip; world=position; rgb=color.rgb;\n}\n", ot = "precision highp float;\nin vec3 world;\nin vec2 corner;\nin vec3 rgb;\nuniform bool mesh;\nlayout(location=0) out vec4 color;\nvoid main() {\n  if(!mesh && dot(corner,corner)>1.) discard;\n  float lighting=1.;\n  if(mesh) {\n    vec3 normal=cross(dFdx(world),dFdy(world)); float lengthSquared=dot(normal,normal);\n    if(lengthSquared>0.) lighting=.35+.65*abs(dot(normal*inversesqrt(lengthSquared),normalize(vec3(.4,.7,.5))));\n  }\n  color=vec4(rgb*lighting,1.);\n}\n", st = /* @__PURE__ */ new WeakMap(), ct = /* @__PURE__ */ new WeakMap(), lt = /* @__PURE__ */ new WeakMap();
function ut(e, t, n, r) {
	let i = lt.get(t);
	i || (i = /* @__PURE__ */ new Map(), lt.set(t, i)), i.get(n) !== r && (e.uniform1i(X(e, t, n), r), i.set(n, r));
}
function X(e, t, n) {
	let r = st.get(t);
	return r || (r = /* @__PURE__ */ new Map(), st.set(t, r)), r.has(n) || r.set(n, e.getUniformLocation(t, n)), r.get(n);
}
function dt(e, t, n, r) {
	let i = ct.get(t);
	if (i || (i = /* @__PURE__ */ new Map(), ct.set(t, i)), !i.has(n)) {
		let a = e.getUniformBlockIndex(t, n);
		i.set(n, a), a !== e.INVALID_INDEX && e.uniformBlockBinding(t, a, r);
	}
	return i.get(n);
}
function ft(e, t, n) {
	let r = [], i = null;
	try {
		for (let [i, a] of [[e.VERTEX_SHADER, t], [e.FRAGMENT_SHADER, n]]) {
			let t = e.createShader(i);
			if (!t) throw Error("The graphics shader could not be allocated.");
			r.push(t), e.shaderSource(t, a), e.compileShader(t);
		}
		if (i = e.createProgram(), !i) throw Error("The graphics program could not be allocated.");
		for (let t of r) e.attachShader(i, t);
		if (e.linkProgram(i), !e.getProgramParameter(i, e.LINK_STATUS)) throw Error(e.getProgramInfoLog(i) || "The graphics program did not link.");
		return i;
	} catch (t) {
		throw i && e.deleteProgram(i), t;
	} finally {
		for (let t of r) e.deleteShader(t);
	}
}
function pt(e) {
	if (e.isContextLost()) return Promise.resolve();
	let t = e.fenceSync(e.SYNC_GPU_COMMANDS_COMPLETE, 0);
	return t ? (e.flush(), new Promise((n, r) => {
		let i = () => {
			if (e.isContextLost()) {
				e.deleteSync(t), n();
				return;
			}
			let a = e.clientWaitSync(t, 0, 0);
			a === e.TIMEOUT_EXPIRED ? setTimeout(i, 1) : (e.deleteSync(t), a === e.WAIT_FAILED ? (e.finish(), r(/* @__PURE__ */ Error("The graphics completion fence failed."))) : n());
		};
		i();
	})) : Promise.reject(/* @__PURE__ */ Error("The graphics completion fence could not be allocated."));
}
function Z(e, t) {
	let n = e.getError();
	if (e.isContextLost() || n !== e.NO_ERROR) throw Error(`${t} could not be allocated (${n}).`);
}
function Q(e, t, n, r) {
	let i = e.createTexture();
	if (!i) throw Error("The graphics texture could not be allocated.");
	try {
		return e.bindTexture(e.TEXTURE_2D, i), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, e.NEAREST), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, e.NEAREST), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE), e.texStorage2D(e.TEXTURE_2D, 1, r, t, n), Z(e, "The graphics texture"), i;
	} catch (t) {
		throw e.deleteTexture(i), t;
	}
}
function mt(e, t, n) {
	let r = e.createFramebuffer();
	if (!r) throw Error("The graphics framebuffer could not be allocated.");
	try {
		if (e.bindFramebuffer(e.FRAMEBUFFER, r), t.forEach((t, n) => e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + n, e.TEXTURE_2D, t, 0)), e.drawBuffers(t.map((t, n) => e.COLOR_ATTACHMENT0 + n)), n && e.framebufferRenderbuffer(e.FRAMEBUFFER, e.DEPTH_ATTACHMENT, e.RENDERBUFFER, n), e.checkFramebufferStatus(e.FRAMEBUFFER) !== e.FRAMEBUFFER_COMPLETE) throw Error("The graphics framebuffer is incomplete.");
		return Z(e, "The graphics framebuffer"), r;
	} catch (t) {
		throw e.deleteFramebuffer(r), t;
	}
}
function ht(e, t, n) {
	let r = e.createRenderbuffer();
	if (!r) throw Error("The graphics depth target could not be allocated.");
	try {
		return e.bindRenderbuffer(e.RENDERBUFFER, r), e.renderbufferStorage(e.RENDERBUFFER, e.DEPTH_COMPONENT32F, t, n), Z(e, "The graphics depth target"), r;
	} catch (t) {
		throw e.deleteRenderbuffer(r), t;
	}
}
var gt = "#version 300 es\nprecision highp float;\nvoid main() {\n  vec2 p = gl_VertexID == 0 ? vec2(-1.,-1.) : gl_VertexID == 1 ? vec2(3.,-1.) : vec2(-1.,3.);\n  gl_Position = vec4(p,0.,1.);\n}", _t = Object.freeze({
	alpha: !1,
	antialias: !1,
	depth: !1,
	stencil: !1,
	premultipliedAlpha: !1,
	preserveDrawingBuffer: !1,
	powerPreference: "high-performance"
});
function vt(e) {
	if (!e.getExtension("EXT_color_buffer_float")) return "Floating-point color targets are unavailable.";
	if (e.getParameter(e.MAX_DRAW_BUFFERS) < 4 || e.getParameter(e.MAX_COLOR_ATTACHMENTS) < 4) return "Four simultaneous color attachments are unavailable.";
	if (e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS) < 10 || e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS) < 13) return "The texture units required for reconstruction are unavailable.";
	let t = [], n = [], r, i;
	try {
		for (let n of [
			e.RGBA16F,
			e.RGBA32UI,
			e.RGBA32F,
			e.R32F
		]) t.push(Q(e, 2, 2, n));
		r = ht(e, 2, 2), n.push(mt(e, t, r)), i = ft(e, gt, "#version 300 es\nprecision highp float; precision highp int;\nlayout(location=0) out vec4 rawColor;\nlayout(location=1) out uvec4 sampleData;\nlayout(location=2) out vec4 axes;\nlayout(location=3) out float opacity;\nvoid main() { rawColor=vec4(.5,.25,.75,1.); sampleData=uvec4(16777217u,0u,0u,0u); axes=vec4(1.25,-2.5,3.75,4.); opacity=.1234567; }"), e.viewport(0, 0, 2, 2), e.disable(e.BLEND), e.disable(e.DEPTH_TEST), e.useProgram(i), e.drawArrays(e.TRIANGLES, 0, 3);
		let a = /* @__PURE__ */ new Uint32Array(4);
		e.readBuffer(e.COLOR_ATTACHMENT1), e.readPixels(0, 0, 1, 1, e.RGBA_INTEGER, e.UNSIGNED_INT, a);
		let o = /* @__PURE__ */ new Float32Array(4);
		if (e.readBuffer(e.COLOR_ATTACHMENT3), e.readPixels(0, 0, 1, 1, e.RGBA, e.FLOAT, o), e.getError() !== e.NO_ERROR || a[0] !== 16777217 || Math.abs(o[0] - .1234567) > 1e-7) return "Mixed integer/float render targets did not preserve source IDs and opacity.";
		let s = [];
		for (let n = 0; n < 4; n++) {
			let n = Q(e, 2, 2, e.RGBA32UI);
			s.push(n), t.push(n);
		}
		return n.push(mt(e, s)), null;
	} catch (e) {
		return e instanceof Error ? e.message : String(e);
	} finally {
		e.bindFramebuffer(e.FRAMEBUFFER, null), e.useProgram(null);
		for (let t of n) e.deleteFramebuffer(t);
		for (let n of t) e.deleteTexture(n);
		r && e.deleteRenderbuffer(r), i && e.deleteProgram(i);
		for (let t = 0; t < 16 && e.getError() !== e.NO_ERROR; t++);
	}
}
function yt(e) {
	if (e.isContextLost()) throw Error("The WebGL2 context was lost during initialization.");
	let t = (t) => {
		let n = e.getParameter(t);
		if (!Number.isSafeInteger(n) || n < 1) throw Error("The graphics context returned invalid resource limits.");
		return n;
	}, n = e.getParameter(e.MAX_VIEWPORT_DIMS);
	if (n.length !== 2 || Array.from(n).some((e) => !Number.isSafeInteger(e) || e < 1)) throw Error("Invalid graphics viewport limits.");
	let r = e.getExtension("WEBGL_debug_renderer_info"), i = vt(e), a = {
		maxTextureSize: t(e.MAX_TEXTURE_SIZE),
		maxRenderbufferSize: t(e.MAX_RENDERBUFFER_SIZE),
		maxViewport: [n[0], n[1]],
		maxVertexTextureUnits: t(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
		maxFragmentTextureUnits: t(e.MAX_TEXTURE_IMAGE_UNITS),
		maxCombinedTextureUnits: t(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
		maxDrawBuffers: t(e.MAX_DRAW_BUFFERS),
		maxColorAttachments: t(e.MAX_COLOR_ATTACHMENTS),
		fragmentFloatPrecision: e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT)?.precision ?? 0,
		fragmentIntPrecision: e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_INT)?.rangeMax ?? 0,
		extensions: Object.freeze([...e.getSupportedExtensions() ?? []].sort()),
		version: String(e.getParameter(e.VERSION)),
		enabledExtensions: Object.freeze([...r ? ["WEBGL_debug_renderer_info"] : [], ...e.getExtension("EXT_color_buffer_float") ? ["EXT_color_buffer_float"] : []].sort()),
		shadingLanguageVersion: String(e.getParameter(e.SHADING_LANGUAGE_VERSION)),
		vendor: String(e.getParameter(e.VENDOR)),
		renderer: String(e.getParameter(e.RENDERER)),
		unmaskedVendor: r ? String(e.getParameter(r.UNMASKED_VENDOR_WEBGL)) : null,
		unmaskedRenderer: r ? String(e.getParameter(r.UNMASKED_RENDERER_WEBGL)) : null,
		steady: i === null,
		steadyReason: i
	};
	if (a.fragmentFloatPrecision < 23 || a.fragmentIntPrecision < 30 || a.maxVertexTextureUnits < 3 || a.maxCombinedTextureUnits < 3) throw Error("The graphics context lacks the precision or texture units required for Gaussian rendering.");
	if (e.isContextLost()) throw Error("The WebGL2 context was lost during capability probing.");
	return Object.freeze(a);
}
//#endregion
//#region src/renderer/webgl2/diagnostics.ts
function bt(e, t) {
	let n = Object.freeze({
		MAX_TEXTURE_SIZE: t.maxTextureSize,
		MAX_RENDERBUFFER_SIZE: t.maxRenderbufferSize,
		MAX_VIEWPORT_WIDTH: t.maxViewport[0],
		MAX_VIEWPORT_HEIGHT: t.maxViewport[1],
		MAX_DRAW_BUFFERS: t.maxDrawBuffers,
		MAX_COLOR_ATTACHMENTS: t.maxColorAttachments,
		MAX_VERTEX_TEXTURE_IMAGE_UNITS: t.maxVertexTextureUnits,
		MAX_TEXTURE_IMAGE_UNITS: t.maxFragmentTextureUnits,
		MAX_COMBINED_TEXTURE_IMAGE_UNITS: t.maxCombinedTextureUnits
	}), r = {
		features: Object.freeze(t.enabledExtensions.slice()),
		limits: n,
		featuresUnavailableReason: null,
		limitsUnavailableReason: null
	}, i = performance.now();
	return Object.freeze({
		schemaVersion: 1,
		kind: "splatview-renderer-negotiation",
		status: "ready",
		stage: "ready",
		clock: "performance.now",
		startedAtMs: e,
		observedAtMs: i,
		clockUnavailableReason: null,
		stages: Object.freeze([{
			stage: "start",
			status: "initializing",
			atMs: e
		}, {
			stage: "ready",
			status: "ready",
			atMs: i
		}]),
		adapter: Object.freeze({
			...r,
			info: Object.freeze({
				backend: "webgl2",
				vendor: t.vendor,
				description: t.unmaskedRenderer ?? t.renderer,
				version: t.version,
				shadingLanguageVersion: t.shadingLanguageVersion
			}),
			infoUnavailableReason: t.unmaskedRenderer ? null : "Unmasked renderer identification is unavailable."
		}),
		requested: Object.freeze({
			features: Object.freeze([]),
			limits: Object.freeze({})
		}),
		device: Object.freeze(r),
		failure: null,
		gpuTimestamps: Object.freeze({
			available: !1,
			reason: "GPU timestamp queries are not instrumented. Initialization uses performance.now."
		})
	});
}
//#endregion
//#region src/renderer/webgl2/programPreparation.ts
async function xt(e, t, n = () => !0) {
	let r = [], i = [], a = () => {
		if (!n() || e.isContextLost()) throw new DOMException("Program preparation was retired.", "AbortError");
	};
	try {
		a();
		let n = e.getExtension("KHR_parallel_shader_compile");
		for (let n of t) {
			let t = e.createProgram();
			if (!t) throw Error("The graphics program could not be allocated.");
			r.push(t);
			for (let [r, a] of [[e.VERTEX_SHADER, n.vertex], [e.FRAGMENT_SHADER, n.fragment]]) {
				let n = e.createShader(r);
				if (!n) throw Error("The graphics shader could not be allocated.");
				i.push(n), e.shaderSource(n, a), e.compileShader(n), e.attachShader(t, n);
			}
			e.linkProgram(t);
		}
		if (n) for (; r.some((t) => !e.getProgramParameter(t, n.COMPLETION_STATUS_KHR));) a(), await new Promise((e) => setTimeout(e, 1));
		a();
		for (let t of r) if (!e.getProgramParameter(t, e.LINK_STATUS)) throw Error(e.getProgramInfoLog(t) || i.map((t) => e.getShaderInfoLog(t)).filter(Boolean).join("\n") || "The graphics program did not link.");
		return r;
	} catch (t) {
		for (let t of r) e.deleteProgram(t);
		throw t;
	} finally {
		for (let t of i) e.deleteShader(t);
	}
}
//#endregion
//#region src/renderer/webgl2/geometry.ts
var St = class {
	renderer;
	kind = "geometry";
	descriptor;
	vertices;
	indices;
	count;
	revision;
	contentRevision;
	retired = !1;
	uploadBytes = 0;
	retirement;
	get deviceEpoch() {
		return this.renderer.deviceEpoch;
	}
	get allocationBytes() {
		return this.descriptor.vertexBytes + this.descriptor.indexBytes;
	}
	constructor(e, t) {
		if (this.renderer = e, this.descriptor = Object.freeze(ne(t)), this.count = t.vertexCount, this.revision = t.revision, this.contentRevision = t.contentRevision, this.count > 1e7 || t.triangleCount > 1e7) throw Error("This PLY geometry exceeds the native preview budget.");
		let { gl: n } = e, r = [], i = (e, t) => {
			let i = n.createBuffer();
			if (!i) throw Error("The graphics geometry could not be allocated.");
			return r.push(i), n.bindBuffer(e, i), n.bufferData(e, t, n.STATIC_DRAW), Z(n, "The graphics geometry"), i;
		};
		try {
			this.vertices = i(n.ARRAY_BUFFER, t.vertexBytes), t.kind === 2 && (this.indices = i(n.ELEMENT_ARRAY_BUFFER, t.indexBytes));
		} catch (e) {
			for (let e of r) n.deleteBuffer(e);
			throw e;
		}
	}
	async upload(e, t, n, r, i, a, o) {
		if (this.renderer.requireScene(this), !e || ![n, r].every(Number.isSafeInteger) || n < 0 || r < 1 || n + r > a || o.byteLength > 1048576 || o.byteLength !== y(r, i)) throw Error("Invalid readonly PLY geometry upload.");
		let { gl: s } = this.renderer;
		s.bindBuffer(t, e), s.bufferSubData(t, n * i, new Uint8Array(o)), Z(s, "The geometry upload"), this.uploadBytes += o.byteLength, this.uploadBytes >= 16777216 && (await this.renderer.fence(), this.uploadBytes = 0, this.renderer.requireScene(this));
	}
	uploadVertices(e, t, n) {
		return this.upload(this.vertices, this.renderer.gl.ARRAY_BUFFER, e, t, 16, this.count, n);
	}
	uploadIndices(e, t, n) {
		return n.byteLength % 4 || new Uint32Array(n).some((e) => e >= this.count) ? Promise.reject(/* @__PURE__ */ Error("Invalid readonly PLY triangle index.")) : this.upload(this.indices, this.renderer.gl.ELEMENT_ARRAY_BUFFER, e, t, 4, this.descriptor.triangleCount * 3, n);
	}
	dispose() {
		return this.retirement ? this.retirement : (this.retired = !0, this.retirement = (async () => {
			try {
				await this.renderer.finish();
			} catch {}
			this.renderer.gl.deleteBuffer(this.vertices), this.indices && this.renderer.gl.deleteBuffer(this.indices), await this.renderer.releaseGeometryScene(this);
		})());
	}
};
//#endregion
//#region src/renderer/webgl2/sceneLayout.ts
function Ct(e, t, n, r = 2048) {
	if (y(e, t), !e || !Number.isSafeInteger(n) || n < 1) throw new g("Invalid graphics texture size.");
	let i = Math.min(e, r, n), a = Math.ceil(e / i);
	if (a > n) throw new g("This scene exceeds the WebGL2 texture limit. Load fewer splats.");
	return Object.freeze({
		width: i,
		height: a,
		entries: e,
		bytes: y(y(i, a), t)
	});
}
function wt(e, t, n) {
	let r = b(t);
	if (!Number.isSafeInteger(e) || e < 1 || e > 3e6) throw new g("This scene exceeds the current loaded-splat limit.");
	let i = Ct(y(e, r / 4), 4, n, 8192), a = Ct(e, 16, n), o = Ct(e, 4, n);
	return Object.freeze({
		stride: r,
		words: i,
		states: a,
		order: o,
		bytes: y(i.bytes + a.bytes + o.bytes + y(e, r + 1), 1)
	});
}
function Tt(e, t, n) {
	if (![e, t].every(Number.isSafeInteger) || e < 0 || t < 0 || e + t > n.entries) throw RangeError("Invalid graphics texture upload range.");
	let r = [], i = e, a = t, o = 0;
	for (; a;) {
		let e = i % n.width, t = Math.floor(i / n.width), s = e === 0 ? Math.floor(a / n.width) : 0, c = s ? n.width : Math.min(a, n.width - e), l = s || 1, u = c * l;
		r.push({
			x: e,
			y: t,
			width: c,
			height: l,
			offset: o,
			entries: u
		}), i += u, o += u, a -= u;
	}
	return r;
}
//#endregion
//#region src/renderer/webgl2/scene.ts
var Et = [
	"colorBase",
	"transformBase",
	"opacityBase"
], Dt = 0, Ot = class e {
	renderer;
	count;
	degree;
	kind = "gaussian";
	id = ++Dt;
	layout;
	words;
	order;
	residentOrder;
	residentSortPrecision = 32;
	stride;
	retired = !1;
	revision = 0;
	sourceRevision = 0;
	selectedRevision = 0;
	canonical;
	previews = {};
	previewRevisions = {
		colorBase: 0,
		transformBase: 0,
		opacityBase: 0
	};
	stateTexture;
	bindingRevision = 0;
	duplicateRange = null;
	duplicateSelected = !1;
	uploadBytes = 0;
	retirement;
	get deviceEpoch() {
		return this.renderer.deviceEpoch;
	}
	get duplicateSelectionGuarded() {
		return this.duplicateSelected;
	}
	get allocationBytes() {
		return this.layout.bytes + Object.values(this.previews).reduce((e, t) => e + t.byteLength, 0);
	}
	constructor(e, t, n) {
		this.renderer = e, this.count = t, this.degree = n, this.layout = wt(t, n, e.capabilities.maxTextureSize), this.stride = this.layout.stride, this.canonical = new Uint8Array(t);
		let { gl: r } = e, i = [];
		try {
			this.words = Q(r, this.layout.words.width, this.layout.words.height, r.R32UI), i.push(this.words), this.order = Q(r, this.layout.order.width, this.layout.order.height, r.R32UI), i.push(this.order), this.stateTexture = Q(r, this.layout.states.width, this.layout.states.height, r.RGBA32UI), i.push(this.stateTexture);
		} catch (e) {
			for (let e of i) r.deleteTexture(e);
			throw e;
		}
	}
	static async create(t, n, r) {
		t.requireScene();
		let i;
		try {
			return i = new e(t, n, r), await t.compute.request({
				action: "create",
				scene: i.id,
				count: n,
				stride: i.stride
			}), t.requireScene(), i;
		} catch (e) {
			throw i ? await i.dispose() : await t.fence().catch(() => void 0), e;
		}
	}
	snapshotMasks() {
		return {
			canonical: this.canonical,
			color: this.previews.colorBase ?? this.canonical,
			transform: this.previews.transformBase ?? this.canonical,
			opacity: this.previews.opacityBase ?? this.canonical,
			texture: this.stateTexture
		};
	}
	async upload(e, t, n) {
		if (this.renderer.requireScene(this), ![e, t].every(Number.isSafeInteger) || e < 0 || t < 1 || e + t > this.count || n.byteLength !== y(t, this.stride)) throw Error("Invalid scene upload.");
		let { gl: r } = this.renderer, i = new Uint32Array(n);
		r.bindTexture(r.TEXTURE_2D, this.words);
		for (let n of Tt(e * this.stride / 4, t * this.stride / 4, this.layout.words)) r.texSubImage2D(r.TEXTURE_2D, 0, n.x, n.y, n.width, n.height, r.RED_INTEGER, r.UNSIGNED_INT, i.subarray(n.offset, n.offset + n.entries));
		Z(r, "The packed source upload"), this.revision++, this.sourceRevision++, await this.renderer.compute.request({
			action: "upload",
			scene: this.id,
			first: e,
			count: t,
			bytes: n
		}, [n]), this.renderer.requireScene(this), this.uploadBytes += t * this.stride, this.uploadBytes >= 16777216 && (await this.renderer.fence(), this.uploadBytes = 0, this.renderer.requireScene(this));
	}
	validateMask(e) {
		if (e.byteLength !== this.count) throw Error("Invalid scene state mask.");
		let t = new Uint8Array(e);
		if (t.some((e) => e > 3)) throw Error("Invalid scene state mask.");
		return t;
	}
	publishCanonical(e) {
		let t = !1, n = !1;
		for (let r = 0; r < this.count; r++) {
			let i = e[r] ^ this.canonical[r];
			t ||= !!(i & 2), n ||= !!(i & 1);
		}
		t && this.sourceRevision++, n && this.selectedRevision++, this.canonical = e, this.updateDuplicate();
	}
	updateDuplicate() {
		let e = 0, t = 0, n = this.duplicateRange;
		if (n) for (let r = 0; r < this.count; r++) this.canonical[r] === 1 && (e++, r >= n.first && t++);
		this.duplicateSelected = !!n && e === n.count && t === n.count;
	}
	setDuplicateRange(e) {
		let t = he(e, this.count);
		ge(t, this.duplicateRange) || (this.duplicateRange = t, this.updateDuplicate());
	}
	hasPreviewMask(e) {
		return this.previews[e] !== void 0;
	}
	previewMaskRevision(e) {
		return this.previewRevisions[e];
	}
	uploadStates(e, t, n) {
		let { gl: r } = this.renderer, i = new Uint32Array(this.count * 4);
		for (let e = 0; e < this.count; e++) i.set([
			t[e],
			(n.colorBase ?? t)[e],
			(n.transformBase ?? t)[e],
			(n.opacityBase ?? t)[e]
		], e * 4);
		r.bindTexture(r.TEXTURE_2D, e);
		for (let e of Tt(0, this.count, this.layout.states)) r.texSubImage2D(r.TEXTURE_2D, 0, e.x, e.y, e.width, e.height, r.RGBA_INTEGER, r.UNSIGNED_INT, i.subarray(e.offset * 4, (e.offset + e.entries) * 4));
		Z(r, "The scene state upload");
	}
	masks(e) {
		this.renderer.requireScene(this);
		let t = this.validateMask(e), n = this.renderer.admitWork?.(this.count * 17);
		try {
			let e = t.slice();
			this.uploadStates(this.stateTexture, e, this.previews), this.publishCanonical(e), this.bindingRevision++, this.revision++;
		} finally {
			n && this.renderer.retireAfterFence(n);
		}
	}
	stageMasks(e, t = {}) {
		return this.stage(e, t);
	}
	stagePreviewMasks(e, t) {
		return this.stage(void 0, { [t]: e });
	}
	async stage(e, t) {
		this.renderer.requireScene(this);
		let n = Object.keys(t);
		if (n.some((e) => !Et.includes(e) || t[e] === void 0)) throw Error("Invalid preview mask channel.");
		e && this.validateMask(e);
		for (let e of n) t[e] !== null && this.validateMask(t[e]);
		let r = (Number(e !== void 0) + n.filter((e) => t[e] !== null).length) * this.count, i = this.renderer.admitWork?.(this.layout.states.bytes + r + this.count * 16), a = e === void 0 ? this.canonical : new Uint8Array(e).slice(), o = { ...this.previews }, s = [];
		e !== void 0 && s.push(this.canonical);
		for (let e of n) o[e] && s.push(o[e]), t[e] === null ? delete o[e] : o[e] = new Uint8Array(t[e]).slice();
		let c = this.bindingRevision, l = this.stateTexture, { gl: u } = this.renderer, d, f = !1, p = !1, m = { destroy: () => {
			u.deleteTexture(l);
			for (let e of s) e.byteLength && structuredClone(e.buffer, { transfer: [e.buffer] });
		} };
		try {
			return d = Q(u, this.layout.states.width, this.layout.states.height, u.RGBA32UI), this.uploadStates(d, a, o), {
				allocationBytes: this.layout.states.bytes + r,
				retirementBytes: this.layout.states.bytes + s.reduce((e, t) => e + t.byteLength, 0),
				retirementBuffers: [m],
				publish: () => {
					if (this.renderer.requireScene(this), f || p || c !== this.bindingRevision) throw new q("The scene masks changed before publication.");
					e !== void 0 && this.publishCanonical(a), this.stateTexture = d, this.previews = o, this.bindingRevision++, this.revision++;
					for (let e of n) this.previewRevisions[e]++;
					return f = !0, m;
				},
				dispose: async () => {
					if (!p) {
						p = !0;
						try {
							f || (await this.renderer.fence(), u.deleteTexture(d));
						} finally {
							i?.(), i = void 0;
						}
					}
				}
			};
		} catch (e) {
			throw await this.renderer.fence().catch(() => void 0), d && u.deleteTexture(d), i?.(), e;
		}
	}
	uploadOrder(e) {
		this.residentOrder = void 0;
		let { gl: t } = this.renderer;
		t.bindTexture(t.TEXTURE_2D, this.order);
		for (let n of Tt(0, this.count, this.layout.order)) t.texSubImage2D(t.TEXTURE_2D, 0, n.x, n.y, n.width, n.height, t.RED_INTEGER, t.UNSIGNED_INT, e.subarray(n.offset, n.offset + n.entries));
		Z(t, "The sorted source order upload");
	}
	dispose() {
		return this.retirement ? this.retirement : (this.retired = !0, this.retirement = (async () => {
			try {
				await this.renderer.finish();
			} catch {}
			await this.renderer.compute.request({
				action: "drop",
				scene: this.id
			}).catch(() => void 0);
			let { gl: e } = this.renderer;
			e.deleteTexture(this.words), e.deleteTexture(this.order), e.deleteTexture(this.stateTexture);
			for (let e of [this.canonical, ...Object.values(this.previews)]) e.byteLength && structuredClone(e.buffer, { transfer: [e.buffer] });
			this.previews = {};
		})());
	}
}, kt = "// Adapted from the reviewed WebGPU implementation. PlayCanvas MIT attribution:\n// docs/third-party/STEADY_SPLATS_REFERENCES.md and public/licenses/PlayCanvas-MIT.txt.\nprecision highp float;\nprecision highp int;\nprecision highp usampler2D;\nlayout(std140) uniform SteadyParameters {\n  mat4 inverseProjection; mat4 inverseView; mat4 previousViewProjection;\n  uvec4 sampleFlags; vec4 temporal; uvec4 stripe;\n};\nivec2 canonicalPixel() { return ivec2(int(gl_FragCoord.x),int(temporal.y)-1-int(gl_FragCoord.y)); }\nivec2 glPixel(ivec2 pixel) { return ivec2(pixel.x,int(temporal.y)-1-pixel.y); }\nconst ivec2 neighbors[4]=ivec2[4](ivec2(1,0),ivec2(-1,0),ivec2(0,1),ivec2(0,-1));\nfloat opacitySupport(float a) {\n  if(a>=.2141082512) return 9.;\n  if(a>=.0289764008) { if(a>=.0787660238) return a>=.1298632188 ? 8.:7.; return a>=.0477740084 ? 6.:5.; }\n  if(a>=.0106598221) return a>=.0175750755 ? 4.:3.;\n  return a>=.0064655090 ? 2.:1.;\n}\nfloat steadyAlpha(float opacity,vec2 local) {\n  float r=dot(local,local); if(r>min(9.,opacitySupport(opacity)+.001)) return 0.;\n  float alpha=min(.99,opacity*exp(-.5*r)); return alpha>=1./255. ? alpha:0.;\n}\n", At = "in vec2 local;\nflat in vec4 gaussianCenter;\nflat in vec4 gaussianAxes;\nflat in vec4 gaussianColorOpacity;\nflat in uint sourceId;\nuniform highp sampler3D noiseTexture;\nlayout(location=0) out vec4 rawColor;\nlayout(location=1) out uvec4 sampleData;\nlayout(location=2) out vec4 projectedAxes;\nlayout(location=3) out float projectedOpacity;\nuint primitivePhase(uint id) {\n  uint state=id*747796405u+2891336453u;\n  uint word=((state>>((state>>28u)+4u))^state)*277803737u;\n  return (word>>22u)^word;\n}\nvoid main() {\n  float alpha=steadyAlpha(gaussianColorOpacity.a,local); if(alpha<=0.) discard;\n  uvec2 offset=uvec2(sourceId*3242174889u,sourceId*2447445415u)>>uvec2(27u);\n  ivec3 coordinate=ivec3((uvec2(canonicalPixel())+offset)&uvec2(31u),int(sampleFlags.x&63u));\n  uint rank=uint(texelFetch(noiseTexture,coordinate,0).r*255.+.5);\n  uint rotated=(rank<<24u)+primitivePhase(sourceId)+stripe.z;\n  if(alpha<=float(rotated>>8u)*(1./16777216.)) discard;\n  rawColor=vec4(gaussianColorOpacity.rgb,1.);\n  sampleData=uvec4(sourceId,floatBitsToUint(gaussianCenter.z),floatBitsToUint(gaussianCenter.x),floatBitsToUint(gaussianCenter.y));\n  projectedAxes=gaussianAxes; projectedOpacity=gaussianColorOpacity.a;\n}\n", jt = "uniform usampler2D sampleTexture;\nuniform sampler2D axesTexture;\nuniform sampler2D opacityTexture;\nuniform usampler2D fifo0;\nuniform usampler2D fifo1;\nuniform usampler2D fifo2;\nuniform usampler2D fifo3;\nuvec4 historyEntry(ivec2 pixel,int index) {\n  if(sampleFlags.y==0u) return uvec4(0u);\n  ivec2 q=glPixel(pixel);\n  if(index==0) return texelFetch(fifo0,q,0);\n  if(index==1) return texelFetch(fifo1,q,0);\n  if(index==2) return texelFetch(fifo2,q,0);\n  return texelFetch(fifo3,q,0);\n}\nfloat alphaAt(ivec2 source,vec2 pixel) {\n  ivec2 q=glPixel(source); uvec4 sampleData=texelFetch(sampleTexture,q,0);\n  if(sampleData.x==0u) return 1.;\n  vec2 center=(uintBitsToFloat(sampleData.zw)*vec2(.5,-.5)+.5)*temporal.xy;\n  vec2 delta=(pixel-center)*vec2(1.,-1.); vec4 axes=texelFetch(axesTexture,q,0);\n  vec2 local=3.*vec2(dot(delta,axes.xy)/dot(axes.xy,axes.xy),dot(delta,axes.zw)/dot(axes.zw,axes.zw));\n  return steadyAlpha(texelFetch(opacityTexture,q,0).r,local);\n}\nvec4 adjacentAlpha(ivec2 source) {\n  vec4 values;\n  for(int n=0;n<4;n++) values[n]=alphaAt(source,vec2(source+neighbors[n])+.5);\n  return values;\n}\nvec4 outwardRatios(ivec2 p) {\n  uvec4 sampleData=texelFetch(sampleTexture,glPixel(p),0);\n  float depth=sampleData.x==0u?3.402823e38:uintBitsToFloat(sampleData.y);\n  vec4 ratio=adjacentAlpha(p)/max(alphaAt(p,vec2(p)+.5),1e-20);\n  for(int k=0;k<4;k++) {\n    uvec4 entry=historyEntry(p,k);\n    if(entry.x!=0u && entry.x!=sampleData.x && uintBitsToFloat(entry.y)<depth)\n      ratio*=vec4(unpackHalf2x16(entry.z),unpackHalf2x16(entry.w));\n  }\n  return ratio;\n}\n", Mt = "layout(location=0) out uvec4 next0;\nlayout(location=1) out uvec4 next1;\nlayout(location=2) out uvec4 next2;\nlayout(location=3) out uvec4 next3;\nvoid main() {\n  ivec2 p=canonicalPixel(); uvec4 sampleData=texelFetch(sampleTexture,glPixel(p),0);\n  uvec4 entries[4]; bool duplicate=false;\n  for(int k=0;k<4;k++) { entries[k]=historyEntry(p,k); duplicate=duplicate || (entries[k].x==sampleData.x && sampleData.x!=0u); }\n  if(sampleData.x!=0u && !duplicate) {\n    float alpha=alphaAt(p,vec2(p)+.5); vec4 occlusion=(1.-adjacentAlpha(p))/max(1.-alpha,1e-6);\n    for(int k=3;k>0;k--) entries[k]=entries[k-1];\n    entries[0]=uvec4(sampleData.xy,packHalf2x16(occlusion.xy),packHalf2x16(occlusion.zw));\n  }\n  next0=entries[0]; next1=entries[1]; next2=entries[2]; next3=entries[3];\n}\n", Nt = "uniform sampler2D rawTexture;\nuniform sampler2D previousColor;\nuniform sampler2D previousAverage;\nlayout(location=0) out vec4 nextColor;\nlayout(location=1) out vec4 nextAverage;\nvec3 ycocg(vec3 c) { return vec3(dot(c,vec3(.25,.5,.25)),(c.r-c.b)*.5,dot(c,vec3(-.25,.5,-.25))); }\nvec3 radiance(vec4 c) { return c.rgb+(1.-c.a)*temporal.w; }\nvec4 cubic(float t) {\n  float t2=t*t,t3=t2*t;\n  return vec4(-.5*t+t2-.5*t3,1.-2.5*t2+1.5*t3,.5*t+2.*t2-1.5*t3,-.5*t2+.5*t3);\n}\nvec4 historyAt(vec2 pixel) {\n  ivec2 base=ivec2(floor(pixel-.5)); vec2 fraction=fract(pixel-.5);\n  vec4 wx=cubic(fraction.x),wy=cubic(fraction.y),color=vec4(0.);\n  for(int y=0;y<4;y++) for(int x=0;x<4;x++) {\n    ivec2 q=clamp(base+ivec2(x-1,y-1),ivec2(0),ivec2(temporal.xy)-1);\n    color+=wx[x]*wy[y]*texelFetch(previousColor,glPixel(q),0);\n  }\n  return color;\n}\nvec4 temporalAt(ivec2 p,vec4 current) {\n  if(sampleFlags.y==0u || temporal.z<=0.) return current;\n  vec2 pixel=vec2(p)+.5,previousPixel=pixel; vec4 historical=texelFetch(previousColor,glPixel(p),0);\n  if(sampleFlags.z==0u) {\n    uvec4 sampleData=texelFetch(sampleTexture,glPixel(p),0);\n    vec2 ndc=pixel/temporal.xy*vec2(2.,-2.)+vec2(-1.,1.);\n    vec4 unprojected=inverseProjection*vec4(ndc,1.,1.); vec3 ray=unprojected.xyz/-unprojected.z;\n    float depth=uintBitsToFloat(sampleData.y);\n    vec4 world=inverseView*(sampleData.x!=0u?vec4(ray*depth,1.):vec4(ray,0.));\n    vec4 clip=previousViewProjection*world;\n    previousPixel=(clip.xy/max(clip.w,1e-20)*vec2(.5,-.5)+.5)*temporal.xy;\n    if(clip.w<=0. || any(lessThan(previousPixel,vec2(2.))) || any(greaterThanEqual(previousPixel,temporal.xy-2.))) return current;\n    historical=historyAt(previousPixel);\n  }\n  vec3 mean=vec3(0.),second=vec3(0.);\n  for(int y=-1;y<=1;y++) for(int x=-1;x<=1;x++) {\n    ivec2 q=clamp(p+ivec2(x,y),ivec2(0),ivec2(temporal.xy)-1);\n    vec3 value=ycocg(radiance(texelFetch(rawTexture,glPixel(q),0))); mean+=value; second+=value*value;\n  }\n  mean/=9.; vec3 sigma=sqrt(max(second/9.-mean*mean,vec3(0.)));\n  float gamma=mix(4.,1.,min(length(pixel-previousPixel)/4.,1.)); vec3 extent=max(sigma*gamma,vec3(.01,.005,.005));\n  vec3 delta=abs(ycocg(radiance(historical))-mean)/extent;\n  return mix(current,historical,temporal.z/max(1.,max(delta.x,max(delta.y,delta.z))));\n}\nvoid main() {\n  ivec2 p=canonicalPixel(); vec4 raw=texelFetch(rawTexture,glPixel(p),0),spatial=raw; float mass=1.;\n  for(int n=0;n<4;n++) {\n    ivec2 source=p-neighbors[n];\n    if(all(greaterThanEqual(source,ivec2(0))) && all(lessThan(source,ivec2(temporal.xy)))) {\n      float weight=outwardRatios(source)[n]; spatial+=texelFetch(rawTexture,glPixel(source),0)*weight; mass+=weight;\n    }\n  }\n  spatial/=mass; vec4 color=temporalAt(p,spatial),average=vec4(0.); uint frames=sampleFlags.w;\n  if(frames!=0u) {\n    vec4 sampleColor=frames<=8u?spatial:raw; average=sampleColor;\n    if(frames>1u) { average=texelFetch(previousAverage,glPixel(p),0); average+=(sampleColor-average)/float(frames); }\n    color=mix(color,average,float(frames)/(float(frames)+8.));\n  }\n  float alpha=clamp(color.a,0.,1.); vec3 rgb=color.rgb*(color.a>0.?alpha/max(color.a,1e-8):0.);\n  nextColor=vec4(rgb,alpha); nextAverage=average;\n}\n", Pt = "precision highp float;\nuniform sampler2D reconstructedColor;\nuniform float backgroundShade;\nlayout(location=0) out vec4 color;\nvoid main() {\n  vec4 value=texelFetch(reconstructedColor,ivec2(gl_FragCoord.xy),0);\n  color=vec4(value.rgb+(1.-value.a)*backgroundShade,1.);\n}\n", Ft = 65536;
function It(e, t, n) {
	if (!n.steady) throw Error(n.steadyReason ?? "SteadySplats render targets are unavailable.");
	if (![e, t].every(Number.isSafeInteger) || e < 1 || t < 1 || e > n.maxTextureSize || t > n.maxTextureSize || e > n.maxRenderbufferSize || t > n.maxRenderbufferSize || e > n.maxViewport[0] || t > n.maxViewport[1]) throw RangeError("The SteadySplats viewport exceeds the WebGL2 device limit.");
	return Object.freeze({
		width: e,
		height: t,
		bytes: y(y(e, t), 224) + Ft + 240
	});
}
//#endregion
//#region src/renderer/webgl2/steady.ts
var Lt = class {
	renderer;
	settings = Te;
	state = new Ae();
	resources;
	programs;
	desired;
	generation = 0;
	failed = !1;
	disposed = !1;
	preparation;
	previousViewProjection;
	writeIndex = 0;
	status = "sorted";
	reason = null;
	allocatedBytes = 0;
	constructor(e) {
		this.renderer = e;
	}
	get snapshot() {
		return {
			status: this.status,
			reason: this.reason,
			allocationBytes: this.allocatedBytes,
			frame: this.state.frame,
			restFrames: this.state.restFrames,
			valid: this.state.valid
		};
	}
	configure(e) {
		let t = Ee(e);
		Object.keys(t).every((e) => t[e] === this.settings[e]) || (this.settings = t, this.failed = !1, this.resetHistory(), t.mode === "sorted" ? this.suspend() : (this.generation++, this.report(this.resources ? "steady" : "preparing")));
	}
	resetHistory() {
		this.state.reset(), this.previousViewProjection = void 0, this.writeIndex = 0;
	}
	report(e, t = null) {
		this.reason = t, e !== this.status && (this.status = e, this.disposed || this.renderer.onRenderStatus?.(e));
	}
	suspend(e) {
		if ((this.desired || this.resources) && (this.generation++, this.desired = void 0, this.failed = !1, this.resetHistory(), this.resources)) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
		this.report(e && this.settings.mode === "steady" ? "unavailable" : "sorted", e ?? null);
	}
	ready(e, t) {
		if (this.disposed || this.settings.mode !== "steady") return !1;
		if (this.resources?.width === e && this.resources.height === t) return !0;
		if ((this.desired?.width !== e || this.desired.height !== t) && (this.desired = {
			width: e,
			height: t
		}, this.generation++, this.failed = !1, this.resetHistory(), this.resources)) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
		return this.prepare(), !1;
	}
	prepare() {
		if (this.preparation || this.disposed || this.failed || !this.desired || this.settings.mode !== "steady") return;
		let e = this.generation, { width: t, height: n } = this.desired;
		this.report("preparing");
		let r = this.createResources(t, n, e).then(async (t) => {
			this.disposed || e !== this.generation || this.settings.mode !== "steady" ? await this.retire(t) : (this.resources = t, this.resetHistory(), this.report("steady"));
		}).catch((t) => {
			!this.disposed && e === this.generation && (this.failed = !0, this.report("unavailable", t instanceof Error ? t.message : String(t)));
		}).finally(() => {
			this.preparation === r && (this.preparation = void 0), this.disposed || this.renderer.onFrameNeeded?.();
		});
		this.preparation = r, this.renderer.trackRetirement(r);
	}
	async createResources(e, t, n) {
		if (await this.renderer.compute.trimSortScratch(), this.disposed || n !== this.generation) throw new DOMException("Steady preparation was retired.", "AbortError");
		let { gl: r } = this.renderer, i = It(e, t, this.renderer.capabilities), a = this.renderer.admitSteady?.(i.bytes);
		this.allocatedBytes += i.bytes;
		let o = !1, s = () => {
			o || (o = !0, this.allocatedBytes -= i.bytes, a?.());
		}, c = [], l = [], u = [], d, f;
		try {
			if (!this.programs) {
				let e = await xt(r, [
					{
						vertex: "#version 300 es\n" + nt + rt,
						fragment: "#version 300 es\n" + kt + At
					},
					{
						vertex: gt,
						fragment: "#version 300 es\n" + kt + jt + Mt
					},
					{
						vertex: gt,
						fragment: "#version 300 es\n" + kt + jt + Nt
					},
					{
						vertex: gt,
						fragment: "#version 300 es\n" + Pt
					}
				], () => !this.disposed && n === this.generation);
				u.push(...e), this.programs = {
					sample: e[0],
					history: e[1],
					resolve: e[2],
					composite: e[3]
				};
			}
			let i = (n) => {
				let i = Q(r, e, t, n);
				return c.push(i), i;
			}, a = (e, t) => {
				let n = mt(r, e, t);
				return l.push(n), n;
			}, o = i(r.RGBA16F), p = i(r.RGBA32UI), m = i(r.RGBA32F), h = i(r.R32F);
			d = ht(r, e, t);
			let g = a([
				o,
				p,
				m,
				h
			], d), _ = [[], []];
			for (let e of _) for (let t = 0; t < 4; t++) e.push(i(r.RGBA32UI));
			let v = _.map((e) => a(e)), y = [i(r.RGBA16F), i(r.RGBA16F)], b = [i(r.RGBA32F), i(r.RGBA32F)], x = y.map((e, t) => a([e, b[t]])), S = r.createTexture();
			if (!S) throw Error("The sample noise could not be allocated.");
			if (c.push(S), r.activeTexture(r.TEXTURE0), r.bindTexture(r.TEXTURE_3D, S), r.texStorage3D(r.TEXTURE_3D, 1, r.R8, 32, 32, 64), r.texParameteri(r.TEXTURE_3D, r.TEXTURE_MIN_FILTER, r.NEAREST), r.texParameteri(r.TEXTURE_3D, r.TEXTURE_MAG_FILTER, r.NEAREST), r.texParameteri(r.TEXTURE_3D, r.TEXTURE_WRAP_S, r.CLAMP_TO_EDGE), r.texParameteri(r.TEXTURE_3D, r.TEXTURE_WRAP_T, r.CLAMP_TO_EDGE), r.texParameteri(r.TEXTURE_3D, r.TEXTURE_WRAP_R, r.CLAMP_TO_EDGE), r.texSubImage3D(r.TEXTURE_3D, 0, 0, 0, 0, 32, 32, 64, r.RED, r.UNSIGNED_BYTE, we()), f = r.createBuffer() ?? void 0, !f) throw Error("The sample parameters could not be allocated.");
			return r.bindBuffer(r.UNIFORM_BUFFER, f), r.bufferData(r.UNIFORM_BUFFER, 240, r.DYNAMIC_DRAW), Z(r, "The SteadySplats frame resources"), await this.renderer.fence(), {
				width: e,
				height: t,
				noise: S,
				params: f,
				raw: o,
				samples: p,
				axes: m,
				opacity: h,
				sampleTarget: g,
				histories: _,
				historyTargets: v,
				colors: y,
				averages: b,
				resolveTargets: x,
				textures: c,
				targets: l,
				depth: d,
				release: s
			};
		} catch (e) {
			await this.renderer.fence().catch(() => void 0);
			for (let e of c) r.deleteTexture(e);
			for (let e of l) r.deleteFramebuffer(e);
			d && r.deleteRenderbuffer(d), f && r.deleteBuffer(f);
			for (let e of u) r.deleteProgram(e);
			throw u.length && (this.programs = void 0), s(), e;
		} finally {
			r.bindFramebuffer(r.FRAMEBUFFER, null);
		}
	}
	retire(e) {
		return e.retirement ??= this.renderer.trackRetirement((async () => {
			try {
				await this.renderer.fence();
			} catch {} finally {
				let { gl: t } = this.renderer;
				for (let n of e.targets) t.deleteFramebuffer(n);
				for (let n of e.textures) t.deleteTexture(n);
				t.deleteRenderbuffer(e.depth), t.deleteBuffer(e.params), e.release();
			}
		})());
	}
	bind(e, t, n) {
		let { gl: r } = this.renderer;
		r.useProgram(e), this.renderer.bindFullscreen(), dt(r, e, "SteadyParameters", 1) !== r.INVALID_INDEX && r.bindBufferBase(r.UNIFORM_BUFFER, 1, t.params), n.forEach(([t, n], i) => {
			r.activeTexture(r.TEXTURE0 + i), r.bindTexture(r.TEXTURE_2D, n), ut(r, e, t, i);
		});
	}
	encode(e) {
		let t = this.resources, n = this.programs, { gl: r } = this.renderer, i = this.state.observe({
			scene: e.scene,
			revision: e.revision,
			uniform: e.words,
			shade: e.shade
		}, this.settings), a = e.values.subarray(0, 16), o = e.values.subarray(16, 32), s = Oe(o, a);
		if (i.reconstruct) {
			let c = /* @__PURE__ */ new Float32Array(60), l = new Uint32Array(c.buffer);
			c.set(ke(o)), c.set(ke(a), 16), c.set(this.previousViewProjection ?? s, 32), l.set([
				i.sampleFrame,
				Number(i.valid),
				Number(i.still),
				i.restFrames
			], 48), c.set([
				t.width,
				t.height,
				this.settings.historyWeight,
				e.shade
			], 52), l.set([
				0,
				t.height,
				Math.imul(Math.floor(i.sampleFrame / 64), 2654435769) >>> 0,
				0
			], 56), r.bindBuffer(r.UNIFORM_BUFFER, t.params), r.bufferSubData(r.UNIFORM_BUFFER, 0, c), r.bindBufferBase(r.UNIFORM_BUFFER, 1, t.params), r.bindFramebuffer(r.FRAMEBUFFER, t.sampleTarget), r.viewport(0, 0, t.width, t.height), r.disable(r.BLEND), r.disable(r.SCISSOR_TEST), r.disable(r.CULL_FACE), r.colorMask(!0, !0, !0, !0);
			let u = /* @__PURE__ */ new Float32Array(4);
			r.clearBufferfv(r.COLOR, 0, u), r.clearBufferuiv(r.COLOR, 1, /* @__PURE__ */ new Uint32Array(4)), r.clearBufferfv(r.COLOR, 2, u), r.clearBufferfv(r.COLOR, 3, u), r.enable(r.DEPTH_TEST), r.depthMask(!0), r.depthFunc(r.LEQUAL), r.clearBufferfv(r.DEPTH, 0, new Float32Array([1])), this.renderer.bindSplat(n.sample, e, !1), dt(r, n.sample, "SteadyParameters", 1), r.uniform1i(X(r, n.sample, "stochasticDepth"), 1), r.activeTexture(r.TEXTURE3), r.bindTexture(r.TEXTURE_3D, t.noise), ut(r, n.sample, "noiseTexture", 3), r.drawElementsInstanced(r.TRIANGLES, 6, r.UNSIGNED_SHORT, 0, e.scene.count), r.disable(r.DEPTH_TEST);
			let d = 1 - this.writeIndex, f = t.histories[d], p = [
				["sampleTexture", t.samples],
				["axesTexture", t.axes],
				["opacityTexture", t.opacity],
				...f.map((e, t) => [`fifo${t}`, e])
			];
			r.bindFramebuffer(r.FRAMEBUFFER, t.historyTargets[this.writeIndex]), this.bind(n.history, t, p), r.drawArrays(r.TRIANGLES, 0, 3), r.bindFramebuffer(r.FRAMEBUFFER, t.resolveTargets[this.writeIndex]), this.bind(n.resolve, t, [
				...p,
				["rawTexture", t.raw],
				["previousColor", t.colors[d]],
				["previousAverage", t.averages[d]]
			]), r.drawArrays(r.TRIANGLES, 0, 3), Z(r, "The SteadySplats reconstruction"), this.previousViewProjection = s, this.writeIndex = d;
		}
		return r.bindFramebuffer(r.FRAMEBUFFER, null), r.viewport(0, 0, t.width, t.height), r.disable(r.BLEND), r.disable(r.DEPTH_TEST), this.bind(n.composite, t, [["reconstructedColor", t.colors[1 - this.writeIndex]]]), r.uniform1f(X(r, n.composite, "backgroundShade"), e.shade), r.drawArrays(r.TRIANGLES, 0, 3), i.needsMore;
	}
	dispose() {
		if (!this.disposed && (this.disposed = !0, this.suspend(), this.generation++, this.programs)) {
			let e = this.programs;
			this.programs = void 0, this.renderer.retireAfterFence(() => {
				for (let t of Object.values(e)) this.renderer.gl.deleteProgram(t);
			});
		}
	}
}, Rt = 256, zt = 144, Bt = Rt * zt * 4, Vt = 448512, Ht = class {
	renderer;
	enabled = !1;
	disposed = !1;
	failed = !1;
	generation = 0;
	resources;
	pending;
	desired;
	sampled;
	lastStarted = -Infinity;
	timer;
	constructor(e) {
		this.renderer = e;
	}
	setEnabled(e) {
		this.enabled === e || this.disposed || (this.enabled = e, e ? this.failed && this.renderer.onHistogramUnavailable?.() : this.reset());
	}
	reset() {
		if (this.generation++, this.desired = void 0, this.sampled = void 0, this.cancelTimer(), this.resources) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
	}
	cancelTimer() {
		this.timer !== void 0 && clearTimeout(this.timer), this.timer = void 0;
	}
	requestFrame() {
		if (this.disposed || !this.enabled || this.failed || this.pending || !this.desired || this.desired === this.sampled) return;
		let e = Math.max(0, this.lastStarted + 200 - performance.now());
		e ? this.timer === void 0 && (this.timer = setTimeout(() => {
			this.timer = void 0, this.requestFrame();
		}, e)) : (this.cancelTimer(), this.renderer.onFrameNeeded?.());
	}
	retire(e) {
		this.renderer.trackRetirement((async () => {
			await this.pending, await this.renderer.fence().catch(() => void 0);
			let { gl: t } = this.renderer;
			t.deleteFramebuffer(e.target), t.deleteTexture(e.texture), t.deleteBuffer(e.readback), e.release?.();
		})());
	}
	allocate() {
		let { gl: e } = this.renderer, t = this.renderer.admitHistogram?.(Vt), n, r, i;
		try {
			if (n = Q(e, Rt, zt, e.RGBA8), r = mt(e, [n]), i = e.createBuffer() ?? void 0, !i) throw Error("The histogram readback could not be allocated.");
			return e.bindBuffer(e.PIXEL_PACK_BUFFER, i), e.bufferData(e.PIXEL_PACK_BUFFER, Bt, e.STREAM_READ), e.bindBuffer(e.PIXEL_PACK_BUFFER, null), Z(e, "The display histogram"), {
				texture: n,
				target: r,
				readback: i,
				release: t
			};
		} catch (a) {
			throw r && e.deleteFramebuffer(r), n && e.deleteTexture(n), i && e.deleteBuffer(i), t && this.renderer.retireAfterFence(t), a;
		}
	}
	observe(e, t, n) {
		if (this.disposed || !this.enabled || this.failed) return;
		if (this.desired = t, this.sampled === t) {
			this.cancelTimer();
			return;
		}
		if (this.pending) return;
		if (performance.now() - this.lastStarted < 200) {
			this.requestFrame();
			return;
		}
		this.cancelTimer();
		let r = this.generation, { gl: i } = this.renderer, a = Math.min(e.width, Rt), o = Math.min(e.height, zt), s;
		try {
			s = this.resources ??= this.allocate(), i.disable(i.SCISSOR_TEST), i.bindFramebuffer(i.READ_FRAMEBUFFER, null), i.bindFramebuffer(i.DRAW_FRAMEBUFFER, s.target), i.blitFramebuffer(0, 0, e.width, e.height, 0, 0, a, o, i.COLOR_BUFFER_BIT, i.NEAREST), i.bindFramebuffer(i.READ_FRAMEBUFFER, s.target), i.readBuffer(i.COLOR_ATTACHMENT0), i.bindBuffer(i.PIXEL_PACK_BUFFER, s.readback), i.readPixels(0, 0, a, o, i.RGBA, i.UNSIGNED_BYTE, 0), i.bindBuffer(i.PIXEL_PACK_BUFFER, null), i.bindFramebuffer(i.FRAMEBUFFER, null), Z(i, "The display histogram sampling");
		} catch {
			this.fail();
			return;
		}
		this.sampled = t, this.lastStarted = performance.now();
		let c = (async () => {
			try {
				if (await this.renderer.fence(), this.disposed || !this.enabled || r !== this.generation || this.desired !== t || e.scene.retired) return;
				let c = new Uint8Array(a * o * 4), l = /* @__PURE__ */ new Uint32Array(768);
				i.bindBuffer(i.PIXEL_PACK_BUFFER, s.readback), i.getBufferSubData(i.PIXEL_PACK_BUFFER, 0, c), i.bindBuffer(i.PIXEL_PACK_BUFFER, null), Z(i, "The display histogram readback");
				for (let e = 0; e < c.length; e += 4) l[c[e]]++, l[256 + c[e + 1]]++, l[512 + c[e + 2]]++;
				this.renderer.onHistogram?.({
					bins: l,
					width: a,
					height: o,
					frame: n,
					deviceEpoch: this.renderer.deviceEpoch
				}, e.scene);
			} catch {
				r === this.generation && this.fail();
			}
		})().finally(() => {
			this.pending === c && (this.pending = void 0), this.requestFrame();
		});
		this.pending = c;
	}
	fail() {
		if (this.failed = !0, this.cancelTimer(), this.resources) {
			let e = this.resources;
			this.resources = void 0, this.retire(e);
		}
		this.enabled && !this.disposed && this.renderer.onHistogramUnavailable?.();
	}
	dispose() {
		this.disposed || (this.disposed = !0, this.enabled = !1, this.reset());
	}
}, Ut = class e {
	canvas;
	gl;
	capabilities;
	backend = "webgl2";
	deviceEpoch = n();
	compute;
	negotiationSnapshot;
	sorted;
	geometry;
	frameBuffer;
	emptyVao;
	geometryVao;
	quadIndices;
	displayCheckpoint;
	queries = /* @__PURE__ */ new Set();
	queryCancellations = /* @__PURE__ */ new Map();
	tail = Promise.resolve();
	retiring = /* @__PURE__ */ new Set();
	displayRequest = 0;
	submission = 0;
	disposed = !1;
	prepared;
	queryRevision = 0;
	opacityRevision = 0;
	preparedOpacityRevision = -1;
	depthTarget;
	steady;
	histogram;
	histogramDisplay;
	opacityScale = 1;
	opacitySelectedOnly = !1;
	lost = !1;
	admitSortScratch;
	admitWork;
	admitGeometryDepth;
	admitHistogram;
	admitSteady;
	onHistogram;
	onHistogramUnavailable;
	onRenderStatus;
	onFrameNeeded;
	onLost;
	onDeviceLost;
	contextLost = (e) => {
		e.preventDefault(), !(this.disposed || this.lost) && (this.lost = !0, this.compute.close("The graphics context was lost."), this.onDeviceLost?.("The WebGL2 context was lost. Your edits are retained."));
	};
	constructor(e, t, n, r, i, a) {
		this.canvas = e, this.gl = t, this.capabilities = n;
		let o = [], s = [], c = [];
		try {
			this.sorted = a[0], o.push(this.sorted), this.geometry = a[1], o.push(this.geometry);
			let e = t.createBuffer();
			if (!e) throw Error("The graphics frame could not be allocated.");
			s.push(e), this.frameBuffer = e, t.bindBuffer(t.UNIFORM_BUFFER, e), t.bufferData(t.UNIFORM_BUFFER, 320, t.DYNAMIC_DRAW), dt(t, this.sorted, "GaussianFrame", 0);
			let n = () => {
				let e = t.createVertexArray();
				if (!e) throw Error("The graphics vertex state could not be allocated.");
				return c.push(e), e;
			};
			this.emptyVao = n(), this.geometryVao = n();
			let r = t.createBuffer();
			if (!r) throw Error("The quad indices could not be allocated.");
			s.push(r), this.quadIndices = r, t.bindVertexArray(this.emptyVao), t.bindBuffer(t.ELEMENT_ARRAY_BUFFER, r), t.bufferData(t.ELEMENT_ARRAY_BUFFER, new Uint16Array([
				0,
				1,
				2,
				2,
				1,
				3
			]), t.STATIC_DRAW), Z(t, "The graphics programs"), this.compute = i;
		} catch (e) {
			for (let e of o) t.deleteProgram(e);
			for (let e of s) t.deleteBuffer(e);
			for (let e of c) t.deleteVertexArray(e);
			throw e;
		}
		this.negotiationSnapshot = bt(r, n), this.steady = new Lt(this), this.histogram = new Ht(this), this.compute.onFailure = (e) => {
			!this.disposed && !this.lost && (this.lost = !0, this.onLost?.(e));
		}, e.addEventListener("webglcontextlost", this.contextLost);
	}
	static async create(t, n, r) {
		let a = performance.now(), o = t.getContext("webgl2", _t);
		if (!o) throw Error("WebGL2 is unavailable on this canvas.");
		i(t, "webgl2");
		let s = yt(o), c = await n(), l;
		try {
			let n = await xt(o, [{
				vertex: "#version 300 es\n" + nt + rt,
				fragment: "#version 300 es\n" + it
			}, {
				vertex: "#version 300 es\n" + at,
				fragment: "#version 300 es\n" + ot
			}]);
			l = new e(t, o, s, a, c, n);
		} catch (e) {
			throw c.close(), e;
		}
		try {
			return await l.compute.barrier(), l.requireScene(), r?.(l.negotiationSnapshot), l;
		} catch (e) {
			throw l.dispose(), e;
		}
	}
	get frameSubmissionSequence() {
		return this.submission;
	}
	get steadySnapshot() {
		return this.steady.snapshot;
	}
	requireScene(e) {
		if (this.disposed || this.lost || this.gl.isContextLost()) throw new q("The graphics device is unavailable. Your edits are retained.");
		if (e && (e.renderer !== this || e.deviceEpoch !== this.deviceEpoch || e.retired || !(e instanceof Ot || e instanceof St))) throw new q("The scene belongs to a retired graphics owner.");
	}
	run(e) {
		let t = this.tail.then(e);
		return this.tail = t.catch(() => void 0), t;
	}
	fence() {
		return pt(this.gl);
	}
	retireAfterFence(e) {
		let t = this.fence().catch(() => void 0).finally(() => {
			e(), this.retiring.delete(t);
		});
		return this.retiring.add(t), t;
	}
	trackRetirement(e) {
		return this.retiring.add(e), e.finally(() => this.retiring.delete(e)).catch(() => void 0), e;
	}
	displayCompletion() {
		return this.displayCheckpoint;
	}
	runQuery(e) {
		let t = e();
		return this.queries.add(t), t.finally(() => this.queries.delete(t)).catch(() => void 0), t;
	}
	async finish() {
		await this.tail, await Promise.allSettled([...this.queries]), !this.disposed && !this.lost && await this.compute.barrier(), await this.fence(), await Promise.allSettled([...this.retiring]);
	}
	allocateScene(e, t) {
		return Ot.create(this, e, Math.min(t, 3));
	}
	async allocateGeometry(e) {
		this.requireScene();
		try {
			return new St(this, e);
		} catch (e) {
			throw await this.fence().catch(() => void 0), e;
		}
	}
	prepareSurfaceResources() {
		return this.compute.barrier();
	}
	trimSurfaceResources() {
		this.compute.trimSortScratch().catch(() => void 0);
	}
	setOpacityPreview(e, t) {
		if (!Number.isFinite(e) || e < 0 || e > 5) throw RangeError("Opacity scale must be between 0 and 5.");
		e = Math.fround(e), t = e !== 1 && t, (e !== this.opacityScale || t !== this.opacitySelectedOnly) && (this.opacityScale = e, this.opacitySelectedOnly = t, this.opacityRevision++);
	}
	setRenderSettings(e) {
		this.steady.configure(e);
	}
	resetRenderHistory() {
		this.steady.resetHistory(), this.onFrameNeeded?.();
	}
	setHistogramEnabled(e) {
		this.histogram.setEnabled(e);
	}
	resetHistogram() {
		this.histogramDisplay = void 0, this.histogram.reset();
	}
	dimensions(e, t) {
		if (V(e, t), e > this.capabilities.maxTextureSize || t > this.capabilities.maxTextureSize || e > this.capabilities.maxViewport[0] || t > this.capabilities.maxViewport[1]) throw RangeError("The viewport exceeds the graphics device limit.");
		if (this.gl.drawingBufferWidth !== e || this.gl.drawingBufferHeight !== t) throw Error("The graphics drawing buffer did not preserve the requested viewport.");
	}
	frame(e, t, n, r, i, a, o, s, c) {
		let l = this.canvas.width, u = this.canvas.height;
		this.dimensions(l, u);
		let d = {
			view: new Float32Array(t.view),
			projection: new Float32Array(t.projection),
			eye: new Float32Array(t.eye),
			revision: t.revision,
			background: t.background
		}, f = e.kind === "gaussian" ? Xe(e, d, n, r, i, a, l, u, o, s, c) : void 0;
		return Object.freeze({
			scene: e,
			revision: e.revision,
			camera: d,
			width: l,
			height: u,
			shade: Ze(d.background),
			values: f?.values,
			words: f?.words,
			masks: e.kind === "gaussian" ? e.snapshotMasks() : void 0
		});
	}
	current(e, t = !1) {
		if (this.requireScene(e.scene), e.scene.revision !== e.revision || t && (this.canvas.width !== e.width || this.canvas.height !== e.height)) throw new q("The captured scene or viewport changed.");
	}
	sortPrecision = 32;
	get displaySortPrecision() {
		return this.sortPrecision ?? 32;
	}
	set displaySortPrecision(e) {
		let t = f(e);
		this.displaySortPrecision !== t && (this.sortPrecision = t, this.onFrameNeeded?.());
	}
	async sortedOrder(e, t, n = this.displaySortPrecision) {
		let r = e.scene;
		if (r.kind !== "gaussian" || (r.count < 2048 && (n = 32), this.current(e), (r.residentSortPrecision ?? 32) >= n && s(r.residentOrder, e.words, r.sourceRevision, e.masks.transform))) return;
		let i = c(e.words, r.sourceRevision, e.masks.transform), a = await this.compute.acquireSortScratch(r.count, this.admitSortScratch ?? this.admitWork), o;
		try {
			this.current(e);
			try {
				o = this.admitWork?.(y(r.count, a ? 5 : 17) + 320 + (a ? 0 : 1024));
			} catch (t) {
				if (!a) throw t;
				a(), a = void 0, await this.compute.trimSortScratch(), this.current(e), o = this.admitWork?.(y(r.count, 17) + 320 + 1024);
			}
			let s = e.values.slice().buffer, c = e.masks.transform.slice().buffer, l = await this.compute.request({
				action: "sort",
				scene: r.id,
				frame: s,
				transformTargets: c,
				precision: n
			}, [s, c], t);
			this.current(e), r.uploadOrder(new Uint32Array(l.order)), r.residentOrder = i, r.residentSortPrecision = n;
		} finally {
			a?.(), o && this.retireAfterFence(o);
		}
	}
	bindSplat(e, t, n) {
		let r = t.scene;
		if (r.kind !== "gaussian") throw Error("Expected Gaussian frame.");
		let { gl: i } = this;
		i.useProgram(e), i.bindVertexArray(this.emptyVao), i.bindBuffer(i.UNIFORM_BUFFER, this.frameBuffer), i.bufferSubData(i.UNIFORM_BUFFER, 0, t.values), i.bindBufferBase(i.UNIFORM_BUFFER, 0, this.frameBuffer), dt(i, e, "GaussianFrame", 0), [
			[r.words, "wordsTexture"],
			[t.masks.texture, "statesTexture"],
			[r.order, "orderTexture"]
		].forEach(([t, n], r) => {
			i.activeTexture(i.TEXTURE0 + r), i.bindTexture(i.TEXTURE_2D, t), ut(i, e, n, r);
		}), i.uniform1i(X(i, e, "useOrder"), Number(n)), i.uniform1i(X(i, e, "stochasticDepth"), 0);
	}
	bindFullscreen() {
		this.gl.bindVertexArray(this.emptyVao);
	}
	drawSorted(e, t) {
		let { gl: n } = this;
		n.bindFramebuffer(n.FRAMEBUFFER, t), n.viewport(0, 0, e.width, e.height), n.disable(n.SCISSOR_TEST), n.disable(n.DEPTH_TEST), n.disable(n.CULL_FACE), n.colorMask(!0, !0, !0, !0), n.clearColor(e.shade, e.shade, e.shade, 1), n.clear(n.COLOR_BUFFER_BIT), this.bindSplat(this.sorted, e, !0), n.enable(n.BLEND), n.blendEquation(n.FUNC_ADD), n.blendFunc(n.ONE, n.ONE_MINUS_SRC_ALPHA), n.drawElementsInstanced(n.TRIANGLES, 6, n.UNSIGNED_SHORT, 0, e.scene.count), n.disable(n.BLEND), Z(n, "The sorted display submission");
	}
	drawGeometry(e, t) {
		let n = e.scene;
		if (n.kind !== "geometry") throw Error("Expected geometry frame.");
		let { gl: r } = this, i = this.geometry, a = n.descriptor.kind === 2;
		r.bindFramebuffer(r.FRAMEBUFFER, t), r.viewport(0, 0, e.width, e.height), r.disable(r.SCISSOR_TEST), r.disable(r.BLEND), r.disable(r.CULL_FACE), r.enable(r.DEPTH_TEST), r.depthFunc(r.LESS), r.depthMask(!0), r.clearColor(e.shade, e.shade, e.shade, 1), r.clearDepth(1), r.clear(r.COLOR_BUFFER_BIT | r.DEPTH_BUFFER_BIT), r.useProgram(i), r.bindVertexArray(this.geometryVao), r.bindBuffer(r.ARRAY_BUFFER, n.vertices), r.enableVertexAttribArray(0), r.vertexAttribPointer(0, 3, r.FLOAT, !1, 16, 0), r.vertexAttribDivisor(0, +!a), r.enableVertexAttribArray(1), r.vertexAttribPointer(1, 4, r.UNSIGNED_BYTE, !0, 16, 12), r.vertexAttribDivisor(1, +!a), r.uniformMatrix4fv(X(r, i, "geometryView"), !1, e.camera.view), r.uniformMatrix4fv(X(r, i, "geometryProjection"), !1, e.camera.projection), r.uniform3f(X(r, i, "geometryViewport"), e.width, e.height, Math.max(1.3, Math.min(3, Math.min(e.width, e.height) / 160))), r.uniform1i(X(r, i, "mesh"), Number(a)), a ? (r.bindBuffer(r.ELEMENT_ARRAY_BUFFER, n.indices), r.drawElements(r.TRIANGLES, n.descriptor.triangleCount * 3, r.UNSIGNED_INT, 0)) : r.drawArraysInstanced(r.TRIANGLES, 0, 6, n.count), r.bindVertexArray(this.emptyVao), r.disable(r.DEPTH_TEST), Z(r, "The PLY display submission");
	}
	createTarget(e, t, n, r = !0) {
		let { gl: i } = this, a, o, s;
		try {
			return a = Q(i, e, t, i.RGBA8), r && (o = ht(i, e, t)), s = mt(i, [a], o), {
				width: e,
				height: t,
				color: a,
				depth: o,
				target: s,
				release: n
			};
		} catch (e) {
			throw s && i.deleteFramebuffer(s), o && i.deleteRenderbuffer(o), a && i.deleteTexture(a), n && this.retireAfterFence(n), e;
		}
	}
	retireTarget(e) {
		return this.retireAfterFence(() => {
			this.gl.deleteFramebuffer(e.target), this.gl.deleteTexture(e.color), e.depth && this.gl.deleteRenderbuffer(e.depth), e.release?.();
		});
	}
	releaseGeometryScene(e) {
		if (this.prepared?.scene === e && (this.prepared = void 0), this.prepared?.scene.kind !== "geometry" && this.depthTarget) {
			let e = this.depthTarget;
			return this.depthTarget = void 0, this.retireTarget(e);
		}
		return Promise.resolve();
	}
	render(e, t, n = L, r = !0, i = R, a = !1, o = a, s = 1, c = !1) {
		this.requireScene(e);
		let l = ++this.displayRequest, u = e ? this.frame(e, t, n, r, i, a, o, s, c) : void 0, d = this.canvas.width, f = this.canvas.height, p = Ze(t.background);
		for (let [e, t] of this.queryCancellations) t(u) || e.abort();
		return this.run(async () => {
			if (l !== this.displayRequest || this.disposed || this.lost) return;
			if (this.requireScene(), u) {
				try {
					this.current(u, !0);
				} catch (e) {
					if (e instanceof q) return;
					throw e;
				}
				if (u.scene.kind === "gaussian") {
					if (this.depthTarget) {
						let e = this.depthTarget;
						this.depthTarget = void 0, this.retireTarget(e);
					}
					let e = De(u.camera.projection);
					if (e || this.steady.suspend("SteadySplats requires a supported perspective projection."), e && this.steady.ready(d, f)) this.setOpacityPreview(s, c), this.steady.encode(u) && this.onFrameNeeded?.();
					else {
						try {
							await this.sortedOrder(u);
						} catch (e) {
							if (e instanceof q) return;
							throw e;
						}
						try {
							this.current(u, !0);
						} catch (e) {
							if (e instanceof q) return;
							throw e;
						}
						this.setOpacityPreview(s, c), this.drawSorted(u, null);
					}
				} else {
					if (this.steady.suspend("SteadySplats requires a Gaussian scene."), !this.depthTarget || this.depthTarget.width !== d || this.depthTarget.height !== f) {
						let e = this.createTarget(d, f, this.admitGeometryDepth?.(y(d * f, 8))), t = this.depthTarget;
						this.depthTarget = e, t && this.retireTarget(t);
					}
					this.drawGeometry(u, this.depthTarget.target);
					let { gl: e } = this;
					e.bindFramebuffer(e.READ_FRAMEBUFFER, this.depthTarget.target), e.bindFramebuffer(e.DRAW_FRAMEBUFFER, null), e.blitFramebuffer(0, 0, d, f, 0, 0, d, f, e.COLOR_BUFFER_BIT, e.NEAREST), e.bindFramebuffer(e.FRAMEBUFFER, null);
				}
				(!this.prepared || this.prepared.scene !== u.scene || this.prepared.revision !== u.revision || !u.words || u.words.some((e, t) => e !== this.prepared?.words?.[t])) && this.queryRevision++, this.prepared = u, this.preparedOpacityRevision = this.opacityRevision;
			} else {
				if (this.depthTarget) {
					let e = this.depthTarget;
					this.depthTarget = void 0, this.retireTarget(e);
				}
				this.steady.suspend("SteadySplats requires a Gaussian scene.");
				let { gl: e } = this;
				e.bindFramebuffer(e.FRAMEBUFFER, null), e.viewport(0, 0, d, f), e.clearColor(p, p, p, 1), e.clear(e.COLOR_BUFFER_BIT), this.prepared = void 0;
			}
			Z(this.gl, "The graphics display submission"), this.gl.flush();
			let e = this.fence();
			if (e.catch(() => void 0), this.displayCheckpoint = {
				deviceEpoch: this.deviceEpoch,
				submissionSequence: this.submission + 1,
				done: e
			}, this.submission++, this.canvas.dataset.frames = String(this.submission), u?.scene.kind === "gaussian") {
				let e = this.histogramDisplay, t = this.steady.snapshot.frame;
				(!e || e.frame.scene !== u.scene || e.frame.revision !== u.revision || e.frame.camera.revision !== u.camera.revision || e.frame.width !== u.width || e.frame.height !== u.height || e.frame.shade !== u.shade || e.steadyFrame !== t || u.words.some((t, n) => t !== e.frame.words?.[n])) && (this.histogramDisplay = {
					frame: u,
					steadyFrame: t,
					identity: {}
				}), this.histogram.observe(u, this.histogramDisplay.identity, this.submission);
			} else this.histogramDisplay && this.resetHistogram();
		});
	}
	queryFrame(e) {
		this.requireScene(e);
		let t = this.prepared;
		if (!t || t.scene !== e || t.revision !== e.revision || !t.words || this.preparedOpacityRevision !== this.opacityRevision) throw new q("Prepare the current scene before querying it.");
		return this.current(t, !0), t;
	}
	surfaceSnapshot(e) {
		let t = this.queryFrame(e), n = e.sourceRevision, r = e.selectedRevision, i = this.opacityRevision, a = (e) => [
			...e.subarray(0, 42),
			e[59],
			...e.subarray(60, 77),
			e[76] ? e[77] : 0,
			e[79]
		], o = a(t.words), s = t.words[76] !== 0 && t.words[77] !== 0, c = (t.words[79] & 3) == 3, l = e.previewMaskRevision("transformBase"), u = e.previewMaskRevision("opacityBase"), d = () => {
			this.requireScene(e);
			let d = this.prepared, f = d?.words ? a(d.words) : [];
			if (d?.scene !== e || e.sourceRevision !== n || this.opacityRevision !== i || this.preparedOpacityRevision !== i || (s || c) && e.selectedRevision !== r || s && e.previewMaskRevision("transformBase") !== l || c && e.previewMaskRevision("opacityBase") !== u || this.canvas.width !== t.width || this.canvas.height !== t.height || o.some((e, t) => e !== f[t])) throw new q("The surface geometry, view, viewport or source membership changed.");
		};
		return d(), {
			frame: t,
			check: d
		};
	}
	queryCancellation(e, t) {
		let n = e.scene, r = n.sourceRevision, i = n.selectedRevision, a = n.previewMaskRevision("transformBase"), o = n.previewMaskRevision("opacityBase"), s = e.words, c = !!s[76] && !!s[77], l = (s[79] & 3) == 3, u = new AbortController(), d = () => u.abort(t?.reason);
		return t?.aborted ? d() : t?.addEventListener("abort", d, { once: !0 }), this.queryCancellations.set(u, (t) => {
			if (t?.scene !== n || t.width !== e.width || t.height !== e.height || n.sourceRevision !== r || (c || l) && n.selectedRevision !== i || c && n.previewMaskRevision("transformBase") !== a || l && n.previewMaskRevision("opacityBase") !== o) return !1;
			let u = t.words;
			for (let e = 0; e < 42; e++) if (s[e] !== u[e]) return !1;
			if (s[59] !== u[59] || s[79] !== u[79]) return !1;
			for (let e = 60; e < 78; e++) if (s[e] !== u[e]) return !1;
			return !0;
		}), {
			signal: u.signal,
			dispose: () => {
				t?.removeEventListener("abort", d), this.queryCancellations.delete(u);
			}
		};
	}
	queryInputs(e) {
		return {
			frame: e.values.slice().buffer,
			canonical: e.masks.canonical.slice().buffer,
			transform: e.masks.transform.slice().buffer,
			opacity: e.masks.opacity.slice().buffer
		};
	}
	async pick(e, t, n, r = 0) {
		let i = this.queryFrame(e), a = this.queryRevision, o = this.opacityRevision;
		if (![
			t,
			n,
			r
		].every(Number.isFinite) || r < 0 || t < 0 || n < 0 || t >= i.width || n >= i.height) return {
			index: null,
			depth: 0,
			opacity: 0,
			contribution: 0,
			deviceEpoch: this.deviceEpoch
		};
		t = Math.fround(Math.floor(t) + .5), n = Math.fround(Math.floor(n) + .5), r = Math.fround(r);
		let s = () => {
			if (this.current(i, !0), this.queryRevision !== a || this.prepared?.scene !== e || o !== this.opacityRevision || this.preparedOpacityRevision !== o) throw new q("The rendered view, viewport or scene changed before the query completed.");
		};
		return this.runQuery(async () => {
			s();
			let a = this.admitWork?.(y(e.count, 67) + 320 + 65536), o = this.queryCancellation(i);
			try {
				let a = this.queryInputs(i), c = await this.compute.request({
					action: "pick",
					scene: e.id,
					...a,
					x: t,
					y: n,
					radius: r
				}, Object.values(a), o.signal);
				return s(), {
					...c.pick,
					deviceEpoch: this.deviceEpoch
				};
			} finally {
				o.dispose(), a?.();
			}
		});
	}
	async surface(e, t) {
		let { frame: n, check: r } = this.surfaceSnapshot(e), i = () => {
			t.signal?.throwIfAborted(), r();
		}, { width: a, height: o, scale: s } = He(n.width, n.height), c = Ue(t, a, o), l = a * o, u = a !== n.width || o !== n.height, d = (e) => {
			if (!Number.isInteger(e) || e < 1 || e > 65536 || e & e - 1) throw RangeError("Surface tile capacity must be a power of two between 1 and 65536.");
			return e;
		}, f = t.initialTileCapacity === void 0 ? void 0 : d(t.initialTileCapacity), p = t.maxTileCapacity === void 0 ? void 0 : d(t.maxTileCapacity);
		if (f !== void 0 && p !== void 0 && f > p) throw RangeError("Initial surface tile capacity exceeds its explicit query limit.");
		let m = y(l, t.colors ? 20 : 8) + (t.visible ? Math.ceil(e.count / 32) * 4 : 0), h = Math.ceil(a / 16) * Math.ceil(o / 16), g = y(e.count, 51 + (t.visible ? 4 : 0) + (t.visible && u ? 48 : 0)) + y(h, 12) + 320 + 48 + 65536;
		i();
		let _ = t.admit(m + g), v = !1;
		return this.runQuery(async () => {
			let l = this.queryCancellation(n, t.signal);
			try {
				i();
				let d = this.queryInputs(n), f = Ge({
					fullWidth: n.width,
					fullHeight: n.height,
					width: a,
					height: o,
					sourceCount: e.count,
					channelFlags: We(t, u),
					dispatchWidth: 1,
					scale: s,
					region: c
				}).buffer, h = await this.compute.request({
					action: "surface",
					scene: e.id,
					...d,
					parameters: f,
					maximum: p
				}, [...Object.values(d), f], l.signal, (e) => {
					i(), _.resize(m + g + y(e, 1));
				});
				i();
				let b = h.surface, x = new Float32Array(b.depths), S = new Float32Array(b.opacities), C = b.colors ? new Float32Array(b.colors) : void 0, w = b.visible ? new Uint32Array(b.visible) : void 0;
				_.resize(m);
				let T = !1, E = Object.freeze({
					width: a,
					height: o,
					fullWidth: n.width,
					fullHeight: n.height,
					depths: x,
					opacities: S,
					colors: C,
					visible: w,
					region: c,
					deviceEpoch: this.deviceEpoch,
					attempts: 1,
					allocationBytes: m + g + b.candidateBytes + b.sortScratchBytes,
					candidateBytes: b.candidateBytes,
					candidateEntries: b.candidateEntries,
					tileCapacity: b.tileCapacity,
					tileCount: b.tileCount,
					occupiedTiles: b.occupiedTiles,
					sortComparisons: b.sortComparisons,
					assertCurrent: () => {
						if (T) throw new q("The surface map was disposed.");
						r();
					},
					dispose: () => {
						if (!T) {
							T = !0;
							for (let e of [
								x,
								S,
								C,
								w
							]) e?.byteLength && structuredClone(e.buffer, { transfer: [e.buffer] });
							_();
						}
					}
				});
				return v = !0, E;
			} finally {
				l.dispose(), v || _();
			}
		});
	}
	captureRgba(e, t, n, r = L, i = R, a = !1, o = a, s = 1, c = !1) {
		this.requireScene(e);
		let l = this.frame(e, t, [...r], !1, [...i], a, o, s, c), u = () => {
			n.signal?.throwIfAborted(), n.current?.(), this.current(l);
		};
		u();
		let d = V(l.width, l.height), f = n.admit(d);
		return this.run(async () => {
			let t, r, i, a, o = !1, s = !1, { gl: c } = this;
			try {
				if (u(), t = n.admit(y(d, e.kind === "geometry" ? 4 : 3)), o = !0, r = this.createTarget(l.width, l.height, void 0, e.kind === "geometry"), i = c.createBuffer() ?? void 0, !i) throw Error("The image readback could not be allocated.");
				e.kind === "gaussian" ? (await this.sortedOrder(l, n.signal, 32), u(), this.drawSorted(l, r.target)) : this.drawGeometry(l, r.target), c.bindFramebuffer(c.READ_FRAMEBUFFER, r.target), c.readBuffer(c.COLOR_ATTACHMENT0), c.bindBuffer(c.PIXEL_PACK_BUFFER, i), c.bufferData(c.PIXEL_PACK_BUFFER, d, c.STREAM_READ), c.readPixels(0, 0, l.width, l.height, c.RGBA, c.UNSIGNED_BYTE, 0), c.bindBuffer(c.PIXEL_PACK_BUFFER, null), Z(c, "The image readback"), await this.fence(), s = !0, u();
				let p = new Uint8Array(d);
				c.bindBuffer(c.PIXEL_PACK_BUFFER, i), c.getBufferSubData(c.PIXEL_PACK_BUFFER, 0, p), c.bindBuffer(c.PIXEL_PACK_BUFFER, null), a = new Uint8ClampedArray(d);
				for (let e = 0; e < l.height; e++) a.set(p.subarray((l.height - 1 - e) * l.width * 4, (l.height - e) * l.width * 4), e * l.width * 4);
				u();
				let m = ae(l.width, l.height, a, f);
				return f = void 0, m;
			} finally {
				o && !s && await this.fence().catch(() => void 0), c.bindBuffer(c.PIXEL_PACK_BUFFER, null), i && c.deleteBuffer(i), r && (c.deleteFramebuffer(r.target), c.deleteTexture(r.color), r.depth && c.deleteRenderbuffer(r.depth)), t?.(), f?.(), f = void 0;
			}
		});
	}
	async capture(e, t, n = "image/png", r = L, i = R, a = !1, o = a, s = 1, c = !1) {
		if (n !== "image/png" && n !== "image/jpeg") throw Error("Unsupported capture image type.");
		let l = { admit: () => () => void 0 }, u = await this.captureRgba(e, t, l, r, i, a, o, s, c);
		try {
			let e = await U(u, n, l);
			try {
				return e.blob;
			} finally {
				e.dispose();
			}
		} finally {
			u.dispose();
		}
	}
	async close() {
		for (this.dispose(), await Promise.allSettled([this.tail, ...this.queries]); this.retiring.size;) await Promise.allSettled([...this.retiring]);
	}
	dispose() {
		if (!this.disposed) {
			this.disposed = !0, this.displayRequest++;
			for (let e of this.queryCancellations.keys()) e.abort();
			this.steady.dispose(), this.histogram.dispose(), this.canvas.removeEventListener("webglcontextlost", this.contextLost), this.compute.close(), this.depthTarget &&= (this.retireTarget(this.depthTarget), void 0), this.retireAfterFence(() => {
				this.gl.deleteProgram(this.sorted), this.gl.deleteProgram(this.geometry), this.gl.deleteBuffer(this.frameBuffer), this.gl.deleteBuffer(this.quadIndices), this.gl.deleteVertexArray(this.emptyVao), this.gl.deleteVertexArray(this.geometryVao);
			});
		}
	}
};
//#endregion
//#region src/renderer/factory.ts
async function Wt(t, n) {
	let r = e(n.preference), i = n.recoveryBackend ?? (r === "auto" ? "webgpu" : r), o = f(n.sortPrecision ?? 32), s = (e) => (e.displaySortPrecision = o, e), c = t, l = async () => {
		if (!n.replaceCanvas) throw Error("A new presentation canvas is required to restore graphics. Your document is retained.");
		let e = await n.replaceCanvas(c);
		if (e === c || a(e)) throw Error("The replacement graphics canvas is already in use.");
		c = e;
	};
	if (a(c) && (a(c) !== i || i === "webgl2") && await l(), i === "webgl2") return s(await Ut.create(c, n.createCompute, n.observe));
	try {
		return s(await tt.create(c, n.observe));
	} catch (e) {
		if (n.recoveryBackend || r !== "auto" || !n.allowFallback) throw e;
		let t = e instanceof Error ? e.message : String(e);
		return n.fallback?.(t), a(c) && await l(), s(await Ut.create(c, n.createCompute, n.observe));
	}
}
//#endregion
//#region src/build/contracts.ts
var Gt = [
	"html",
	"application-entry",
	"document-worker",
	"core-glue",
	"core-wasm",
	"camera-glue",
	"camera-wasm",
	"build-provenance"
], Kt = /^[a-f0-9]{64}$/;
[...Gt];
var $ = (e) => /* @__PURE__ */ Error(`SplatView could not verify this build: ${e} Reload after the site finishes updating.`);
function qt(e, t) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw $(`invalid ${t}.`);
	return e;
}
function Jt(e, t, n) {
	if (Object.keys(e).some((e) => !t.includes(e))) throw $(`unexpected ${n} field.`);
}
function Yt(e) {
	return Number.isSafeInteger(e) && Number(e) > 0;
}
function Xt(e) {
	if (e === null || typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isFinite(e)) return JSON.stringify(e);
	if (Array.isArray(e)) return `[${e.map(Xt).join(",")}]`;
	if (typeof e == "object" && Object.getPrototypeOf(e) === Object.prototype) return `{${Object.keys(e).sort().map((t) => `${JSON.stringify(t)}:${Xt(e[t])}`).join(",")}}`;
	throw $("invalid canonical data.");
}
function Zt(e) {
	let t = qt(e, "native identity");
	if (Jt(t, [
		"schemaVersion",
		"kind",
		"abi",
		"variant",
		"nativeInputId",
		"mapLayoutVersion",
		"capabilities"
	], "native identity"), t.schemaVersion !== 1 || !["core", "camera"].includes(String(t.kind)) || !Yt(t.abi) || t.variant !== "scalar" || typeof t.nativeInputId != "string" || !Kt.test(t.nativeInputId)) throw $("invalid native identity.");
	if (t.kind === "core" && !Yt(t.mapLayoutVersion) || t.kind === "camera" && t.mapLayoutVersion !== void 0) throw $("invalid native map layout.");
	let n = qt(t.capabilities, "native capabilities");
	if (!Object.keys(n).length || Object.entries(n).some(([e, t]) => !/^[a-zA-Z][a-zA-Z0-9]*$/.test(e) || !Yt(t))) throw $("invalid native capabilities.");
	return t;
}
function Qt(e) {
	let t = qt(e, "application identity");
	if (Jt(t, [
		"schemaVersion",
		"appInputId",
		"protocolVersion",
		"uiWorkerContract",
		"native"
	], "application identity"), t.schemaVersion !== 1 || typeof t.appInputId != "string" || !Kt.test(t.appInputId) || !Yt(t.protocolVersion) || !Yt(t.uiWorkerContract)) throw $("invalid application identity.");
	let n = qt(t.native, "native build set");
	if (Jt(n, ["core", "camera"], "native build set"), Zt(n.core).kind !== "core" || Zt(n.camera).kind !== "camera") throw $("swapped native module roles.");
	return t;
}
function $t(e, t) {
	let n = Qt(e);
	if (Xt(n) !== Xt(t)) throw $("the page, worker and native requirements belong to different builds.");
	return n;
}
//#endregion
//#region src/renderer/webgl2/computeIdentity.ts
function en(e, t) {
	if (!e || typeof e != "object") throw Error("Invalid render executor identity.");
	let n = e;
	if (n.kind !== t.kind) throw Error("The render executor belongs to a different host.");
	if (t.kind === "application") {
		if (Object.keys(n).some((e) => e !== "kind" && e !== "build")) throw Error("Invalid render executor identity.");
		$t(n.build, t.build);
	} else if (Object.keys(n).some((e) => ![
		"kind",
		"protocolVersion",
		"sourceId"
	].includes(e)) || n.protocolVersion !== t.protocolVersion || !/^[a-f0-9]{64}$/.test(String(n.sourceId)) || n.sourceId !== t.sourceId) throw Error("The render executor does not match this standalone module.");
}
//#endregion
//#region src/renderer/webgl2/computeClient.ts
var tn = class e {
	worker;
	sequence = 0;
	closed = !1;
	sortScratch;
	scratchPreparation;
	scratchUsers = 0;
	scratchTrimRequested = !1;
	scratchRetirement;
	get sortScratchSnapshot() {
		return {
			bytes: this.sortScratch ? this.sortScratch.count * 12 + 1024 : 0,
			users: this.scratchUsers,
			retiring: !!this.scratchRetirement,
			preparing: !!this.scratchPreparation
		};
	}
	pending = /* @__PURE__ */ new Map();
	observeStages = !1;
	observeWork;
	onFailure;
	constructor(e) {
		this.worker = e, this.worker.onmessage = ({ data: e }) => {
			let t = this.pending.get(e.id);
			if (t) {
				if ("phase" in e) try {
					if (!t.admit) throw Error("Render query admission is unavailable.");
					t.admit(e.bytes), this.worker.postMessage({
						action: "admitted",
						target: e.id,
						ok: !0
					});
				} catch (t) {
					this.worker.postMessage({
						action: "admitted",
						target: e.id,
						ok: !1,
						message: t instanceof Error ? t.message : String(t)
					});
				}
				else this.pending.delete(e.id), e.scratchBytes === 0 && (this.sortScratch?.release(), this.sortScratch = void 0), e.ok ? t.resolve(e) : t.reject(e.capacity ? new Ve(e.capacity.required, e.capacity.capacity) : e.name === "AbortError" ? new DOMException(e.message, "AbortError") : Error(e.message));
			}
		}, this.worker.onerror = (e) => {
			e.preventDefault(), this.fail(e.message || "The rendering worker failed.");
		}, this.worker.onmessageerror = () => this.fail("The rendering worker returned an unreadable message.");
	}
	static async connect(t, n, r = 45e3) {
		let i = new e(t), a = setTimeout(() => i.close("The render executor could not verify this build in time."), r);
		try {
			return en((await i.request({
				action: "initialize",
				identity: n
			})).identity, n), i;
		} catch (e) {
			throw i.close(), e;
		} finally {
			clearTimeout(a);
		}
	}
	request(e, t = [], n, r) {
		if (this.closed) return Promise.reject(new q("The rendering worker is unavailable."));
		n?.throwIfAborted();
		let i = ++this.sequence, a = this.observeWork, o = a ? performance.now() : 0, s = a ? t.reduce((e, t) => e + (t instanceof ArrayBuffer ? t.byteLength : 0), 0) : 0, c = () => this.worker.postMessage({
			action: "cancel",
			target: i
		}), l = new Promise((n, o) => {
			this.pending.set(i, {
				resolve: n,
				reject: o,
				admit: r
			});
			try {
				this.worker.postMessage({
					...e,
					id: i,
					...a ? { profile: !this.observeStages || "stages" } : {}
				}, t);
			} catch (e) {
				this.pending.delete(i), o(e);
			}
		});
		return n?.addEventListener("abort", c, { once: !0 }), l.then((t) => {
			if (a && t.timing) {
				let n = performance.now() - o;
				try {
					a({
						action: e.action,
						roundTripMs: n,
						...t.timing,
						transferredArrayBufferBytes: s + (t.order?.byteLength ?? 0) + (t.surface ? [
							t.surface.depths,
							t.surface.opacities,
							t.surface.colors,
							t.surface.visible
						].reduce((e, t) => e + (t?.byteLength ?? 0), 0) : 0),
						transportAndWakeupMs: Math.max(0, n - t.timing.queueMs - t.timing.computeMs)
					});
				} catch {}
			}
			return t;
		}).finally(() => n?.removeEventListener("abort", c));
	}
	ensureSortScratch(e, t) {
		if (this.scratchPreparation) return this.scratchPreparation.then(() => !!this.sortScratch && this.sortScratch.count >= e);
		if (this.sortScratch) return Promise.resolve(this.sortScratch.count >= e);
		if (!t || e * 12 + 1024 > 16 * 1024 ** 2) return Promise.resolve(!1);
		let n;
		try {
			n = t(e * 12 + 1024);
		} catch {
			return Promise.resolve(!1);
		}
		let r = this.request({
			action: "sortScratch",
			count: e
		}).then(() => this.closed ? (n(), !1) : (this.sortScratch = {
			count: e,
			release: n
		}, !0), () => (n(), !1)).finally(() => {
			this.scratchPreparation === r && (this.scratchPreparation = void 0);
		});
		return this.scratchPreparation = r, r;
	}
	async acquireSortScratch(e, t) {
		if (this.scratchRetirement) {
			await this.scratchRetirement;
			return;
		}
		this.sortScratch && this.sortScratch.count !== e && !this.scratchUsers && await this.trimSortScratch();
		let n = await this.ensureSortScratch(e, t);
		if (this.scratchRetirement) {
			await this.scratchRetirement;
			return;
		}
		if (!n || this.closed || !this.sortScratch || this.sortScratch.count < e) return;
		this.scratchUsers++;
		let r = !1;
		return () => {
			r || (r = !0, this.scratchUsers--, !this.scratchUsers && this.scratchTrimRequested && (this.scratchTrimRequested = !1, this.trimSortScratch().catch(() => void 0)));
		};
	}
	async trimSortScratch() {
		if (await this.scratchPreparation, !this.sortScratch || this.closed) return;
		if (this.scratchUsers) {
			this.scratchTrimRequested = !0;
			return;
		}
		if (this.scratchRetirement) return this.scratchRetirement;
		let e = this.request({
			action: "sortScratch",
			count: 0
		}).then(() => void 0).finally(() => {
			this.scratchRetirement === e && (this.scratchRetirement = void 0);
		});
		return this.scratchRetirement = e, e;
	}
	barrier() {
		return this.request({ action: "barrier" }).then(() => void 0);
	}
	fail(e) {
		this.close(e), this.onFailure?.(e);
	}
	close(e = "The rendering worker was retired.") {
		if (!this.closed) {
			this.closed = !0, this.worker.terminate(), this.sortScratch?.release(), this.sortScratch = void 0;
			for (let t of this.pending.values()) t.reject(new q(e));
			this.pending.clear();
		}
	}
};
//#endregion
//#region src/engine/compute.worker.ts?worker
function nn(e) {
	return new Worker(new URL("assets/compute.worker-D93-qexC.js", import.meta.url).href, {
		type: "module",
		name: e?.name
	});
}
//#endregion
//#region src/renderer/displayFrameAdmission.ts
var rn = class {
	capacity;
	flights = /* @__PURE__ */ new Set();
	latest = /* @__PURE__ */ new WeakMap();
	constructor(e = 2) {
		if (this.capacity = e, e !== 1 && e !== 2) throw RangeError("Display capacity must be one or two.");
	}
	get inFlight() {
		return this.flights.size;
	}
	canSubmit(e) {
		if (![e.width, e.height].every((e) => Number.isSafeInteger(e) && e > 0)) throw RangeError("Invalid display dimensions.");
		return this.flights.size < this.capacity && [...this.flights].every((t) => t.owner === e.owner && t.scene === e.scene && t.width === e.width && t.height === e.height);
	}
	track(e, t) {
		let n = this.latest.get(e.owner);
		if (n?.epoch === t.deviceEpoch && n.sequence >= t.submissionSequence) return !1;
		if (!this.canSubmit(e)) throw Error("Display admission is full or belongs to an earlier view.");
		let r = {
			...e,
			epoch: t.deviceEpoch,
			sequence: t.submissionSequence
		};
		return this.latest.set(e.owner, {
			epoch: r.epoch,
			sequence: r.sequence
		}), this.flights.add(r), t.done.then(() => {
			this.flights.delete(r);
		}, () => {
			this.flights.delete(r);
		}), !0;
	}
};
//#endregion
//#region src/renderer/displayPrecision.ts
function an(e, t) {
	return e && e.owner === t.owner && e.scene === t.scene && e.camera === t.camera && e.revision !== t.revision ? 24 : 32;
}
//#endregion
//#region src/engine/index.ts
function on(e, t = {}) {
	return Wt(e, {
		...t,
		preference: t.preference ?? "auto",
		allowFallback: t.allowFallback ?? !0,
		createCompute: () => tn.connect(new nn({ name: "splatview-standalone-compute" }), {
			kind: "standalone",
			protocolVersion: 1,
			sourceId: "4cefb913f6306a516bf21b4d1dbf85eb771197faae887923bd32baf85692fe4a"
		})
	});
}
var sn = [...R], cn = [...L];
//#endregion
export { g as AdmissionError, Te as DEFAULT_STEADY_SETTINGS, rn as DisplayFrameAdmission, sn as IDENTITY_MATRIX, cn as NEUTRAL_COLOR, S as ResourceLedger, q as StaleRenderQueryError, Ve as SurfaceCapacityError, on as createRenderer, U as encodeRgba, x as estimateSceneBytes, an as interactiveDisplayPrecision, b as packedStride, f as validateSortPrecision, Ee as validateSteadySettings, oe as withRgbaImage };

//# sourceMappingURL=splatview-renderer.js.map