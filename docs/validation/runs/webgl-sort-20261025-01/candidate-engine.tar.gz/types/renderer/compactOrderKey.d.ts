import type { SortPrecision } from './sortPrecision';
export type CompactOrderKey = {
    revision: number;
    precision: SortPrecision;
    bits: Uint32Array;
};
export declare function captureCompactOrderKey(words: Uint32Array, revision: number, precision: SortPrecision): CompactOrderKey;
export declare function compactOrderMatches(key: CompactOrderKey | undefined, words: Uint32Array, revision: number, precision: SortPrecision): boolean;
