/** Exact canonical FP32 dependencies of the stable source-depth permutation.
 * Keys belong to one scene's installed order, including offscreen overwrites.
 * No projection, color, opacity or camera-revision dependency is implied.
 */
export type DepthOrderKey = Readonly<{
    sourceRevision: number;
    bits: Uint32Array;
    transformTargets: unknown;
}>;
export declare function depthOrderMatches(key: DepthOrderKey | undefined, words: Uint32Array, sourceRevision: number, transformTargets?: unknown): boolean;
export declare function captureDepthOrderKey(words: Uint32Array, sourceRevision: number, transformTargets?: unknown): DepthOrderKey;
