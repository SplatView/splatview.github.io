export declare const GEOMETRY_LAYOUT_VERSION = 1;
export declare const GEOMETRY_CHUNK_BYTES: number;
export type GeometryChannel = 'vertices' | 'indices';
export type GeometryDescriptor = {
    layoutVersion: 1;
    kind: 1 | 2;
    vertexCount: number;
    triangleCount: number;
    vertexStride: 16;
    indexStride: 4;
    vertexBytes: number;
    indexBytes: number;
    revision: number;
    contentRevision: number;
};
export declare function geometryInteger(value: unknown, minimum: number, maximum: number, name: string): asserts value is number;
/** A detached, exact descriptor; caller mutation cannot change an admitted transfer. */
export declare function validateGeometryDescriptor(value: unknown): GeometryDescriptor;
export declare function sameGeometryDescriptor(a: GeometryDescriptor, b: GeometryDescriptor): boolean;
