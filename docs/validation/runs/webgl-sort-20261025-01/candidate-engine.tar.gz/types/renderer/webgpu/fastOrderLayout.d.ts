/** Optional retained buffers; source pairs/ranks are borrowed from the scene. */
export declare function planFastOrder(count: number): {
    groups: number;
    blocks: number;
    sizes: {
        visibleCounts: number;
        indirect: number;
        compactA: number;
        visibleOffsets: number;
        visibleSums: number;
        visibleBlocks: number;
        visibleTotal: number;
    };
    bufferBytes: number;
    bytes: number;
};
