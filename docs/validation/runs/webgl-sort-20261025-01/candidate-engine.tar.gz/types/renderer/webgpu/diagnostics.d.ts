/** Creation observations only. No GPU timestamp queries or inferred hardware timings. */
export type RendererInitializationStage = 'start' | 'adapter-request' | 'adapter-observed' | 'device-request' | 'device-observed' | 'shader-compilation' | 'pipeline-creation' | 'renderer-creation' | 'validation' | 'ready';
type Status = 'initializing' | 'ready' | 'failed';
export type RendererCapabilitiesObservation = Readonly<{
    features: readonly string[] | null;
    limits: Readonly<Record<string, number>> | null;
    featuresUnavailableReason: string | null;
    limitsUnavailableReason: string | null;
}>;
export type RendererAdapterObservation = RendererCapabilitiesObservation & Readonly<{
    info: Readonly<Record<string, string | number | boolean>> | null;
    infoUnavailableReason: string | null;
}>;
export type RendererNegotiationSnapshot = Readonly<{
    schemaVersion: 1;
    kind: 'splatview-renderer-negotiation';
    status: Status;
    stage: RendererInitializationStage;
    clock: 'performance.now';
    startedAtMs: number | null;
    observedAtMs: number | null;
    clockUnavailableReason: string | null;
    stages: readonly Readonly<{
        stage: RendererInitializationStage;
        status: Status;
        atMs: number | null;
    }>[];
    adapter: RendererAdapterObservation | null;
    requested: Readonly<{
        features: readonly string[];
        limits: Readonly<Record<string, number>>;
    }> | null;
    device: RendererCapabilitiesObservation | null;
    failure: Readonly<{
        stage: RendererInitializationStage;
        reason: string;
    }> | null;
    gpuTimestamps: Readonly<{
        available: false;
        reason: string;
    }>;
}>;
export type RendererNegotiationObserver = (snapshot: RendererNegotiationSnapshot) => void;
/** Copies values immediately, including prototype getters; no live GPU object is retained. */
export declare function captureRendererCapabilities(source: unknown): RendererCapabilitiesObservation;
/** One renderer-create lifetime. At most ten small snapshots, including failure. */
export declare class RendererNegotiation {
    private readonly observer?;
    private readonly now;
    private stage;
    private status;
    private events;
    private adapter;
    private requested;
    private device;
    private failure;
    private startedAtMs;
    private observedAtMs;
    private clockUnavailableReason;
    private current;
    constructor(observer?: RendererNegotiationObserver | undefined, now?: () => number);
    get snapshot(): RendererNegotiationSnapshot;
    observeAdapter(adapter: unknown): void;
    observeRequest(descriptor: {
        requiredFeatures?: Iterable<string>;
        requiredLimits?: object;
    }): void;
    observeDevice(device: unknown): void;
    advance(stage: RendererInitializationStage): void;
    fail(error: unknown): void;
    private publish;
}
export {};
