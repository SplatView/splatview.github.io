import type { GaussianRenderer, GpuScene } from './renderer';
declare const entries: readonly ['countCandidates', 'candidateOffsets', 'scatterCandidates', 'pickCandidates'];
type Pipelines = Record<typeof entries[number], GPUComputePipeline>;
export declare function preparePickCandidates(renderer: GaussianRenderer): Promise<Pipelines>;
export declare function allocatePickCandidates(renderer: GaussianRenderer, scene: GpuScene): Promise<{
    encode(encoder: GPUCommandEncoder): void;
    dispose(): void;
} | undefined>;
export {};
