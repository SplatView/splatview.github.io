import { type GeometryDescriptor } from '../geometryLayout';
import type { GaussianRenderer } from './renderer';
/** Readonly PLY vertex/index storage; never owns Gaussian masks or sorting. */
export declare class GpuGeometryScene {
    readonly renderer: GaussianRenderer;
    readonly kind: 'geometry';
    readonly descriptor: GeometryDescriptor;
    readonly vertices: GPUBuffer;
    readonly indices?: GPUBuffer;
    readonly drawGroup: GPUBindGroup;
    readonly count: number;
    readonly revision: number;
    readonly contentRevision: number;
    retired: boolean;
    private pendingUploadBytes;
    private retirement?;
    get deviceEpoch(): number;
    constructor(renderer: GaussianRenderer, descriptor: GeometryDescriptor);
    get allocationBytes(): number;
    private upload;
    uploadVertices(first: number, count: number, bytes: ArrayBuffer): Promise<void>;
    uploadIndices(first: number, count: number, bytes: ArrayBuffer): Promise<void>;
    dispose(): Promise<void>;
}
