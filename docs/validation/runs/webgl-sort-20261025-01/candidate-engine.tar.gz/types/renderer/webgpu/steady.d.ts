import { type SteadySettings, type SteadyStatus } from '../steadySettings';
type Scene = {
    revision: number;
    count: number;
    buffers: {
        projected: GPUBuffer;
        states: GPUBuffer;
    };
};
type Callbacks = {
    admit(bytes: number): (() => void) | undefined;
    invalidate(): void;
    status(status: SteadyStatus): void;
};
/** Optional display resources. GaussianRenderer owns all command submission. */
export declare class SteadySplats {
    private readonly device;
    private readonly format;
    private readonly frame;
    private readonly callbacks;
    private settings;
    private disposed;
    private generation;
    private desired?;
    private failed;
    private preparation?;
    private readonly retiring;
    private pipelines?;
    private resources?;
    private state;
    private previousViewProjection?;
    private writeIndex;
    private status;
    private reason;
    private allocatedBytes;
    constructor(device: GPUDevice, format: GPUTextureFormat, frame: GPUBuffer, callbacks: Callbacks);
    get snapshot(): {
        status: SteadyStatus;
        reason: string | null;
        allocationBytes: number;
        frame: number;
        restFrames: number;
        valid: boolean;
    };
    configure(value: SteadySettings): void;
    resetHistory(): void;
    private report;
    /** Non-Gaussian/unsupported views retain their normal renderer and release optional memory. */
    suspend(reason?: string): void;
    ready(width: number, height: number): boolean;
    private prepare;
    private createResources;
    private retire;
    finish(): Promise<void>;
    private group;
    /** Returns whether the controller should request another refinement frame. */
    encode(encoder: GPUCommandEncoder, scene: Scene, uniform: Uint32Array, shade: number, target: GPUTextureView): boolean;
    dispose(): void;
}
export {};
