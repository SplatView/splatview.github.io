import { type ResourceLease } from '../../document/resources';
export type SurfaceScratch = {
    readonly buffer: GPUBuffer;
    readonly reused: boolean;
    /** The caller must join submitted uploads/commands before releasing. */
    release(retain?: boolean): void;
};
/** One renderer's exact-size scratch cache. Every physical buffer keeps its own
 * admission, including while idle. Only fully retired, unmapped buffers may be
 * returned; callers must clear counters/padding before reusing their contents.
 */
export declare class SurfaceScratchPool {
    private readonly device;
    readonly maximumIdleBytes: number;
    readonly maximumIdleBuffers: number;
    private readonly entries;
    private disposed;
    private reused;
    private created;
    constructor(device: GPUDevice, maximumIdleBytes?: number, maximumIdleBuffers?: number);
    get snapshot(): {
        allocatedBytes: number;
        idleBytes: number;
        idleBuffers: number;
        activeBuffers: number;
        createdBuffers: number;
        reusedBuffers: number;
    };
    acquire(owner: object, label: string, size: number, usage: GPUBufferUsageFlags, admit: (bytes: number) => ResourceLease): SurfaceScratch;
    /** Pressure/scene invalidation evicts idle buffers now. Active buffers keep
     * their credit and are discarded only after their caller joins retirement.
     */
    trim(owner?: object): void;
    private evictIdle;
    private destroy;
    /** Call only after device loss or device.destroy() has retired its work. */
    dispose(): void;
}
