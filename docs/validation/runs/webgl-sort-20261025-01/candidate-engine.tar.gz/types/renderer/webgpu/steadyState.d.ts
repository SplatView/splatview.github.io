export declare const STEADY_NOISE_BYTES: number;
export declare const STEADY_UNIFORM_BYTES = 240;
export declare const STEADY_HISTORY_BYTES = 68;
export declare const STEADY_PIXEL_BYTES = 136;
/** Keep each history binding within portable storage limits without reducing display resolution. */
export declare function planSteadyResources(width: number, height: number, limits: Pick<GPUSupportedLimits, 'maxTextureDimension2D' | 'maxBufferSize' | 'maxStorageBufferBindingSize' | 'maxComputeWorkgroupsPerDimension'>): {
    width: number;
    height: number;
    stripes: {
        start: number;
        rows: number;
    }[];
    bytes: number;
};
