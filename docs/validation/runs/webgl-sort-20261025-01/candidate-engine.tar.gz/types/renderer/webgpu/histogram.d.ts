import type { RenderedHistogram } from '../histogram';
import type { RenderableScene } from './renderer';
export declare const HISTOGRAM_ALLOCATION_BYTES: number;
export declare const HISTOGRAM_INTERVAL_MS = 200;
type HistogramFrame = {
    identity: object;
    scene: RenderableScene;
    width: number;
    height: number;
    frame: number;
};
type HistogramCallbacks = {
    admit(bytes: number): (() => void) | undefined;
    invalidate(): void;
    publish(result: RenderedHistogram, scene: RenderableScene): void;
    unavailable(): void;
};
/** Optional display sampling. It never retains a canvas texture across a yield. */
export declare class HistogramSampler {
    private readonly device;
    private readonly deviceEpoch;
    private readonly callbacks;
    private enabled;
    private disposed;
    private failed;
    private reportedFailureGeneration;
    private generation;
    private desired?;
    private sampled?;
    private resources?;
    private preparation?;
    private pending?;
    private readonly retiring;
    private retirementWait?;
    private timer?;
    private lastStarted;
    constructor(device: GPUDevice, deviceEpoch: number, callbacks: HistogramCallbacks);
    setEnabled(enabled: boolean): void;
    reset(): void;
    private cancelTimer;
    private requestFrame;
    private fail;
    private reportUnavailable;
    private retire;
    private prepare;
    private createResources;
    private map;
    /** Called synchronously after the display submission, using that frame's texture. */
    observe(texture: GPUTexture, frame: HistogramFrame): void;
    finish(): Promise<void>;
    dispose(): void;
}
export {};
