import { type SurfaceChannels } from './surfaceQuery';
export type SurfaceBufferPlan = Readonly<{
    pixels: number;
    tilesX: number;
    tilesY: number;
    tileCount: number;
    countBytes: number;
    layoutBytes: number;
    outputBytes: number;
    readbackBytes: number;
    auxiliaryBytes: number;
    projectionBytes: number;
    colorBytes: number;
    visibilityBytes: number;
    /** CPU count view, span array/upload and parameter array/upload. */
    hostScratchBytes: number;
    /** Every noncandidate GPU buffer, including readbacks and dummy bindings. */
    physicalScratchBytes: number;
    /** Full-size CPU map arrays retained after GPU retirement. */
    retainedCpuBytes: number;
}>;
/** Size an already-bounded map and resolved coverage without allocating it.
 * Candidate spans are deliberately absent: surface.ts admits them only after
 * the count stage. Device limits, leases and retirement also stay in that owner.
 */
export declare function planSurfaceBuffers(input: SurfaceChannels & Readonly<{
    width: number;
    height: number;
    sourceCount: number;
    downsampled: boolean;
}>): SurfaceBufferPlan;
