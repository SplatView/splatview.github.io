export type SurfaceTileLayout = {
    /** Two u32s per tile: offset into the compact list, then allocated span. */
    spans: Uint32Array;
    candidateEntries: number;
    /** Physical buffer bytes, including the minimum binding for an empty map. */
    candidateBytes: number;
    tileCapacity: number;
    tileCount: number;
    occupiedTiles: number;
    sortComparisons: number;
};
/** Validate the complete prefix sum before allocating or uploading any list.
 * Padding is local to each occupied tile, so empty/singleton tiles do no sort
 * work and one dense tile cannot inflate every other tile's allocation.
 */
export declare function planSurfaceTiles(counts: ArrayLike<number>, maximumCandidateBytes: number, maximumTileCapacity?: number): SurfaceTileLayout;
