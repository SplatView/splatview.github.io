import { AdmissionError, type ResourceLease } from '../../document/resources';
/** Host/shader contract. Keep these values aligned with surface.wgsl. */
export declare const SURFACE_TILE_SIZE = 16;
export declare const SURFACE_PIXEL_LIMIT = 262144;
export declare const SURFACE_PARAMETERS_BYTES = 48;
export declare const SURFACE_MAX_PACKED_COORDINATE = 65535;
export declare const SURFACE_FLAGS: Readonly<{
    colors: 1;
    visible: 2;
    downsampled: 4;
    region: 8;
}>;
/** Half-open coverage in the unchanged, downsampled selection-map grid. */
export type SurfaceRegion = Readonly<{
    x: number;
    y: number;
    width: number;
    height: number;
}>;
/** Undefined coverage means the full map. Color and visibility require full coverage. */
export type SurfaceChannels = Readonly<{
    colors?: boolean;
    visible?: boolean;
    region?: SurfaceRegion;
}>;
export type SurfaceProfile = {
    pipelineMs: number;
    countMs: number;
    planMs: number;
    allocationMs: number;
    compositeReadbackMs: number;
    copyMs: number;
    retireMs: number;
    totalMs: number;
    readbackBytes: number;
    reusedBuffers: number;
    createdBuffers: number;
};
export declare class SurfaceCapacityError extends AdmissionError {
    readonly required: number;
    readonly capacity: number;
    constructor(required: number, capacity: number);
}
export type SurfaceOptions = SurfaceChannels & {
    /** Admission covers candidate lists, GPU outputs/readback and retained CPU arrays. */
    admit(bytes: number): ResourceLease;
    /** Compatibility hint; compact planning no longer allocates a global span. */
    initialTileCapacity?: number;
    /** Optional caller ceiling. The normal query has no fixed per-tile ceiling. */
    maxTileCapacity?: number;
    /** Explicit opt-in; retained physical buffers keep their own memory credit. */
    reuseBuffers?: boolean;
    poolOwner?: object;
    signal?: AbortSignal;
};
/** Published map metadata is immutable. Typed-array contents retain their
 * existing ownership/transport semantics; this adds no freezing or copying.
 */
export type SurfaceMap = Readonly<{
    width: number;
    height: number;
    fullWidth: number;
    fullHeight: number;
    depths: Float32Array;
    opacities: Float32Array;
    deviceEpoch: number;
    /** Raw view-dependent SH colors without display grading or selection tint. */
    colors?: Float32Array;
    /** Source-ID bitset from surviving fragments on the full framebuffer grid. */
    visible?: Uint32Array;
    region?: SurfaceRegion;
    profile?: Readonly<SurfaceProfile>;
    attempts: number;
    tileCapacity: number;
    allocationBytes: number;
    /** Physical candidate buffer bytes (minimum four), and compact work counts. */
    candidateBytes: number;
    candidateEntries: number;
    tileCount: number;
    occupiedTiles: number;
    sortComparisons: number;
    /** Rejects a map retained after its view, document or device changes. */
    assertCurrent(): void;
    dispose(): void;
}>;
export declare function surfaceDimensions(width: number, height: number): {
    width: number;
    height: number;
    scale: number;
};
/** Validate and snapshot depth coverage, preserving the full-map fallback. */
export declare function resolveSurfaceRegion(channels: SurfaceChannels, width: number, height: number): SurfaceRegion | undefined;
export declare function surfaceChannelFlags(channels: SurfaceChannels, downsampled: boolean): number;
/** Encode already-admitted query inputs into the unchanged SurfaceParams ABI.
 * Coverage maxima are exclusive. scale is an f32 at byte40, not a u32 value.
 * This module owns packing only; GPU submission/retirement stay in surface.ts.
 */
export declare function encodeSurfaceParameters(input: {
    fullWidth: number;
    fullHeight: number;
    width: number;
    height: number;
    sourceCount: number;
    channelFlags: number;
    dispatchWidth: number;
    scale: number;
    region?: SurfaceRegion;
}): Uint32Array<ArrayBuffer>;
