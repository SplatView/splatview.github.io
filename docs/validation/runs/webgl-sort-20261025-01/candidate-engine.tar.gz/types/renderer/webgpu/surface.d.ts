import { GaussianRenderer, type GpuScene } from './renderer';
import { type SurfaceMap, type SurfaceOptions } from './surfaceQuery';
/**
 * Bounded FP32 surface map of the most recently prepared renderer frame.
 * Uses compute storage rather than float blend targets, and needs no optional
 * WebGPU features. Count once, admit compact per-tile spans, then fill once;
 * never publish a partial candidate list. Call render before requesting a map.
 */
export declare function compositedSurface(renderer: GaussianRenderer, scene: GpuScene, options: SurfaceOptions): Promise<SurfaceMap>;
