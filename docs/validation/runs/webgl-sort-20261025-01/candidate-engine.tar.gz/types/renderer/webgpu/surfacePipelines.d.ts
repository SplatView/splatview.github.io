import type { GaussianRenderer } from './renderer';
declare const baseEntries: readonly ['bin', 'scatter', 'sortTile', 'composite', 'prepareAuxiliary'];
type BaseEntry = typeof baseEntries[number];
export type SurfacePipelines = Record<BaseEntry, GPUComputePipeline> & {
    markVisible?: GPUComputePipeline;
};
/** Launch asynchronous compilation under synchronously balanced error scopes.
 * Neither optional warming nor a query leaves a device scope open across a yield.
 * Visibility is independent: ordinary depth/color queries never compile it.
 */
export declare function prepareSurfacePipelines(renderer: GaussianRenderer, options?: {
    visible?: boolean;
}): Promise<SurfacePipelines>;
export declare function forgetSurfacePipelines(renderer: GaussianRenderer): void;
export {};
