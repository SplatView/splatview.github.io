import { planFastOrder } from './fastOrderLayout';
import type { GaussianRenderer, GpuScene } from './renderer';
declare const entries: readonly ['countVisible', 'publishVisible', 'scatterVisible'];
type Pipelines = Record<typeof entries[number], GPUComputePipeline>;
/** Compacts an already sorted order. The renderer submits; the scene retires
 * buffers and credit. Private output cannot overwrite complete query pairs. */
export declare class FastOrder {
    readonly allocationBytes: number;
    private readonly buffers;
    private readonly release;
    private disposed;
    private readonly stages;
    readonly indirect: GPUBuffer;
    readonly drawGroup: GPUBindGroup;
    constructor(renderer: GaussianRenderer, allocationBytes: number, buffers: GPUBuffer[], release: () => void, scene: GpuScene, pipelines: Pipelines, layout: ReturnType<typeof planFastOrder>);
    encode(encoder: GPUCommandEncoder): void;
    dispose(): void;
}
export declare function allocateFastOrder(renderer: GaussianRenderer, scene: GpuScene): Promise<FastOrder | undefined>;
export {};
