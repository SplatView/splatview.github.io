/** The graphics API is independent of the sorted/SteadySplats algorithm. */
export type GraphicsBackendPreference = 'auto' | 'webgpu' | 'webgl2';
export type GraphicsBackend = Exclude<GraphicsBackendPreference, 'auto'>;
export declare function validateBackendPreference(value: unknown): GraphicsBackendPreference;
export declare function nextRendererEpoch(): number;
export declare function recordCanvasBackend(canvas: HTMLCanvasElement, backend: GraphicsBackend): void;
export declare function canvasBackend(canvas: HTMLCanvasElement): GraphicsBackend | undefined;
