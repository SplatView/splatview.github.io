import type { BackgroundColor } from '../input/background';
export type RenderCamera = Readonly<{
    view: Float32Array<ArrayBuffer>;
    projection: Float32Array<ArrayBuffer>;
    eye: Float32Array<ArrayBuffer>;
    revision: number;
    background: BackgroundColor;
}>;
export declare const FRAME_BYTES = 320;
/** Canonical native/WebGPU frame. GL raster depth conversion never changes it. */
export declare function encodeGaussianFrame(scene: {
    count: number;
    stride: number;
    degree: number;
    duplicateSelectionGuarded: boolean;
}, camera: RenderCamera, grade: number[], highlight: boolean, geometry: number[], selectedOnly: boolean, width: number, height: number, geometrySelectedOnly?: boolean, opacityScale?: number, opacitySelectedOnly?: boolean): {
    values: Float32Array<ArrayBuffer>;
    words: Uint32Array<ArrayBuffer>;
    geometryKey: string;
};
