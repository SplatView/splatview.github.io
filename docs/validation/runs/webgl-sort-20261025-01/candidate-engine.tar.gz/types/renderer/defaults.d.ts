/** Pure canonical frame defaults shared by rendering and document adapters. */
export declare const NEUTRAL_COLOR: number[];
export declare const IDENTITY_MATRIX: number[];
