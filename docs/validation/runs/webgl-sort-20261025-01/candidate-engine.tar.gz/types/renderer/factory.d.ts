import { type GraphicsBackend, type GraphicsBackendPreference } from './backend';
import type { SceneRenderer } from './contracts';
import type { RendererNegotiationObserver } from './webgpu/diagnostics';
import { type SortPrecision } from './sortPrecision';
export type SceneRendererOptions = {
    createCompute: () => Promise<import('./webgl2/computeClient').RenderComputeClient>;
    preference: GraphicsBackendPreference;
    recoveryBackend?: GraphicsBackend;
    allowFallback: boolean;
    replaceCanvas?: (previous: HTMLCanvasElement) => Promise<HTMLCanvasElement>;
    observe?: RendererNegotiationObserver;
    fallback?: (reason: string) => void;
    sortPrecision?: SortPrecision;
};
/** Startup choice only. Recovery pins the previously selected API. */
export declare function createSceneRenderer(initialCanvas: HTMLCanvasElement, options: SceneRendererOptions): Promise<SceneRenderer>;
