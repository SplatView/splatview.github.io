/**
 * Decodes the scalar STBN volume, with X contiguous, then Y, then frame.
 *
 * @returns {Uint8Array} Uniform 8-bit threshold ranks.
 * @ignore
 */
declare const spatiotemporalBlueNoiseData: () => Uint8Array<ArrayBuffer>;
export { spatiotemporalBlueNoiseData };
