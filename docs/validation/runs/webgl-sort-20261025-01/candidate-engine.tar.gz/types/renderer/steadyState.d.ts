import type { SteadySettings } from './steadySettings';
export declare function supportsSteadyProjection(p: ArrayLike<number>): boolean;
export declare function multiplyMatrices(a: ArrayLike<number>, b: ArrayLike<number>): Float32Array<ArrayBuffer>;
export declare function invertMatrix(m: ArrayLike<number>): Float32Array<ArrayBuffer>;
type DisplayFrame = {
    scene: object;
    revision: number;
    uniform: Uint32Array;
    shade: number;
};
/** Display identity is independent of temporary query/capture preparation. */
export declare class SteadyFrameState {
    private previous?;
    frame: number;
    restFrames: number;
    valid: boolean;
    reset(): void;
    observe(next: DisplayFrame, settings: SteadySettings): {
        reconstruct: boolean;
        valid: boolean;
        still: boolean;
        restFrames: number;
        sampleFrame: number;
        needsMore: boolean;
    };
}
export {};
