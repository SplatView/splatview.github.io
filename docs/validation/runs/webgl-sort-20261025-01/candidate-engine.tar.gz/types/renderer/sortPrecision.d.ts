/** Display depth-key precision. Exact queries and clean output always use 32. */
export type SortPrecision = 16 | 24 | 32;
export declare function validateSortPrecision(value: unknown): SortPrecision;
