import type { ComputeCommand, ComputeTiming } from './computeProtocol';
import { type ComputeIdentity } from './computeIdentity';
/** One executor, with acknowledged cancellation; no document/history authority. */
export declare class RenderComputeClient {
    private readonly worker;
    private sequence;
    private closed;
    private sortScratch?;
    private scratchPreparation?;
    private scratchUsers;
    private scratchTrimRequested;
    private scratchRetirement?;
    get sortScratchSnapshot(): {
        bytes: number;
        users: number;
        retiring: boolean;
        preparing: boolean;
    };
    private readonly pending;
    /** Test/agent-only diagnostics. No clocks or records while disabled. */
    observeStages: boolean;
    observeWork?: (event: ComputeTiming & {
        action: ComputeCommand['action'];
        roundTripMs: number;
        transportAndWakeupMs: number;
        transferredArrayBufferBytes: number;
    }) => void;
    onFailure?: (message: string) => void;
    private constructor();
    /** Takes worker ownership immediately, including initialization failure. */
    static connect(worker: Worker, identity: ComputeIdentity, timeoutMs?: number): Promise<RenderComputeClient>;
    request(command: ComputeCommand, transfer?: Transferable[], signal?: AbortSignal, admit?: (bytes: number) => void): Promise<{
        id: number;
        ok: true;
        identity?: import('./computeIdentity').ComputeIdentity;
        order?: ArrayBuffer;
        pick?: {
            index: number | null;
            depth: number;
            opacity: number;
            contribution: number;
        };
        surface?: import("./computeProtocol").ComputeSurfaceResult;
    } & {
        timing?: ComputeTiming;
        scratchBytes?: number;
    }>;
    /** Retained worker arrays have an independent lease, including while idle. */
    private ensureSortScratch;
    acquireSortScratch(count: number, admit?: ((bytes: number) => () => void)): Promise<(() => void) | undefined>;
    trimSortScratch(): Promise<void>;
    barrier(): Promise<undefined>;
    private fail;
    close(message?: string): void;
}
