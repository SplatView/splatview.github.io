import { type SteadySettings, type SteadyStatus } from '../steadySettings';
import type { GlRenderer, GlFrame } from './renderer';
/** Framebuffer resource owner; the renderer owns all display submissions. */
export declare class GlSteadySplats {
    private readonly renderer;
    private settings;
    private readonly state;
    private resources?;
    private programs?;
    private desired?;
    private generation;
    private failed;
    private disposed;
    private preparation?;
    private previousViewProjection?;
    private writeIndex;
    private status;
    private reason;
    private allocatedBytes;
    constructor(renderer: GlRenderer);
    get snapshot(): {
        status: SteadyStatus;
        reason: string | null;
        allocationBytes: number;
        frame: number;
        restFrames: number;
        valid: boolean;
    };
    configure(settings: SteadySettings): void;
    resetHistory(): void;
    private report;
    suspend(reason?: string): void;
    ready(width: number, height: number): boolean;
    private prepare;
    private createResources;
    private retire;
    private bind;
    encode(frame: GlFrame): boolean;
    dispose(): void;
}
