import type { BuildDescriptor } from '../../build/contracts';
/** Application deployments keep their full descriptor; standalone builds have
 * their own source digest. Neither executor accepts the other host's identity. */
export type ComputeIdentity = {
    kind: 'application';
    build: BuildDescriptor;
} | {
    kind: 'standalone';
    protocolVersion: 1;
    sourceId: string;
};
export declare function assertComputeIdentity(actual: unknown, expected: ComputeIdentity): void;
