export type ProgramSources = Readonly<{
    vertex: string;
    fragment: string;
}>;
/** Submit all compilation/link work before asking for status. Optional parallel
 * compilation keeps the event loop available; the ordinary GL2 fallback works
 * without the extension. Every pending object has this single preparation owner.
 */
export declare function preparePrograms(gl: WebGL2RenderingContext, sources: readonly ProgramSources[], current?: () => boolean): Promise<WebGLProgram[]>;
