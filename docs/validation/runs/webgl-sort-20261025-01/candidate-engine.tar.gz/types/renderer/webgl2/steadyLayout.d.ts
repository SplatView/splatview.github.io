import type { WebglCapabilities } from './capabilities';
export declare const GL_STEADY_PIXEL_BYTES = 224;
export declare const GL_STEADY_NOISE_BYTES: number;
export declare const GL_STEADY_UNIFORM_BYTES = 240;
export declare function planGlSteady(width: number, height: number, caps: Pick<WebglCapabilities, 'maxTextureSize' | 'maxRenderbufferSize' | 'maxViewport' | 'steady' | 'steadyReason'>): Readonly<{
    width: number;
    height: number;
    bytes: number;
}>;
