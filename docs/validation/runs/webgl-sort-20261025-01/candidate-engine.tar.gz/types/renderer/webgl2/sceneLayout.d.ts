export type TextureLayout = Readonly<{
    width: number;
    height: number;
    entries: number;
    bytes: number;
}>;
/** Linear integer texels; padding belongs to the physical allocation. */
export declare function linearTextureLayout(entries: number, bytesPerTexel: number, maximum: number, preferred?: number): TextureLayout;
export declare function planGlScene(count: number, degree: number, maximum: number): Readonly<{
    stride: number;
    words: Readonly<{
        width: number;
        height: number;
        entries: number;
        bytes: number;
    }>;
    states: Readonly<{
        width: number;
        height: number;
        entries: number;
        bytes: number;
    }>;
    order: Readonly<{
        width: number;
        height: number;
        entries: number;
        bytes: number;
    }>;
    bytes: number;
}>;
/** Split partial linear uploads at rows without padding or rewriting neighbors. */
export declare function textureUploadSpans(first: number, count: number, layout: TextureLayout): {
    x: number;
    y: number;
    width: number;
    height: number;
    offset: number;
    entries: number;
}[];
