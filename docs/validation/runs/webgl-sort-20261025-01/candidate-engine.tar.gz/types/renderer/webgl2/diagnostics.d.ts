import type { RendererNegotiationSnapshot } from '../webgpu/diagnostics';
import type { WebglCapabilities } from './capabilities';
/** Actual GL observations use GL names; no synthetic GPUDevice or adapter. */
export declare function glNegotiation(startedAtMs: number, caps: WebglCapabilities): RendererNegotiationSnapshot;
