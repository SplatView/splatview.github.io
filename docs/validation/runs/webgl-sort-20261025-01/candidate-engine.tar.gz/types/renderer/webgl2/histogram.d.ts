import type { GlFrame, GlRenderer } from './renderer';
/** Copies the displayed framebuffer in the submitting task, then reads bounded pixels. */
export declare class GlHistogramSampler {
    private readonly renderer;
    private enabled;
    private disposed;
    private failed;
    private generation;
    private resources?;
    private pending?;
    private desired?;
    private sampled?;
    private lastStarted;
    private timer?;
    constructor(renderer: GlRenderer);
    setEnabled(value: boolean): void;
    reset(): void;
    private cancelTimer;
    private requestFrame;
    private retire;
    private allocate;
    observe(frame: GlFrame, identity: object, sequence: number): void;
    private fail;
    dispose(): void;
}
