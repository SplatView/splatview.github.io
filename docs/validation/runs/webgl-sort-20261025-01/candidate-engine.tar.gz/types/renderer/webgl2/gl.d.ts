export declare function samplerUniform(gl: WebGL2RenderingContext, program: WebGLProgram, name: string, unit: number): void;
/** Program objects are context-owned; retired programs cannot serve a new epoch. */
export declare function uniformLocation(gl: WebGL2RenderingContext, program: WebGLProgram, name: string): WebGLUniformLocation;
export declare function uniformBlock(gl: WebGL2RenderingContext, program: WebGLProgram, name: string, binding: number): number;
/** WebGL objects and synchronization stay inside their backend. */
export declare function createProgram(gl: WebGL2RenderingContext, vertex: string, fragment: string): WebGLProgram;
/** A real nonblocking fence. Cancellation never releases queued work early. */
export declare function finishGl(gl: WebGL2RenderingContext): Promise<void>;
export declare function requireGlAllocation(gl: WebGL2RenderingContext, label: string): void;
export declare function texture2d(gl: WebGL2RenderingContext, width: number, height: number, format: number): WebGLTexture;
export declare function framebuffer(gl: WebGL2RenderingContext, colors: WebGLTexture[], depth?: WebGLRenderbuffer): WebGLFramebuffer;
export declare function depth32(gl: WebGL2RenderingContext, width: number, height: number): WebGLRenderbuffer;
export declare const FULLSCREEN_VERTEX = "#version 300 es\nprecision highp float;\nvoid main() {\n  vec2 p = gl_VertexID == 0 ? vec2(-1.,-1.) : gl_VertexID == 1 ? vec2(3.,-1.) : vec2(-1.,3.);\n  gl_Position = vec4(p,0.,1.);\n}";
