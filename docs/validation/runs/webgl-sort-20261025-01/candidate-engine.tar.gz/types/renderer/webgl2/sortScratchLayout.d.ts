/** Optional retained worker storage. Transient/query sorts keep 256 bins. */
export declare const sortScratchLimit: number;
export declare function planSortScratch(count: number): {
    histogramBins: number;
    bytes: number;
};
