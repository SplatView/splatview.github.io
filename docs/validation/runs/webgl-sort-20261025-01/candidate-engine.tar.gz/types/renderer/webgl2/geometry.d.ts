import { type GeometryDescriptor } from '../geometryLayout';
import type { GeometryScene } from '../contracts';
import type { GlRenderer } from './renderer';
export declare class GlGeometryScene implements GeometryScene {
    readonly renderer: GlRenderer;
    readonly kind: 'geometry';
    readonly descriptor: GeometryDescriptor;
    readonly vertices: WebGLBuffer;
    readonly indices?: WebGLBuffer;
    readonly count: number;
    readonly revision: number;
    readonly contentRevision: number;
    retired: boolean;
    private uploadBytes;
    private retirement?;
    get deviceEpoch(): number;
    get allocationBytes(): number;
    constructor(renderer: GlRenderer, descriptor: GeometryDescriptor);
    private upload;
    uploadVertices(first: number, count: number, bytes: ArrayBuffer): Promise<void>;
    uploadIndices(first: number, count: number, bytes: ArrayBuffer): Promise<void>;
    dispose(): Promise<void>;
}
