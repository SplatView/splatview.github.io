export declare const WEBGL_CONTEXT_ATTRIBUTES: WebGLContextAttributes;
export type WebglCapabilities = Readonly<{
    maxTextureSize: number;
    maxRenderbufferSize: number;
    maxViewport: readonly [number, number];
    maxVertexTextureUnits: number;
    maxFragmentTextureUnits: number;
    maxCombinedTextureUnits: number;
    maxDrawBuffers: number;
    maxColorAttachments: number;
    fragmentFloatPrecision: number;
    fragmentIntPrecision: number;
    extensions: readonly string[];
    enabledExtensions: readonly string[];
    version: string;
    shadingLanguageVersion: string;
    vendor: string;
    renderer: string;
    unmaskedVendor: string | null;
    unmaskedRenderer: string | null;
    steady: boolean;
    steadyReason: string | null;
}>;
/** Capability evidence is observed, never inferred from a browser/GPU brand. */
export declare function observeWebglCapabilities(gl: WebGL2RenderingContext): WebglCapabilities;
