/** Histogram of the displayed frame, in RGB channel-major order. */
export type RenderedHistogram = {
    bins: Uint32Array;
    /** Number of sample columns/rows, rather than the display resolution. */
    width: number;
    height: number;
    frame: number;
    deviceEpoch: number;
};
export declare const HISTOGRAM_BINS = 256;
export declare const HISTOGRAM_HEIGHT = 54;
export declare const HISTOGRAM_COLORS: readonly ['#ec6464', '#7dd292', '#69a5f5'];
/** Desktop uses a single logarithmic scale shared by all three channels. */
export declare function histogramPaths(bins: Uint32Array | undefined, width: number): string[];
