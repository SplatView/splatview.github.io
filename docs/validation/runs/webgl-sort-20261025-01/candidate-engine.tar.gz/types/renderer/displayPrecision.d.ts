import type { SortPrecision } from './sortPrecision';
export type DisplayPoseIdentity = Readonly<{
    owner: object;
    scene: object | undefined;
    camera: object;
    revision: number;
}>;
/** A changed pose may use the qualified interactive key; a stationary or new
 * owner uses exact order. The host schedules the final refinement frame. */
export declare function interactiveDisplayPrecision(previous: DisplayPoseIdentity | undefined, current: DisplayPoseIdentity): SortPrecision;
