import type { DisplayCompletion } from './contracts';
export type DisplayFrameIdentity = Readonly<{
    owner: object;
    scene: object | undefined;
    width: number;
    height: number;
}>;
/** Host admission metadata only: no submission, scheduling, cancellation or
 * retirement authority. Real backend completion releases each occupied slot. */
export declare class DisplayFrameAdmission {
    readonly capacity: 1 | 2;
    private readonly flights;
    private readonly latest;
    constructor(capacity?: 1 | 2);
    get inFlight(): number;
    canSubmit(identity: DisplayFrameIdentity): boolean;
    track(identity: DisplayFrameIdentity, checkpoint: DisplayCompletion): boolean;
}
