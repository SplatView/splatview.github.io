/** Session-only display preferences; these never enter a scene or saved-view format. */
export type GaussianRenderMode = 'sorted' | 'steady';
export type SteadySettings = Readonly<{
    mode: GaussianRenderMode;
    historyWeight: number;
    convergence: boolean;
    convergenceFrames: number;
    animate: boolean;
}>;
export type SteadyStatus = 'sorted' | 'preparing' | 'steady' | 'unavailable';
export declare const DEFAULT_STEADY_SETTINGS: SteadySettings;
export declare function validateSteadySettings(value: SteadySettings): SteadySettings;
