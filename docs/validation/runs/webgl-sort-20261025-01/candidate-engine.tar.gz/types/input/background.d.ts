export declare const BACKGROUND_COLORS: readonly ['black', 'gray', 'white'];
export type BackgroundColor = typeof BACKGROUND_COLORS[number];
export declare function backgroundShade(color: BackgroundColor): number;
export declare function nextBackground(color: BackgroundColor): BackgroundColor;
