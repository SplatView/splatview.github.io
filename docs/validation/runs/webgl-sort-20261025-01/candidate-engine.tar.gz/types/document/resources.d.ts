export declare const MiB: number;
export declare class AdmissionError extends Error {
}
export type Category = 'source' | 'decoded' | 'work' | 'history' | 'render' | 'image' | 'recovery';
export type ResourceLease = (() => void) & {
    readonly bytes: number;
    resize(bytes: number): void;
};
/** Opaque identity only. The mutable reservation and its liveness stay private.
 * This draft addition lets a materialization barrier inspect multiple credits
 * without invoking a caller's lease.bytes getter between inspections. */
declare const resourceCreditBrand: unique symbol;
export type ResourceCredit = Readonly<{
    readonly [resourceCreditBrand]: true;
}>;
export declare function resourceLeaseCredit(lease: ResourceLease): ResourceCredit;
/** Explicitly bind a cleanup/resize wrapper to the genuine reservation it owns.
 * Possession of a genuine lease (or an already bound wrapper) is required. This
 * invokes no wrapper hooks/getters and never moves or duplicates the credit.
 * Owners must reject duplicate credit identities even through distinct wrappers.
 */
export declare function bindResourceLeaseCredit(wrapper: ResourceLease, underlying: ResourceLease): ResourceLease;
/** Trusted, hook-free observation. Released zero-byte credit is distinct from a
 * live zero-byte reservation; neither wrapper properties nor callbacks run. */
export declare function resourceCreditBytes(credit: ResourceCredit): number | undefined;
export declare function assertResourceCredit(credit: ResourceCredit, expectedBytes: number): void;
export declare function checkedBytes(count: number, stride: number): number;
/** Browser-owned checkpoint bytes are external to the measured native heap.
 * Reserve both generations during replacement. Metadata includes the owner's
 * bounded immutable JSON/table estimate, not native serialization workspace.
 */
export declare function estimateRecoveryCheckpointBytes(byteLength: number, maximumChunkBytes: number, metadataBytes: number): Readonly<{
    retainedBytes: number;
    workBytes: number;
    totalBytes: number;
}>;
export declare function packedStride(degree: number): number;
export declare function estimateSceneBytes(count: number, degree: number): number;
export declare const FLOOR_VIEW_BOOKKEEPING_BYTES: number;
export declare function estimateFloorWorkBytes(count: number): number;
export declare function estimateCaptureBytes(width: number, height: number, depth?: boolean): number;
export declare class ResourceLedger {
    readonly limit: number;
    private entries;
    private used;
    private peak;
    private identities;
    constructor(limit: number);
    get usage(): {
        bytes: number;
        peakBytes: number;
        allocations: number;
    };
    /** Logical reservations only; this does not measure physical JS/GPU memory. */
    get categorySnapshot(): Readonly<Record<Category, Readonly<{
        bytes: number;
        allocations: number;
    }>>>;
    get overageBytes(): number;
    owns(lease: ResourceLease, category?: Category): boolean;
    reserve(category: Category, bytes: number): ResourceLease;
    private stage;
    private commit;
    rebalance(updates: readonly {
        lease: ResourceLease;
        bytes: number;
    }[]): void;
    /** Record memory that already exists, never admission for new native work.
     * Only the measured heap remainder may increase; all other owners must shrink.
     * NativeHeapAccounting supplies and validates the same-client H/C evidence.
     */
    retainObservedNativeHeap(remainder: ResourceLease, bytes: number, reductions?: readonly {
        lease: ResourceLease;
        bytes: number;
    }[]): void;
    /** Redistribute existing retained native credit at an unchanged measured H.
     * The accounting owner proves actual payload coverage; this cannot add any
     * aggregate admission while an active heap is over the configured budget.
     */
    transferRetainedNativeCoverage(remainder: ResourceLease, bytes: number, updates: readonly {
        lease: ResourceLease;
        bytes: number;
    }[]): void;
}
export {};
