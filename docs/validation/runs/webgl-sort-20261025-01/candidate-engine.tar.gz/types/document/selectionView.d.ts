/** Canonical desktop camera: target xyz, yaw, pitch, distance, radius,
 * vertical FOV in degrees, yUp, roll and aspect. Native code derives clipping. */
export type SelectionView = readonly [number, number, number, number, number, number, number, number, number, number, number];
export type MaskChannel = 'document' | 'colorBase' | 'transformBase' | 'opacityBase';
export declare const SELECTION_VIEW_COMMANDS: readonly ['clipSelection', 'selectAll', 'selectNone', 'invert', 'delete', 'crop', 'single', 'rectangle', 'polygon', 'brush', 'volume', 'colorPick', 'fillPick', 'morphology', 'duplicate', 'previewFilter', 'beginColor', 'grade', 'autoColor', 'transform', 'beginTransform', 'rebaseTransform', 'beginOpacity'];
export declare function validateSelectionView(value: unknown): SelectionView | null;
/** Let existing command families retain exact field validation. */
export declare function commandWithoutSelectionView(value: unknown, allowed: readonly string[]): unknown;
/** Detach camera values before an asynchronous worker queue can observe edits. */
export declare function captureSelectionViewCommand<T extends {
    command: string;
}>(value: T): T;
export declare function isBeginColorCommand(value: unknown): boolean;
