export declare const DUPLICATE_SCENE_LIMIT = 1000000;
export type DuplicateRange = Readonly<{
    first: number;
    count: number;
}> | null;
/** The marker describes a nonempty suffix of one immutable Gaussian scene.
 * Its containing summary/receipt supplies the authoritative scene revision. */
export declare function validateDuplicateRange(value: unknown, loadedCount: number, gaussian?: boolean): DuplicateRange;
export declare function sameDuplicateRange(a: DuplicateRange, b: DuplicateRange): boolean;
/** Every summary owns this field, including unloaded and view-only scenes. */
export declare function validateDuplicateSummary(value: {
    loaded: boolean;
    kind: number;
    count: number;
    sourceCount: number;
    duplicateRange: unknown;
}): DuplicateRange;
/** Duplicate accepts only its captured view; native code owns records/center IDs. */
export declare function isDuplicateCommand(value: unknown): boolean;
