export type ImageOperation = {
    signal?: AbortSignal;
    current?: () => void;
    admit: (bytes: number) => () => void;
};
export type OwnedRgbaImage = Readonly<{
    width: number;
    height: number;
    pixels: Uint8ClampedArray<ArrayBuffer>;
    dispose(): void;
}>;
export type OwnedImageOutput = Readonly<{
    blob: Blob;
    dispose(): void;
}>;
/** The same bounded raw-image dimensions as the desktop thumbnail endpoint. */
export declare function rgbaImageBytes(width: number, height: number): number;
/** Consume an already admitted, tightly packed buffer on success. The caller
 * retains cleanup responsibility if validation throws before ownership moves. */
export declare function ownRgbaImage(width: number, height: number, pixels: Uint8ClampedArray<ArrayBuffer>, release: () => void): OwnedRgbaImage;
/** A pending encoder/filter borrows the raw buffer until its actual Promise
 * joins. Disposing its parent cannot release or detach bytes still in use. */
export declare function withRgbaImage<T>(source: OwnedRgbaImage, read: (pixels: Uint8ClampedArray<ArrayBuffer>) => T | Promise<T>): Promise<T>;
/** Encode one immutable raw frame without consuming it. Browser encoding is
 * an explicit PNG/JPEG adapter; matching JPEG bytes across encoders is not
 * promised. Both working storage and returned Blob ownership remain admitted. */
export declare function encodeRgba(source: OwnedRgbaImage, type: 'image/png' | 'image/jpeg', operation: ImageOperation, quality?: number): Promise<OwnedImageOutput>;
