import json
from pathlib import Path

out=Path('docs/validation/runs/renderer-comparison-20261025-01')
s=json.loads((out/'summary.json').read_text());images=json.loads((out/'images.json').read_text())
rows={(v['fixture'],v['variant']):v for v in s['series']}
fixtures=['256k-sparse','256k-dense','1m-sparse','1m-dense']
gpu_variants=['splatview-webgpu-32','splatview-webgpu-24','playcanvas-webgpu','colmapview-webgpu-16']
gl_variants=['splatview-webgl2-32','splatview-webgl2-24','playcanvas-webgl2']
def gpu(f,v,phase):return rows[f,v][phase]['wholePipelineGpuMs']['medianMs']
gpu_table='\n'.join('| '+f+' | '+' | '.join(f'{gpu(f,v,"motion"):.3f} / {gpu(f,v,"fixed"):.3f}' for v in gpu_variants)+' |' for f in fixtures)
gl_table='\n'.join('| '+f+' | '+' | '.join(f'{rows[f,v]["motion"]["completionMs"]["medianMs"]:.2f}' for v in gl_variants)+' |' for f in fixtures)
quality_table=[]
for v in gpu_variants[1:]+gl_variants:
    values=[x['qualityVsSplatView32'] for x in images if x['fixture'] and x['variant']==v and x['phase']=='fixed-image']
    quality_table.append(f'| {v} | {min(x["psnrDb"] for x in values):.2f} | {min(x["foregroundPsnrDb"] for x in values):.2f} |')

report='''# SplatView / PlayCanvas / COLMAPView renderer benchmark

**84 comparison cases and seven camera/color probes passed.** Each fixture /
renderer cell contains three repetitions, 180 moving and 180 fixed-view samples.
The application and standalone engine algorithms were unchanged for this work.

Observed configuration: Windows, Chromium 156, NVIDIA RTX 5090 / Blackwell,
640x400 physical pixels, DPR 1, SH0, black background. The temporary loopback
host is a secure context without cross-origin isolation or a CSP header;
upstream blob workers are allowed. Chromium uses `--enable-unsafe-webgpu`.
GPU clocks add timestamp-query support; ordinary renderer feature selection is
retained. The post-run adapter observation and per-case features are recorded.

Open the [interactive image comparison](comparison.html), inspect
[timings.csv](timings.csv), or read the complete [summary](summary.json) and
[validation receipt](validation.json).

## GPU work

Median GPU pass totals in milliseconds, shown as **moving / fixed**. These sum
each frame's actual GPU pass timestamps before calculating the distribution.
They exclude CPU work, queue callback latency, readback and presentation.
The full report also contains p95 values and CPU submission/completion clocks.

| Fixture | SplatView 32-bit | SplatView 24-bit | PlayCanvas GPU default | COLMAPView GPU 16-bit |
| --- | --- | --- | --- | --- |
'''+gpu_table+'''

PlayCanvas leads the larger moving-camera cases. SplatView's 24-bit path leads
the 256k sparse moving case and every unchanged-view redraw case, and is ahead
of the measured COLMAPView session. At 1M moving sources, SplatView takes about 0.424 ms sparse / 1.123 ms dense;
PlayCanvas takes 0.329 / 0.975 ms and COLMAPView takes 1.089 / 1.736 ms.
These are results for this hardware, input and configuration, not a universal
ranking or a parity target.
The fixed phase forces redraws of an unchanged view. It measures reuse/caching;
it does not claim that an idle application continuously submits frames.

## WebGL and sort freshness

Moving-frame median CPU-through-GPU-completion in milliseconds. Both GL adapters
use `gl.finish`, avoiding different browser fence-poll intervals. **PlayCanvas
retains asynchronous sorting and may display its previous order; SplatView waits
for the current sort.** The low PlayCanvas first-display value is therefore not
a same-freshness sorting-latency result. Worker compute/round-trip timings and
first-versus-settled images are retained separately.

| Fixture | SplatView 32-bit | SplatView 24-bit | PlayCanvas first display, async sort |
| --- | --- | --- | --- |
'''+gl_table+'''

SplatView's main opportunity is WebGL worker sorting. Useful follow-up work is
approximate or asynchronous display ordering with bounded freshness, followed
by exact refinement at rest and exact queries/captures. GPU sorting/projector
work is a smaller remaining gap to PlayCanvas on this device. This benchmark
does not change either implementation to match the other.

## Image agreement and configuration differences

Minimum settled-image PSNR across the tested poses/scenes. The reference is
**SplatView GPU 32-bit**, not perceptual ground truth; these are agreement scores,
not an independent image-quality ranking. Foreground scores exclude the black
background using the union of pixels above 8/255. Compare the actual images.

| Variant | Whole-image PSNR, dB | Foreground PSNR, dB |
| --- | --- | --- |
'''+ '\n'.join(quality_table)+'''

The common scene supplies activated positions, scales, identity quaternions,
opacity and SH0 colors. SplatView uses float covariance / half SH0, PlayCanvas
uses its texture packing and default minimum pixel size 2 with sRGB output and
no tone mapping, and COLMAPView uses float scale/quaternion SH0 with its original
16-bit radix / front-to-back billboard / composite session. AA, culling, color
handling and sorting choices differ. Sorting precision alone does not explain
the cross-renderer image differences.

Sparse cases place 25% of source centers in the view region with scale 0.025;
dense cases place all centers there with scale 0.05 and greater overlap. These
are composite workloads, not an isolated culling experiment. Camera poses,
physical viewport and input values are shared within each fixture.

## Reproduction and evidence

The [tool guide](../../../../tools/bench/comparison/README.md) documents commands,
scope and frozen-input requirements. PlayCanvas is the integrity-verified
2.24.0-beta.10 package at
[`3b389e0`](https://github.com/playcanvas/engine/commit/3b389e05a4619dcb2a6efec3bc8139bf43cafd95).
COLMAPView uses its original renderer session and vendored gs-toolbox from
[`0a1d01c`](https://github.com/ColmapView/Colmapview.github.io/tree/0a1d01c3c8c65f9c0a244f4608c50558c221c5fd).
Original reference licenses remain in the isolated frozen tree. No shipping
dependency, application source, worker protocol or product binding was changed.

The accepted run rotates renderer order across repetitions and keeps GPU
workloads sequential. Every case has a new browser context, real completion and
resource retirement. Source/reference hashes stayed fixed through measurement.
Setup timings include adapter conversion and constructor/upload after module
preloading; they are not app cold-load or file-loading performance.

Six benchmark contract tests and 6,451 existing portable tests passed, along
with both typechecks, frozen source/native/build, generated asset/product and
standalone artifact checks. The existing 133 product registrations and prior
throughput receipt are unchanged. NativeQualification remains false.

Calibration failures were retained and excluded: an oversized query-set probe,
a three-source PlayCanvas GPU binding rejection, and a tiny-splat sparse fixture
discarded by default culling. The final probe has four records / three visible
points, and timed images must contain nontrivial foreground. The first calibration
used linear PlayCanvas output; the accepted run uses sRGB. Some initial calibration
image paths were superseded; those metadata are not accepted as image evidence.
Accepted runs have distinct image directories and hashes.

This is a renderer-core/session benchmark. Full viewer UI, codecs/file loading,
editing/picking, Spark/WebGL fallback in COLMAPView, LOD streaming, SH1-3,
stochastic/TAA, larger resolutions and other browser/OS/GPU configurations remain
outside this comparison. Physical presentation FPS and driver memory are not
observed. Implementation or feature parity is not an acceptance requirement.
'''
(out/'README.md').write_text(report,encoding='utf-8')

data={'rows':s['series'],'images':[dict(x,path='images/'+Path(x['file']['path']).name) for x in images if x['fixture']]}
html='''<!doctype html><meta charset="utf-8"><title>Renderer comparison</title>
<style>body{font:15px system-ui;background:#16191e;color:#e4e9ef;margin:24px}a{color:#9fd0ff}select{font:inherit;margin:8px;padding:6px;background:#252b33;color:inherit}table{border-collapse:collapse;margin:18px 0}th,td{padding:8px 12px;border:1px solid #465363;text-align:left}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:16px}figure{margin:0;padding:12px;background:#252b33}img{width:100%;height:auto;background:black}figcaption{padding:8px 0}p{max-width:1000px;color:#bac7d4}</style>
<h1>Renderer comparison</h1><p>RTX 5090 · Chromium 156 · SH0 · 640×400. Images and clocks from 84 accepted cases. Agreement reference: SplatView GPU 32-bit. This is not perceptual ground truth. <a href="README.md">Scope and method</a>.</p>
<label>Scene<select id="scene"></select></label><label>View<select id="phase"><option value="motion">First moving image</option><option value="fixed">Settled image</option></select></label><label>Pose<select id="pose"><option value="0">−0.2 rad</option><option value="1">0 rad</option><option value="2">+0.2 rad</option></select></label>
<p>GPU time is a whole-pipeline pass total. CPU→completion includes actual GPU completion. PlayCanvas WebGL may use the previous sort, while SplatView waits for the current sort; those first-display clocks have different freshness. Hover images for full-size links.</p><div id="table"></div><main id="images"></main><script>
const data=DATA;
const scenes=[...new Set(data.rows.map(r=>r.fixture))],scene=document.querySelector('#scene'),phase=document.querySelector('#phase'),pose=document.querySelector('#pose');for(const f of scenes)scene.add(new Option(f,f));
const number=x=>x==null?'—':x.toFixed(3);function render(){const rows=data.rows.filter(r=>r.fixture===scene.value),mode=phase.value,index=Number(pose.value);let table='<table><tr><th>Renderer</th><th>GPU ms</th><th>CPU→completion ms</th><th>Image agreement dB</th></tr>',figures='';for(const r of rows){const im=data.images.find(x=>x.fixture===scene.value&&x.variant===r.variant&&x.phase===(mode==='motion'?'motion-image':'fixed-image')&&x.index===index),q=im.qualityVsSplatView32;table+='<tr><td>'+r.variant+'</td><td>'+number(r[mode].wholePipelineGpuMs?.medianMs)+'</td><td>'+number(r[mode].completionMs.medianMs)+'</td><td>'+(q?q.psnrDb.toFixed(2):'reference')+'</td></tr>';figures+='<figure><figcaption>'+r.variant+' · '+(q?q.psnrDb.toFixed(2)+' dB':'reference')+'</figcaption><a href="'+im.path+'"><img alt="'+r.variant+' '+scene.value+'" src="'+im.path+'"></a></figure>';}document.querySelector('#table').innerHTML=table+'</table>';document.querySelector('#images').innerHTML=figures;}
for(const e of [scene,phase,pose])e.addEventListener('change',render);render();</script>'''.replace('DATA',json.dumps(data).replace('</','<\\/'))
(out/'comparison.html').write_text(html,encoding='utf-8')
print(out/'README.md')
