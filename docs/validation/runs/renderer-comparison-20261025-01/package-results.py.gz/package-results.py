import csv
import datetime
import gzip
import hashlib
import json
import shutil
import sys
from pathlib import Path

import numpy as np
from PIL import Image
import PIL

ROOT=Path.cwd()
PHASE=ROOT/'.build/renderer-comparison-20261025-01'
OUT=ROOT/'docs/validation/runs/renderer-comparison-20261025-01'
OUT.mkdir(parents=True,exist_ok=True)


def record(path):
    b=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}


def save(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    return record(path)


def archive(path,name=None):
    b=path.read_bytes();target=OUT/((name or path.name)+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(b,compresslevel=9,mtime=0))
    return {'archive':record(target),'uncompressedBytes':len(b),'uncompressedSha256':hashlib.sha256(b).hexdigest()}


raw=json.loads((PHASE/'results.json').read_text())
summary=json.loads((PHASE/'summary.json').read_text())
assert len(raw['cases'])==84 and len(raw['probes'])==7 and not raw['errors'] and raw.get('finishedAt')
frozen=json.loads((PHASE/'measured-source.json').read_text())
assert all(record(ROOT/f['path'])==f for f in frozen['files'])
references=json.loads((PHASE/'references.json').read_text())
for f in references['files']:
    b=(PHASE/'references'/f['path']).read_bytes()
    assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']

image_records=[];case_reports=[];settle=[]
for case in raw['cases']+raw['probes']:
    path=PHASE/case['path'];value=json.loads(path.read_text());assert not value['errors'] and not value['lost']
    case_reports.append({'id':case['id'],'report':archive(path,'raw/'+path.name)})
    motion={}
    for image in value['images']:
        source=PHASE/image['path'];b=source.read_bytes();assert len(b)==image['bytes'] and hashlib.sha256(b).hexdigest()==image['sha256']
        dest=OUT/'images'/source.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(source,dest)
        image_records.append({'variant':case['variant'],'fixture':case['fixtureId'],'phase':image['phase'],'index':image['index'],
            'angle':image['angle'],'file':record(dest),'qualityVsSplatView32':image['qualityVsSplatView32']})
        pixels=np.asarray(Image.open(source).convert('RGB'),dtype=np.float64)/255
        if image['phase']=='motion-image':motion[image['index']]=pixels
        elif image['phase']=='fixed-image':
            difference=np.abs(pixels-motion[image['index']]);mse=float(np.mean(difference*difference))
            settle.append({'variant':case['variant'],'fixture':case['fixtureId'],'pose':image['index'],
                'meanAbsoluteRgb':float(np.mean(difference)),'maxAbsoluteRgb':float(np.max(difference)),
                'psnrDb':-10*np.log10(mse) if mse else 999,
                'scope':'Same-pose first image versus image after four rest frames; includes async sorting and any renderer temporal/numeric behavior.'})

prior=record(ROOT/'docs/validation/runs/rendering-throughput-20261025-01/validation.json')
assert prior['sha256']=='330f5034adb1e0fadc7f5fafc5e5f9c70122939aa2b0f1b56dbd2d67a70b3fcc'
unit=json.loads((PHASE/'unit.json').read_text(encoding='utf-8-sig'));assert unit['success'] and unit['numPassedTests']==6451 and unit['numFailedTests']==0
sources=[]
for p in sorted((ROOT/'tools/bench/comparison').glob('*')):
    if p.is_file():sources.append(record(p))
sources.append(record(ROOT/'design/feature-reviews/renderer-comparison-benchmark-2026-10-25.md'))

diagnostics=[]
for name,reason in {
    'probe-01-invalid-clock.json':'Rejected fixture clock: query count exceeded the observed 4096-query limit. Replaced with bounded query blocks before accepted measurement.',
    'probe-02-small-input.json':'Pinned PlayCanvas GPU path rejected a 12-byte binding for the three-source probe. Four records, one invisible, qualify the same three visible points without patching upstream code.',
    'smoke-01-small-splats.json':'Excluded calibration: default PlayCanvas GPU minimum pixel size discarded the tiny sparse fixture. Initial image paths were superseded during calibration; metadata/logs retained, not accepted as timing/image evidence.',
}.items():
    diagnostics.append({'reason':reason,'report':archive(PHASE/name)})
logs=[archive(p) for p in PHASE.glob('*.log')]
checks=[
    {'command':'node tools/bench/comparison/run.mjs .build/renderer-comparison-20261025-01 --label=measured-01','exitCode':0,'cases':84,'probes':7},
    {'command':'python -B tools/bench/comparison/summarize.py .build/renderer-comparison-20261025-01','exitCode':0,'series':28,'samplesPerPhase':180},
    {'command':'node --test tools/bench/comparison/fixtures.test.mjs tools/bench/comparison/build.test.mjs','exitCode':0,'tests':6},
    {'command':'npm test -- --maxWorkers=4 --reporter=json --outputFile=.build/renderer-comparison-20261025-01/unit.json','exitCode':0,'tests':6451,'files':len(unit['testResults'])},
    {'command':'npm run typecheck','exitCode':0},{'command':'npm run typecheck:bench','exitCode':0},
    {'command':'npm run verify:sources','exitCode':0,'frozenFiles':919,'productRegistrations':133},
    {'command':'npm run verify:build','exitCode':0,'scope':'Frozen native output/provenance, no new native runtime claim.'},
    {'command':'node tools/check-engine.mjs','exitCode':0,'artifacts':62,'engineSourceId':raw['build']['engineSourceId']},
]
value={'schemaVersion':1,'kind':'renderer-comparison-delivery','status':'measured-and-locally-qualified','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'review':record(ROOT/'design/feature-reviews/renderer-comparison-benchmark-2026-10-25.md'),
    'priorEvidenceUnchanged':prior,'measuredSource':archive(PHASE/'measured-source.json'),
    'analysisSources':save('source-files.json',{'files':sources}),
    'references':save('references.json',references),'sdkManifest':save('engine-manifest.json',json.loads((ROOT/'dist-engine/engine-manifest.json').read_text())),
    'rawCohort':archive(PHASE/'results.json'),'rawCases':case_reports,
    'summary':save('summary.json',summary),'environment':save('environment.json',json.loads((PHASE/'environment.json').read_text())),
    'images':save('images.json',image_records),'samePoseSettling':save('settling-image-delta.json',{'processor':{'python':sys.version,'pillow':PIL.__version__,'numpy':np.__version__},'samples':settle}),
    'diagnostics':diagnostics,'logs':logs,'checks':checks,'portableReport':archive(PHASE/'unit.json'),
    'scope':['Windows Chromium/NVIDIA RTX 5090, 640x400 DPR1, SH0 synthetic scenes only.',
        'Two source counts, sparse/smaller and dense/larger footprints; these are composite workloads, not an isolated culling experiment.',
        'Renderer cores/sessions; full viewer UI, codecs, file loading, editing, LOD streaming, Steady/TAA, other browsers/OS/GPUs and physical presentation are outside this comparison.',
        'COLMAPView uses its frozen original WebGPU session and vendored gs-toolbox; Spark/WebGL fallback is not measured.',
        'Image agreement to SplatView 32-bit is not a ground-truth quality ranking. Packing, AA, culling and color handling differ.',
        'PlayCanvas GL is asynchronous and can use the previous sort; its first-display completion is not a current-sort latency result.',
        'No app/SDK algorithm, registration, source/toolchain/native/WASM lock or shipping asset was changed.'],
    'processors':[archive(PHASE/'package-results.py'),archive(PHASE/'inspect-environment.mjs')]}
save('validation.json',value)

with (OUT/'timings.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.writer(f);writer.writerow(['fixture','variant','phase','gpu_median_ms','gpu_p95_ms','submission_median_ms','completion_median_ms','completion_p95_ms'])
    for row in summary['series']:
        for phase in ['motion','fixed']:
            data=row[phase];gpu=data['wholePipelineGpuMs'];writer.writerow([row['fixture'],row['variant'],phase,gpu['medianMs'] if gpu else '',gpu['p95Ms'] if gpu else '',data['submissionMs']['medianMs'],data['completionMs']['medianMs'],data['completionMs']['p95Ms']])
print('Packaged',len(raw['cases']),'cases and',len(image_records),'images in',OUT)
